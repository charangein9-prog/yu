import os
import json
from datetime import timedelta, datetime, timezone

import discord
from discord import app_commands

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
AUDIT_FILE = os.path.join(DATA_DIR, "security_audit.log")
DATA_FILE = os.path.join(DATA_DIR, "punishment.json")
os.makedirs(DATA_DIR, exist_ok=True)

DEFAULT_CONFIG = {
    "enabled": False,
    "channel_id": None,
    "punishment": "timeout",
    "timeout_minutes": 10,
    "exempt_words": [],
    "panel_message_id": None,
    "panel_channel_id": None,
}


def load_data():
    if not os.path.exists(DATA_FILE):
        return {}
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"❌ อ่าน punishment.json ไม่ได้: {e}")
        return {}


def save_data(data):
    tmp_file = DATA_FILE + ".tmp"
    with open(tmp_file, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)
    os.replace(tmp_file, DATA_FILE)

def audit(guild_id, user_id, action):
    try:
        now = datetime.now(timezone.utc).isoformat(timespec="seconds")
        with open(AUDIT_FILE, "a", encoding="utf-8") as f:
            f.write(f"{now} guild={guild_id} user={user_id} action={action}\n")
    except OSError:
        pass
def get_config(guild_id):
    data = load_data()
    gid = str(guild_id)
    changed = False
    if gid not in data:
        data[gid] = DEFAULT_CONFIG.copy()
        changed = True
    else:
        for key, value in DEFAULT_CONFIG.items():
            if key not in data[gid]:
                data[gid][key] = value
                changed = True
    if changed:
        save_data(data)
    return data[gid]


def update_config(guild_id, key, value):
    data = load_data()
    gid = str(guild_id)
    if gid not in data:
        data[gid] = DEFAULT_CONFIG.copy()
    data[gid][key] = value
    save_data(data)


def can_manage(interaction):
    if interaction.guild is None:
        return False
    p = interaction.user.guild_permissions
    return interaction.guild.owner_id == interaction.user.id or p.administrator or p.manage_guild


def make_embed(guild_id):
    c = get_config(guild_id)
    channel = f"<#{c['channel_id']}>" if c.get("channel_id") else "ยังไม่ได้ตั้ง"
    method = {"timeout": "Timeout", "kick": "Kick", "ban": "Ban"}.get(c.get("punishment"), "Timeout")
    words = c.get("exempt_words", [])
    status = "🟢 เปิด" if c.get("enabled") else "🔴 ปิด"
    return discord.Embed(
        title="🛡️ ระบบลงโทษ",
        description=(
            f"สถานะ: **{status}**\n"
            f"ห้องลงโทษ: {channel}\n"
            f"วิธีลงโทษ: **{method}**\n"
            f"Timeout: **{c.get('timeout_minutes', 10)} นาที**\n"
            f"คำยกเว้น: **{len(words)} คำ**\n\n"
            "กดปุ่มด้านล่างเพื่อแก้ไขระบบ"
        ),
        color=discord.Color.blurple(),
    )


class TimeoutModal(discord.ui.Modal, title="ตั้งเวลา Timeout"):
    minutes = discord.ui.TextInput(label="จำนวนนาที", placeholder="10", required=True, max_length=6)

    async def on_submit(self, interaction):
        if not can_manage(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        try:
            value = max(1, min(int(self.minutes.value.strip()), 40320))
        except ValueError:
            await interaction.response.send_message("❌ ต้องใส่เป็นตัวเลข", ephemeral=True)
            return
        update_config(interaction.guild.id, "timeout_minutes", value)
        audit(interaction.guild.id, interaction.user.id, f"F1 set_timeout={value}")
        await interaction.response.send_message(f"✅ ตั้ง Timeout {value} นาที", ephemeral=True)


class AddWordModal(discord.ui.Modal, title="เพิ่มคำยกเว้น"):
    word = discord.ui.TextInput(label="คำยกเว้น", placeholder="เช่น อนุญาต", required=True, max_length=200)

    async def on_submit(self, interaction):
        if not can_manage(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        value = self.word.value.strip()
        if not value:
            await interaction.response.send_message("❌ ห้ามว่าง", ephemeral=True)
            return
        c = get_config(interaction.guild.id)
        words = c.get("exempt_words", [])
        if value.lower() not in [str(x).lower() for x in words]:
            words.append(value)
            update_config(interaction.guild.id, "exempt_words", words)
        audit(interaction.guild.id, interaction.user.id, "F1 change_exempt_words")
        await interaction.response.send_message(f"✅ เพิ่ม `{value}` แล้ว", ephemeral=True)


class RemoveWordSelect(discord.ui.Select):
    def __init__(self, words):
        self.words = [str(x) for x in words]

        options = []
        for index, word in enumerate(self.words[:25]):
            options.append(
                discord.SelectOption(
                    label=word[:100],
                    value=str(index),
                    description="กดเพื่อเลือกคำนี้สำหรับลบ",
                    emoji="🗑️"
                )
            )

        if not options:
            options = [
                discord.SelectOption(
                    label="ยังไม่มีคำยกเว้น",
                    value="none",
                    description="กรุณาเพิ่มคำยกเว้นก่อน",
                    emoji="📭"
                )
            ]

        super().__init__(
            placeholder="🗑️ เลือกคำที่ต้องการลบ...",
            min_values=1,
            max_values=1,
            options=options,
            disabled=not bool(self.words),
            custom_id="punishment_remove_word_select"
        )

    async def callback(self, interaction):
        if not can_manage(interaction):
            await interaction.response.send_message(
                "❌ ไม่มีสิทธิ์",
                ephemeral=True
            )
            return

        selected = self.values[0]

        if selected == "none":
            await interaction.response.send_message(
                "📭 ยังไม่มีคำยกเว้นให้ลบ",
                ephemeral=True
            )
            return

        try:
            index = int(selected)
            word_to_remove = self.words[index]
        except (ValueError, IndexError):
            await interaction.response.send_message(
                "❌ ไม่พบคำที่เลือก กรุณาเปิดหน้าลบคำใหม่",
                ephemeral=True
            )
            return

        c = get_config(interaction.guild.id)
        current_words = c.get("exempt_words", [])

        # ลบคำที่เลือกแบบไม่สนตัวพิมพ์เล็ก/ใหญ่
        new_words = [
            x for x in current_words
            if str(x).lower() != word_to_remove.lower()
        ]

        update_config(
            interaction.guild.id,
            "exempt_words",
            new_words
        )

        audit(
            interaction.guild.id,
            interaction.user.id,
            f"F1 remove_exempt_word={word_to_remove}"
        )

        await interaction.response.edit_message(
            content=f"✅ ลบคำ `{word_to_remove}` แล้ว",
            view=RemoveWordView(new_words)
        )


class RemoveWordView(discord.ui.View):
    def __init__(self, words):
        super().__init__(timeout=300)
        self.add_item(RemoveWordSelect(words))

    @discord.ui.button(
        label="❌ ปิด",
        style=discord.ButtonStyle.danger,
        custom_id="punishment_remove_word_close"
    )
    async def close(self, interaction, button):
        await interaction.response.edit_message(
            content="ปิดหน้าลบคำยกเว้นแล้ว",
            view=None
        )


class ChannelSelect(discord.ui.ChannelSelect):
    def __init__(self):
        super().__init__(
            placeholder="เลือกห้องลงโทษ",
            channel_types=[discord.ChannelType.text, discord.ChannelType.news],
            min_values=1,
            max_values=1,
            custom_id="punishment_channel_select",
        )

    async def callback(self, interaction):
        if not can_manage(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return
        channel = self.values[0]
        update_config(interaction.guild.id, "channel_id", channel.id)
        audit(interaction.guild.id, interaction.user.id, "F1 set_channel")
        await interaction.response.send_message(f"✅ ตั้งห้องเป็น {channel.mention}", ephemeral=True)


class PunishmentView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(ChannelSelect())

    @discord.ui.button(label="🟢 เปิดระบบ", style=discord.ButtonStyle.success, custom_id="pun_enable", row=1)
    async def enable(self, interaction, button):
        if not can_manage(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        c = get_config(interaction.guild.id)
        if not c.get("channel_id"):
            await interaction.response.send_message("❌ เลือกห้องก่อน", ephemeral=True); return
        update_config(interaction.guild.id, "enabled", True)
        audit(interaction.guild.id, interaction.user.id, "F1 enabled")
        await interaction.response.send_message("🟢 เปิดระบบแล้ว", ephemeral=True)

    @discord.ui.button(label="🔴 ปิดระบบ", style=discord.ButtonStyle.danger, custom_id="pun_disable", row=1)
    async def disable(self, interaction, button):
        if not can_manage(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        update_config(interaction.guild.id, "enabled", False)
        audit(interaction.guild.id, interaction.user.id, "F1 disabled")
        await interaction.response.send_message("🔴 ปิดระบบแล้ว", ephemeral=True)

    @discord.ui.button(label="⏱️ Timeout", style=discord.ButtonStyle.primary, custom_id="pun_timeout", row=2)
    async def timeout_button(self, interaction, button):
        if not can_manage(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        update_config(interaction.guild.id, "punishment", "timeout")
        audit(interaction.guild.id, interaction.user.id, "F1 punishment=timeout")
        await interaction.response.send_message("⏱️ เลือก Timeout แล้ว", ephemeral=True)

    @discord.ui.button(label="👢 Kick", style=discord.ButtonStyle.secondary, custom_id="pun_kick", row=2)
    async def kick(self, interaction, button):
        if not can_manage(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        update_config(interaction.guild.id, "punishment", "kick")
        audit(interaction.guild.id, interaction.user.id, "F1 punishment=kick")
        await interaction.response.send_message("👢 เลือก Kick แล้ว", ephemeral=True)

    @discord.ui.button(label="🔨 Ban", style=discord.ButtonStyle.danger, custom_id="pun_ban", row=2)
    async def ban(self, interaction, button):
        if not can_manage(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        update_config(interaction.guild.id, "punishment", "ban")
        audit(interaction.guild.id, interaction.user.id, "F1 punishment=ban")
        await interaction.response.send_message("🔨 เลือก Ban แล้ว", ephemeral=True)

    @discord.ui.button(label="⏰ ตั้งเวลา", style=discord.ButtonStyle.secondary, custom_id="pun_time", row=3)
    async def set_time(self, interaction, button):
        if not can_manage(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        await interaction.response.send_modal(TimeoutModal())

    @discord.ui.button(label="➕ เพิ่มคำยกเว้น", style=discord.ButtonStyle.secondary, custom_id="pun_add_word", row=3)
    async def add_word(self, interaction, button):
        if not can_manage(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        await interaction.response.send_modal(AddWordModal())

    @discord.ui.button(label="➖ ลบคำยกเว้น", style=discord.ButtonStyle.secondary, custom_id="pun_remove_word", row=3)
    async def remove_word(self, interaction, button):
        if not can_manage(interaction):
            await interaction.response.send_message(
                "❌ ไม่มีสิทธิ์",
                ephemeral=True
            )
            return

        c = get_config(interaction.guild.id)
        words = c.get("exempt_words", [])

        await interaction.response.send_message(
            "🗑️ **เลือกลบคำยกเว้น**\n"
            "กดเมนูด้านล่าง แล้วเลือกคำที่เคยกำหนดไว้ได้เลย",
            view=RemoveWordView(words),
            ephemeral=True
        )

    @discord.ui.button(label="🔄 อัปเดทแผง", style=discord.ButtonStyle.primary, custom_id="pun_update_panel", row=4)
    async def update_panel(self, interaction, button):
        if not can_manage(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        await interaction.response.defer(ephemeral=True)
        ok, text = await update_saved_panel(interaction.client, interaction.guild.id)
        await interaction.followup.send(("✅ " if ok else "❌ ") + text, ephemeral=True)


async def update_saved_panel(bot, guild_id):
    c = get_config(guild_id)
    mid, cid = c.get("panel_message_id"), c.get("panel_channel_id")
    if not mid or not cid:
        return False, "ยังไม่มีแผงที่บันทึกไว้ ให้ใช้ /punishment ใหม่ก่อน"
    guild = bot.get_guild(int(guild_id))
    if not guild:
        return False, "ไม่พบเซิร์ฟเวอร์"
    channel = guild.get_channel(int(cid))
    if not channel:
        return False, "ไม่พบห้องแผง"
    try:
        msg = await channel.fetch_message(int(mid))
        await msg.edit(embed=make_embed(guild_id), view=PunishmentView())
        return True, "อัปเดทแผงเดิมแล้ว"
    except discord.NotFound:
        return False, "แผงเดิมถูกลบแล้ว"
    except discord.Forbidden:
        return False, "บอทไม่มีสิทธิ์แก้ข้อความ"
    except discord.HTTPException as e:
        return False, f"Discord Error: {e}"


def setup(bot):
    @bot.tree.command(name="punishment", description="ตั้งค่าระบบ Timeout/Kick/Ban")
    async def punishment(interaction):
        if not can_manage(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        msg = await interaction.channel.send(embed=make_embed(interaction.guild.id), view=PunishmentView())
        update_config(interaction.guild.id, "panel_message_id", msg.id)
        update_config(interaction.guild.id, "panel_channel_id", interaction.channel.id)
        await interaction.response.send_message("✅ สร้างแผงตั้งค่าแล้ว", ephemeral=True)

    bot.add_view(PunishmentView())

    @bot.listen("on_message")
    async def punishment_message(message):
        if message.author.bot or message.guild is None:
            return
        c = get_config(message.guild.id)
        if not c.get("enabled") or message.channel.id != c.get("channel_id"):
            return
        p = message.author.guild_permissions
        if message.guild.owner_id == message.author.id or p.administrator or p.manage_guild:
            return
        content = message.content.strip().lower()
        if any(str(w).lower() in content for w in c.get("exempt_words", [])):
            return
        member = message.author
        me = message.guild.me
        if me is None or member.top_role >= me.top_role:
            return
        success = False
        try:
            method = c.get("punishment", "timeout")
            if method == "timeout":
                mins = max(1, min(int(c.get("timeout_minutes", 10)), 40320))
                await member.timeout(timedelta(minutes=mins), reason="ระบบลงโทษอัตโนมัติ")
                success = True
            elif method == "kick":
                await member.kick(reason="ระบบลงโทษอัตโนมัติ")
                success = True
            elif method == "ban":
                await member.ban(reason="ระบบลงโทษอัตโนมัติ", delete_message_seconds=0)
                success = True
        except (discord.Forbidden, discord.HTTPException) as e:
            print(f"❌ ลงโทษไม่สำเร็จ: {e}")
        if success:
            try:
                await message.delete()
            except (discord.Forbidden, discord.HTTPException):
                pass
