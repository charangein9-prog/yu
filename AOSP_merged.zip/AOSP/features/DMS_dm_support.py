# dm_support_bot.py
# Discord Bot Loader compatible
# IMPORTANT:
# This file is a FEATURE, not the main bot.
# It MUST be loaded by your main Bot Loader using:
#     await module.setup(bot)
#
# Do NOT put bot.run() in this file.
# Do NOT put TOKEN in this file.

import asyncio
import sqlite3
from datetime import datetime, timezone

import discord
from discord import app_commands
from discord.ext import commands


DB_FILE = "dm_support.sqlite3"


# =========================================================
# DATABASE
# =========================================================

class Database:
    def __init__(self, path=DB_FILE):
        self.path = path
        self.conn = sqlite3.connect(
            self.path,
            check_same_thread=False
        )
        self.conn.row_factory = sqlite3.Row
        self.lock = asyncio.Lock()

        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS guild_settings (
                guild_id INTEGER PRIMARY KEY,
                category_id INTEGER,
                staff_role_id INTEGER,
                status_channel_id INTEGER,
                close_dm_message INTEGER NOT NULL DEFAULT 0,
                staff_role_ids TEXT NOT NULL DEFAULT ''
            )
        """)

        try:
            self.conn.execute(
                "ALTER TABLE guild_settings "
                "ADD COLUMN close_dm_message INTEGER NOT NULL DEFAULT 0"
            )
            self.conn.commit()
        except sqlite3.OperationalError:
            pass
        try:
            self.conn.execute(
                "ALTER TABLE guild_settings "
                "ADD COLUMN staff_role_ids TEXT NOT NULL DEFAULT ''"
            )
            self.conn.commit()
        except sqlite3.OperationalError:
            pass

        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS tickets (
                user_id INTEGER PRIMARY KEY,
                guild_id INTEGER NOT NULL,
                channel_id INTEGER NOT NULL,
                username TEXT,
                created_at TEXT NOT NULL,
                closed INTEGER NOT NULL DEFAULT 0
            )
        """)

        # ตารางสำหรับเก็บข้อความตอบกลับด่วน (Quick Replies)
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS quick_replies (
                guild_id INTEGER,
                shortcut_id TEXT,
                label TEXT,
                message TEXT,
                PRIMARY KEY (guild_id, shortcut_id)
            )
        """)

        # ป้องกันข้อความ Discord เดิมถูกประมวลผลซ้ำ
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS processed_messages (
                message_id INTEGER PRIMARY KEY,
                created_at TEXT NOT NULL
            )
        """)

        self.conn.commit()

    async def get_settings(self, guild_id):
        async with self.lock:
            return self.conn.execute(
                "SELECT * FROM guild_settings WHERE guild_id=?",
                (guild_id,)
            ).fetchone()

    async def set_setting(self, guild_id, field, value):
        allowed = {
            "category_id",
            "staff_role_id",
            "status_channel_id",
            "close_dm_message",
            "staff_role_ids",
        }

        if field not in allowed:
            raise ValueError("Invalid setting")

        async with self.lock:
            row = self.conn.execute(
                "SELECT guild_id FROM guild_settings WHERE guild_id=?",
                (guild_id,)
            ).fetchone()

            if row:
                self.conn.execute(
                    f"UPDATE guild_settings SET {field}=? WHERE guild_id=?",
                    (value, guild_id)
                )
            else:
                self.conn.execute(
                    f"INSERT INTO guild_settings "
                    f"(guild_id, {field}) VALUES (?, ?)",
                    (guild_id, value)
                )

            self.conn.commit()

    async def get_quick_replies(self, guild_id):
        async with self.lock:
            return self.conn.execute(
                "SELECT * FROM quick_replies WHERE guild_id=?",
                (guild_id,)
            ).fetchall()

    async def save_quick_reply(self, guild_id, shortcut_id, label, message):
        async with self.lock:
            self.conn.execute("""
                INSERT INTO quick_replies (guild_id, shortcut_id, label, message)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(guild_id, shortcut_id) DO UPDATE SET
                    label=excluded.label,
                    message=excluded.message
            """, (guild_id, shortcut_id, label, message))
            self.conn.commit()

    async def delete_quick_reply(self, guild_id, shortcut_id):
        async with self.lock:
            self.conn.execute(
                "DELETE FROM quick_replies WHERE guild_id=? AND shortcut_id=?",
                (guild_id, shortcut_id)
            )
            self.conn.commit()

    async def get_ticket_by_user(self, user_id):
        async with self.lock:
            return self.conn.execute(
                "SELECT * FROM tickets WHERE user_id=?",
                (user_id,)
            ).fetchone()

    async def get_ticket_by_channel(self, channel_id):
        async with self.lock:
            return self.conn.execute(
                "SELECT * FROM tickets WHERE channel_id=?",
                (channel_id,)
            ).fetchone()

    async def save_ticket(
        self,
        user_id,
        guild_id,
        channel_id,
        username
    ):
        async with self.lock:
            self.conn.execute("""
                INSERT INTO tickets
                (
                    user_id,
                    guild_id,
                    channel_id,
                    username,
                    created_at,
                    closed
                )
                VALUES (?, ?, ?, ?, ?, 0)
                ON CONFLICT(user_id) DO UPDATE SET
                    guild_id=excluded.guild_id,
                    channel_id=excluded.channel_id,
                    username=excluded.username,
                    closed=0
            """, (
                user_id,
                guild_id,
                channel_id,
                username,
                datetime.now(timezone.utc).isoformat()
            ))

            self.conn.commit()

    async def claim_message(self, message_id):
        """คืน True เฉพาะครั้งแรกที่พบ message_id"""
        async with self.lock:
            try:
                self.conn.execute("BEGIN IMMEDIATE")
                cur = self.conn.execute("""
                    INSERT OR IGNORE INTO processed_messages
                    (message_id, created_at)
                    VALUES (?, ?)
                """, (
                    message_id,
                    datetime.now(timezone.utc).isoformat()
                ))
                self.conn.commit()
                return cur.rowcount == 1
            except Exception:
                try:
                    self.conn.rollback()
                except Exception:
                    pass
                return False

    async def release_message_claim(self, message_id):
        """ให้ retry ได้ถ้าการประมวลผลล้มเหลวจริง"""
        async with self.lock:
            try:
                self.conn.execute(
                    "DELETE FROM processed_messages WHERE message_id=?",
                    (message_id,)
                )
                self.conn.commit()
            except Exception:
                pass

    async def close_ticket(self, user_id):
        async with self.lock:
            self.conn.execute(
                "UPDATE tickets SET closed=1 WHERE user_id=?",
                (user_id,)
            )
            self.conn.commit()

    async def get_open_tickets(self, guild_id=None):
        async with self.lock:
            if guild_id is None:
                return self.conn.execute(
                    "SELECT * FROM tickets WHERE closed=0"
                ).fetchall()

            return self.conn.execute(
                "SELECT * FROM tickets "
                "WHERE guild_id=? AND closed=0",
                (guild_id,)
            ).fetchall()


# =========================================================
# UI
# =========================================================

class CategorySelect(discord.ui.ChannelSelect):
    def __init__(self, cog):
        self.cog = cog

        super().__init__(
            placeholder="📁 เลือก Category สำหรับสร้างห้อง DM",
            channel_types=[discord.ChannelType.category],
            min_values=1,
            max_values=1,
            row=0
        )

    async def callback(self, interaction):
        if not interaction.guild:
            return

        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                "❌ เฉพาะ Administrator",
                ephemeral=True
            )
            return

        category = self.values[0]

        await self.cog.db.set_setting(
            interaction.guild.id,
            "category_id",
            category.id
        )

        await interaction.response.send_message(
            f"✅ ตั้ง Category เป็น **{category.name}** แล้ว",
            ephemeral=True
        )


class StaffRoleSelect(discord.ui.RoleSelect):
    def __init__(self, cog):
        self.cog = cog
        super().__init__(
            placeholder="👤 เลือก Role ที่ตอบ DM / คุมห้องได้",
            min_values=1,
            max_values=1,
            row=0
        )

    async def callback(self, interaction):
        if not interaction.guild:
            return

        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                "❌ เฉพาะ Administrator",
                ephemeral=True
            )
            return

        role_ids = ",".join(str(role.id) for role in self.values)
        await self.cog.db.set_setting(
            interaction.guild.id,
            "staff_role_ids",
            role_ids
        )

        await interaction.response.send_message(
            f"✅ บันทึกยศผู้คุมห้อง / ตอบ DM เรียบร้อยแล้ว",
            ephemeral=True
        )


class StatusChannelSelect(discord.ui.ChannelSelect):
    def __init__(self, cog):
        self.cog = cog

        super().__init__(
            placeholder="📊 เลือกห้องสำหรับนับจำนวน DM",
            channel_types=[discord.ChannelType.text],
            min_values=1,
            max_values=1,
            row=1
        )

    async def callback(self, interaction):
        if not interaction.guild:
            return

        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                "❌ เฉพาะ Administrator",
                ephemeral=True
            )
            return

        channel = self.values[0]

        await self.cog.db.set_setting(
            interaction.guild.id,
            "status_channel_id",
            channel.id
        )

        await self.cog.update_status(interaction.guild)

        await interaction.response.send_message(
            f"✅ ตั้งห้องนับเป็น {channel.mention} แล้ว",
            ephemeral=True
        )


class QuickReplyModal(discord.ui.Modal, title="จัดการข้อความตอบกลับด่วน"):
    shortcut_id = discord.ui.TextInput(
        label="ID ทางลัด (เช่น hello, support)",
        placeholder="ภาษาอังกฤษตัวเล็ก ห้ามเว้นวรรค",
        max_length=20
    )
    label = discord.ui.TextInput(
        label="ชื่อปุ่ม (สูงสุด 80 ตัวอักษร)",
        placeholder="เช่น ทักทายลูกค้า",
        max_length=80
    )
    message_content = discord.ui.TextInput(
        label="ข้อความที่จะส่งให้ผู้ใช้",
        style=discord.TextStyle.paragraph,
        placeholder="พิมพ์ข้อความที่ต้องการส่ง...",
        max_length=1000
    )

    def __init__(self, cog, guild_id):
        super().__init__()
        self.cog = cog
        self.guild_id = guild_id

    async def on_submit(self, interaction: discord.Interaction):
        await self.cog.db.save_quick_reply(
            self.guild_id,
            self.shortcut_id.value.strip().lower(),
            self.label.value.strip(),
            self.message_content.value
        )
        await interaction.response.send_message(
            f"✅ บันทึกข้อความตอบกลับด่วน `{self.shortcut_id.value}` เรียบร้อยแล้ว",
            ephemeral=True
        )


class SetupView(discord.ui.View):
    def __init__(self, cog):
        super().__init__(timeout=300)
        self.cog = cog

        # เอา StaffRoleSelect ออกจากหน้าหลัก ให้เหลือแค่ Category และ Status Channel
        self.add_item(CategorySelect(cog))
        self.add_item(StatusChannelSelect(cog))

    @discord.ui.button(
        label="ดูสถานะ",
        emoji="📊",
        style=discord.ButtonStyle.secondary,
        row=2
    )
    async def status(self, interaction, button):
        if not interaction.guild:
            return

        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                "❌ เฉพาะ Administrator",
                ephemeral=True
            )
            return

        settings = await self.cog.db.get_settings(
            interaction.guild.id
        )

        if not settings:
            await interaction.response.send_message(
                "ยังไม่มีการตั้งค่า",
                ephemeral=True
            )
            return

        category = (
            interaction.guild.get_channel(settings["category_id"])
            if settings["category_id"]
            else None
        )

        role_ids = self.cog.get_staff_role_ids(settings)
        roles = [
            interaction.guild.get_role(rid) for rid in role_ids
            if interaction.guild.get_role(rid)
        ]

        status_channel = (
            interaction.guild.get_channel(
                settings["status_channel_id"]
            )
            if settings["status_channel_id"]
            else None
        )

        tickets = await self.cog.db.get_open_tickets(
            interaction.guild.id
        )

        embed = discord.Embed(
            title="📩 DM Support",
            description=(
                f"📁 Category: "
                f"{category.mention if category else '❌ ไม่ได้ตั้ง'}\n"
                f"👮 ยศคุมห้อง: "
                f"{' '.join(r.mention for r in roles) if roles else '❌ ไม่ได้ตั้ง'}\n"
                f"📊 ห้องนับ: "
                f"{status_channel.mention if status_channel else '❌ ไม่ได้ตั้ง'}\n"
                f"🔕 ข้อความปิด Ticket: "
                f"{'เปิด' if int(settings['close_dm_message'] or 0) else 'ปิด'}\n"
                f"📨 Ticket เปิดอยู่: `{len(tickets)}`"
            )
        )

        await interaction.response.send_message(
            embed=embed,
            ephemeral=True
        )

    @discord.ui.button(
        label="จัดการข้อความด่วน",
        emoji="⚡",
        style=discord.ButtonStyle.success,
        row=3
    )
    async def manage_quick_replies(self, interaction, button):
        if not interaction.guild or not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("❌ เฉพาะ Administrator", ephemeral=True)
            return

        modal = QuickReplyModal(self.cog, interaction.guild.id)
        await interaction.response.send_modal(modal)

    @discord.ui.button(
        label="เลือกยศคุมห้อง",
        emoji="👮",
        style=discord.ButtonStyle.primary,
        row=2
    )
    async def choose_staff_roles(self, interaction, button):
        if not interaction.guild:
            return
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                "❌ เฉพาะ Administrator", ephemeral=True
            )
            return

        view = discord.ui.View(timeout=120)
        view.add_item(StaffRoleSelect(self.cog))

        await interaction.response.send_message(
            "👮 **เลือกยศที่สามารถคุมห้อง Ticket / ตอบกลับ DM ได้**\n"
            "เลือกยศจากเมนูด้านล่างนี้ได้เลย",
            view=view,
            ephemeral=True
        )

    @discord.ui.button(
        label="โหลดข้อมูลเดิม",
        emoji="🔄",
        style=discord.ButtonStyle.primary,
        row=2
    )
    async def restore(self, interaction, button):
        if not interaction.guild:
            return

        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                "❌ เฉพาะ Administrator",
                ephemeral=True
            )
            return

        await self.cog.restore_existing_tickets()

        await interaction.response.send_message(
            "✅ โหลด Ticket เดิมกลับมาแล้ว\n"
            "ระบบจะใช้ห้องเดิมและไม่สร้างห้องซ้ำ",
            ephemeral=True
        )


class TicketControlView(discord.ui.View):
    def __init__(self, cog, quick_replies):
        super().__init__(timeout=None)
        self.cog = cog

        for qr in quick_replies[:5]:
            button = discord.ui.Button(
                label=qr["label"][:80],
                style=discord.ButtonStyle.secondary,
                custom_id=f"qr_{qr['shortcut_id']}"
            )
            button.callback = self.create_quick_reply_callback(qr["message"])
            self.add_item(button)

        close_button = discord.ui.Button(
            label="ปิด Ticket",
            emoji="🔒",
            style=discord.ButtonStyle.danger,
            custom_id="dm_support_close_ticket",
            row=4
        )
        close_button.callback = self.close_ticket_callback
        self.add_item(close_button)

    def create_quick_reply_callback(self, message_text):
        async def callback(interaction: discord.Interaction):
            if not interaction.guild:
                return

            settings = await self.cog.db.get_settings(interaction.guild.id)
            if not self.cog.is_staff(interaction.user, settings):
                await interaction.response.send_message("❌ คุณไม่มีสิทธิ์ใช้งานปุ่มนี้", ephemeral=True)
                return

            row = await self.cog.db.get_ticket_by_channel(interaction.channel.id)
            if not row or row["closed"]:
                await interaction.response.send_message("❌ ห้องนี้ไม่ใช่ Ticket ที่เปิดอยู่", ephemeral=True)
                return

            try:
                user = await self.cog.bot.fetch_user(row["user_id"])
                await user.send(message_text)
                await interaction.response.send_message(
                    f"📤 **ส่งข้อความด่วนสำเร็จ:**\n> {message_text}",
                    ephemeral=True
                )
            except Exception as e:
                await interaction.response.send_message(
                    f"❌ ไม่สามารถส่งข้อความหาผู้ใช้ได้ (อาจปิด DM อยู่): {e}",
                    ephemeral=True
                )

        return callback

    async def close_ticket_callback(self, interaction: discord.Interaction):
        if not interaction.guild:
            return

        settings = await self.cog.db.get_settings(interaction.guild.id)
        if not self.cog.is_staff(interaction.user, settings):
            await interaction.response.send_message("❌ คุณไม่มีสิทธิ์ปิด Ticket", ephemeral=True)
            return

        row = await self.cog.db.get_ticket_by_channel(interaction.channel.id)
        if not row:
            await interaction.response.send_message("❌ ห้องนี้ไม่ใช่ Ticket", ephemeral=True)
            return

        await self.cog.db.close_ticket(row["user_id"])
        await interaction.response.send_message("🔒 ปิด Ticket แล้ว กำลังลบห้อง...", ephemeral=True)
        await self.cog.update_status(interaction.guild)

        await asyncio.sleep(3)
        try:
            await interaction.channel.delete(reason="DM Support Ticket closed")
        except Exception:
            pass


# =========================================================
# COG / FEATURE
# =========================================================

class DMSupport(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.db = Database()
        self.ticket_locks = {}
        self.restore_lock = asyncio.Lock()
        self.restored_once = False

    async def cog_load(self):
        self.bot.add_view(TicketControlView(self, []))
        await self.restore_existing_tickets()
        print("[DM_SUPPORT] Feature loaded with Quick Replies")

    def get_staff_role_ids(self, settings):
        if not settings:
            return set()
        raw = settings["staff_role_ids"] or ""
        ids = set()
        for part in str(raw).split(","):
            part = part.strip()
            if part.isdigit():
                ids.add(int(part))
        old_id = settings["staff_role_id"]
        if old_id:
            ids.add(int(old_id))
        return ids

    def is_staff(self, member, settings):
        if member.guild_permissions.administrator:
            return True
        if not settings:
            return False
        role_ids = self.get_staff_role_ids(settings)
        return any(role.id in role_ids for role in member.roles)

    def make_ticket_name(self, user):
        safe = user.name.lower()
        safe = "".join(c if c.isalnum() or c in "-_" else "-" for c in safe)
        safe = safe.strip("-_")
        if not safe:
            safe = "user"
        return f"dm-{safe}-{user.id}"[:95]

    async def restore_existing_tickets(self):
        async with self.restore_lock:
            rows = await self.db.get_open_tickets()
            valid = 0
            invalid = 0
            for row in rows:
                guild = self.bot.get_guild(row["guild_id"])
                if not guild:
                    continue
                channel = guild.get_channel(row["channel_id"])
                if channel:
                    valid += 1
                else:
                    await self.db.close_ticket(row["user_id"])
                    invalid += 1
            self.restored_once = True

    async def get_existing_ticket(self, user_id):
        row = await self.db.get_ticket_by_user(user_id)
        if not row or row["closed"]:
            return None
        guild = self.bot.get_guild(row["guild_id"])
        if not guild:
            return None
        channel = guild.get_channel(row["channel_id"])
        if channel:
            return channel
        await self.db.close_ticket(user_id)
        return None

    async def get_configured_guild(self):
        for guild in self.bot.guilds:
            settings = await self.db.get_settings(guild.id)
            if not settings:
                continue
            category_id = settings["category_id"]
            if not category_id:
                continue
            category = guild.get_channel(category_id)
            if isinstance(category, discord.CategoryChannel):
                return guild, settings, category
        return None, None, None

    async def create_ticket(self, user):
        existing = await self.get_existing_ticket(user.id)
        if existing:
            return existing, None

        guild, settings, category = await self.get_configured_guild()
        if not guild:
            return None, "ยังไม่ได้ตั้ง Category สำหรับรับ DM"

        lock = self.ticket_locks.setdefault(user.id, asyncio.Lock())
        async with lock:
            existing = await self.get_existing_ticket(user.id)
            if existing:
                return existing, None

            overwrites = {
                guild.default_role: discord.PermissionOverwrite(view_channel=False),
                guild.me: discord.PermissionOverwrite(
                    view_channel=True,
                    send_messages=True,
                    read_message_history=True,
                    manage_channels=True
                )
            }

            for role_id in self.get_staff_role_ids(settings):
                role = guild.get_role(role_id)
                if role:
                    overwrites[role] = discord.PermissionOverwrite(
                        view_channel=True,
                        send_messages=True,
                        read_message_history=True
                    )

            try:
                channel = await guild.create_text_channel(
                    name=self.make_ticket_name(user),
                    category=category,
                    overwrites=overwrites,
                    reason="DM Support - New Ticket"
                )
            except Exception as e:
                return None, f"สร้างห้องไม่สำเร็จ: {e}"

            await self.db.save_ticket(
                user_id=user.id,
                guild_id=guild.id,
                channel_id=channel.id,
                username=str(user)
            )

            embed = discord.Embed(
                title="📩 DM Support",
                description=(
                    f"ผู้ติดต่อ: **{discord.utils.escape_markdown(user.name)}**\n"
                    f"User ID: `{user.id}`\n"
                    f"Username: `{user}`"
                ),
                timestamp=datetime.now(timezone.utc)
            )

            if user.avatar:
                embed.set_thumbnail(url=user.display_avatar.url)

            quick_replies = await self.db.get_quick_replies(guild.id)
            view = TicketControlView(self, quick_replies)

            try:
                await channel.send(embed=embed, view=view)
            except Exception:
                pass

            await self.update_status(guild)
            return channel, None

    async def update_status(self, guild):
        settings = await self.db.get_settings(guild.id)
        if not settings:
            return
        channel_id = settings["status_channel_id"]
        if not channel_id:
            return
        channel = guild.get_channel(channel_id)
        if not channel:
            return
        rows = await self.db.get_open_tickets(guild.id)
        try:
            await channel.edit(name=f"📩-DM-{len(rows)}-เรื่อง")
        except Exception:
            pass

    @app_commands.command(
        name="dmsetup",
        description="เปิด UI ตั้งค่าระบบรับและตอบ DM"
    )
    @app_commands.default_permissions(administrator=True)
    async def dmsetup(self, interaction):
        if not interaction.guild:
            await interaction.response.send_message("❌ ใช้ในเซิร์ฟเวอร์เท่านั้น", ephemeral=True)
            return

        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("❌ เฉพาะ Administrator", ephemeral=True)
            return

        embed = discord.Embed(
            title="📩 DM Support Control Panel",
            description=(
                "ตั้งค่าระบบรับ DM จาก UI\n\n"
                "📁 Category = ห้องของแต่ละคน\n"
                "👮 เลือกยศคุมห้อง = กำหนด Role ที่ตอบ DM ได้\n"
                "📊 ห้องนับ = จำนวน Ticket\n"
                "⚡ จัดการข้อความด่วน = ตั้งปุ่มส่งข้อความอัตโนมัติ"
            )
        )
        await interaction.response.send_message(embed=embed, view=SetupView(self), ephemeral=True)

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot:
            return

        if isinstance(message.channel, discord.DMChannel):
            first = await self.db.claim_message(message.id)
            if not first:
                return

            try:
                channel, error = await self.create_ticket(message.author)
                if error:
                    return

                embed = discord.Embed(
                    title="📨 ข้อความจากผู้ใช้",
                    description=message.content or "(ไม่มีข้อความ)",
                    timestamp=datetime.now(timezone.utc)
                )
                embed.set_author(
                    name=f"{message.author} | {message.author.id}",
                    icon_url=message.author.display_avatar.url
                )

                if message.attachments:
                    urls = "\n".join(a.url for a in message.attachments)
                    embed.add_field(name="📎 ไฟล์/รูป", value=urls[:1024], inline=False)

                await channel.send(embed=embed)
            except Exception:
                await self.db.release_message_claim(message.id)
                raise
            return

        if message.guild:
            row = await self.db.get_ticket_by_channel(message.channel.id)
            if not row or row["closed"]:
                return

            settings = await self.db.get_settings(message.guild.id)
            if not self.is_staff(message.author, settings):
                return

            first = await self.db.claim_message(message.id)
            if not first:
                return

            try:
                user = await self.bot.fetch_user(row["user_id"])
            except Exception:
                await self.db.release_message_claim(message.id)
                return

            sent_any = False
            if message.content:
                try:
                    await user.send(message.content)
                    sent_any = True
                except Exception:
                    pass

            if message.attachments:
                files = [await att.to_file() for att in message.attachments if hasattr(att, 'to_file')]
                if files:
                    try:
                        await user.send(files=files)
                        sent_any = True
                    except Exception:
                        pass

            if not sent_any:
                await self.db.release_message_claim(message.id)


async def setup(bot):
    existing = bot.get_cog("DMSupport")
    if existing is not None:
        return
    cog = DMSupport(bot)
    await bot.add_cog(cog)
    print("[DM_SUPPORT] setup(bot) OK with Quick Replies")
