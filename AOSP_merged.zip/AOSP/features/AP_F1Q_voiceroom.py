import discord
from discord.ext import commands
from discord import app_commands
import json
import os
import time

CONFIG_FILE = "voice_room_config.json"

# =========================================================
# JSON DATA MANAGEMENT (Multi-Server Support)
# =========================================================

def load_data():
    if not os.path.exists(CONFIG_FILE):
        return {}
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def save_data(data):
    try:
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
    except Exception as e:
        print(f"❌ บันทึกข้อมูลไม่สำเร็จ: {e}")


# =========================================================
# MAIN COG
# =========================================================

class VoiceRoom(commands.Cog):

    def __init__(self, bot):
        self.bot = bot
        self.data = load_data()
        self.start_time = time.time()

    def get_config(self, guild_id):
        guild_id = str(guild_id)

        if guild_id not in self.data:
            self.data[guild_id] = {
                "enabled": False,
                "create_channel_id": None,
                "category_id": None,
                "allowed_role_ids": [], 
                "name_format": "🔊 ห้องของ {user}",
                "default_limit": 0,
                "rooms": {},     
                "panels": {}     
            }
            save_data(self.data)

        if "allowed_role_ids" not in self.data[guild_id]:
            self.data[guild_id]["allowed_role_ids"] = []
            save_data(self.data)

        return self.data[guild_id]

    # =====================================================
    # บอทกลับมาออนไลน์ -> ลบห้องเสียงที่เคยสร้างทั้งหมด
    # =====================================================
    @commands.Cog.listener()
    async def on_ready(self):
        self.start_time = time.time()
        await self.clean_all_bot_rooms()

    async def clean_all_bot_rooms(self):
        print("🧹 บอทกลับมาทำงาน: กำลังล้างห้องเสียงทั้งหมดที่บอทเคยสร้างไว้...")
        total_cleaned_rooms = 0

        for guild in self.bot.guilds:
            config = self.get_config(guild.id)
            rooms = config.get("rooms", {})
            panels = config.get("panels", {})

            for room_id_str in list(rooms.keys()):
                try:
                    room_id = int(room_id_str)
                    room = guild.get_channel(room_id)
                    if room:
                        await room.delete(reason="ลบห้องค้างอัตโนมัติเมื่อบอทรีสตาร์ท")
                        total_cleaned_rooms += 1
                except Exception:
                    pass
                rooms.pop(room_id_str, None)

            for room_id_str in list(panels.keys()):
                panel = panels.pop(room_id_str, None)
                if panel:
                    try:
                        ch = guild.get_channel(panel["channel_id"])
                        if ch:
                            msg = await ch.fetch_message(panel["message_id"])
                            await msg.delete()
                    except Exception:
                        pass

            save_data(self.data)

        print(f"✅ ล้างระบบสำเร็จ — ลบห้องค้างทั้งหมดไป {total_cleaned_rooms} ห้อง")

    # =====================================================
    # COMMAND: /voice (ADMIN PANEL)
    # =====================================================
    @app_commands.command(
        name="voice",
        description="[แอดมิน] ตั้งค่าและจัดการระบบห้องเสียงอัตโนมัติ"
    )
    @app_commands.default_permissions(administrator=True)
    async def voice(self, interaction: discord.Interaction):
        if not interaction.guild:
            await interaction.response.send_message("❌ ใช้คำสั่งนี้ในเซิร์ฟเวอร์เท่านั้น", ephemeral=True)
            return

        config = self.get_config(interaction.guild.id)
        status_text = "🟢 เปิดใช้งาน" if config.get("enabled") else "🔴 ปิดใช้งาน"

        embed = discord.Embed(
            title="🎙️ ตั้งค่าและจัดการระบบห้องเสียงอัตโนมัติ",
            description=(
                f"**สถานะปัจจุบัน:** {status_text}\n"
                "เลือกตั้งค่าระบบหรือใช้ปุ่มควบคุมด้านล่างได้เลยครับ"
            ),
            color=discord.Color.blue()
        )

        await interaction.response.send_message(
            embed=embed,
            view=AdminPanel(self, interaction.guild.id),
            ephemeral=True
        )

    # =====================================================
    # VOICE STATE UPDATE
    # =====================================================
    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        try:
            guild = member.guild
            if not guild:
                return

            config = self.get_config(guild.id)
            if not config.get("enabled"):
                return

            create_channel_id = config.get("create_channel_id")
            rooms = config.get("rooms", {})

            # ---------- 1. เข้าห้องสร้างห้อง -> สร้างห้อง + ย้ายสมาชิกเข้า ----------
            if after.channel and after.channel.id == create_channel_id:
                category = guild.get_channel(config.get("category_id"))
                if not category or not isinstance(category, discord.CategoryChannel):
                    print(f"[{guild.name}] ไม่พบ Category หรือ ID Category ไม่ถูกต้อง")
                    return

                for r_id_str, o_id in list(rooms.items()):
                    if o_id == member.id:
                        old_room = guild.get_channel(int(r_id_str))
                        if old_room:
                            try:
                                await member.move_to(old_room)
                                return
                            except Exception:
                                pass

                name_format = config.get("name_format", "🔊 ห้องของ {user}")
                room_name = name_format.replace("{user}", member.display_name)

                # กำหนดสิทธิ์พื้นฐานขณะสร้างห้องทันที ( Override สิทธิ์กลางของ Category )
                overwrites = {
                    guild.default_role: discord.PermissionOverwrite(
                        connect=False,
                        view_channel=True
                    ),
                    member: discord.PermissionOverwrite(
                        connect=True,
                        view_channel=True,
                        speak=True,
                        manage_channels=True
                    ),
                    guild.me: discord.PermissionOverwrite(
                        connect=True,
                        view_channel=True,
                        manage_channels=True,
                        move_members=True,
                        send_messages=True
                    )
                }

                # เพิ่มยศที่อนุญาตเข้าลิสต์สิทธิ์
                allowed_role_ids = config.get("allowed_role_ids", [])
                for role_id in allowed_role_ids:
                    role = guild.get_role(role_id)
                    if role:
                        overwrites[role] = discord.PermissionOverwrite(
                            connect=True,
                            view_channel=True
                        )

                try:
                    room = await category.create_voice_channel(
                        name=room_name,
                        user_limit=config.get("default_limit", 0),
                        overwrites=overwrites,
                        reason=f"Temporary voice room for {member}"
                    )
                except discord.Forbidden:
                    print(f"[{guild.name}] สร้างห้องเสียงไม่สำเร็จ: บอทขาดสิทธิ์ Manage Channels ใน Category '{category.name}'")
                    return
                except Exception as e:
                    print(f"[{guild.name}] สร้างห้องเสียงไม่สำเร็จ:", e)
                    return

                config["rooms"][str(room.id)] = member.id
                save_data(self.data)

                # ย้ายผู้ใช้เข้าห้อง
                try:
                    await member.move_to(room)
                except discord.Forbidden:
                    print(f"[{guild.name}] ย้ายสมาชิกไม่สำเร็จ: ขาดสิทธิ์ 'Move Members'")
                except Exception as e:
                    print(f"[{guild.name}] ย้ายสมาชิกเข้าห้องไม่สำเร็จ:", e)

                # ส่งแผงควบคุม
                try:
                    view = OwnerRoomPanel(self, room.id, member.id)
                    msg = await room.send(
                        content=(
                            f"🎉 **สร้างห้อง 🔊 {room.name} ให้ {member.mention} เรียบร้อยแล้ว!**\n"
                            f"จัดการห้องของคุณด้วยปุ่มด้านล่างได้เลย:"
                        ),
                        view=view
                    )

                    config["panels"][str(room.id)] = {
                        "channel_id": room.id,
                        "message_id": msg.id
                    }
                    save_data(self.data)
                except Exception as e:
                    print(f"[{guild.name}] ส่งเมนูเข้าห้อง Voice ไม่สำเร็จ:", e)

            # ---------- 2. ออกจากห้อง -> ลบห้องอัตโนมัติเมื่อสมาชิกคนสุดท้ายออก ----------
            if before.channel and str(before.channel.id) in rooms:
                old_room = guild.get_channel(before.channel.id)

                if old_room and len(old_room.members) == 0:
                    panels = config.get("panels", {})
                    panel = panels.pop(str(old_room.id), None)
                    if panel:
                        try:
                            ch = guild.get_channel(panel["channel_id"])
                            if ch:
                                msg = await ch.fetch_message(panel["message_id"])
                                await msg.delete()
                        except Exception:
                            pass

                    try:
                        await old_room.delete(reason="ไม่มีคนอยู่ในห้อง ลบห้องอัตโนมัติ")
                    except Exception as e:
                        print(f"[{guild.name}] ลบห้องเสียงไม่สำเร็จ:", e)

                    config["rooms"].pop(str(old_room.id), None)
                    save_data(self.data)

        except Exception as global_e:
            print(f"⚠️ เกิดข้อผิดพลาดในระบบ Voice State Update: {global_e}")


# =========================================================
# ADMIN PANEL
# =========================================================

class AdminPanel(discord.ui.View):

    def __init__(self, cog, guild_id):
        super().__init__(timeout=300)
        self.cog = cog
        self.guild_id = guild_id

    @discord.ui.select(
        cls=discord.ui.ChannelSelect,
        channel_types=[discord.ChannelType.voice],
        placeholder="🎙️ เลือกห้องสร้างห้อง (Voice Channel)",
        row=0
    )
    async def create_channel_select(self, interaction, select):
        channel = select.values[0]
        config = self.cog.get_config(self.guild_id)
        config["create_channel_id"] = channel.id
        save_data(self.cog.data)

        await interaction.response.send_message(f"✅ บันทึกห้องสร้างแล้ว: {channel.mention}", ephemeral=True)

    @discord.ui.select(
        cls=discord.ui.ChannelSelect,
        channel_types=[discord.ChannelType.category],
        placeholder="📁 เลือกหมวดหมู่ (Category) ปลายทาง",
        row=1
    )
    async def category_select(self, interaction, select):
        category = select.values[0]
        config = self.cog.get_config(self.guild_id)
        config["category_id"] = category.id
        save_data(self.cog.data)

        await interaction.response.send_message(f"✅ บันทึก Category แล้ว: **{category.name}**", ephemeral=True)

    @discord.ui.select(
        cls=discord.ui.RoleSelect,
        placeholder="🎖️ เลือกยศที่อนุญาตให้เข้าห้องได้ (เลือกได้หลายยศ)",
        min_values=1,
        max_values=25,
        row=2
    )
    async def allowed_roles_select(self, interaction: discord.Interaction, select: discord.ui.RoleSelect):
        selected_roles = select.values
        config = self.cog.get_config(self.guild_id)
        
        config["allowed_role_ids"] = [role.id for role in selected_roles]
        save_data(self.cog.data)

        roles_mentions = ", ".join([role.mention for role in selected_roles])
        await interaction.response.send_message(f"✅ อัปเดตยศที่ได้รับอนุญาตแล้ว: {roles_mentions}", ephemeral=True)

    @discord.ui.button(label="เปิดระบบ", emoji="▶️", style=discord.ButtonStyle.success, row=3)
    async def enable(self, interaction, button):
        config = self.cog.get_config(self.guild_id)
        if not config.get("create_channel_id") or not config.get("category_id"):
            await interaction.response.send_message("❌ กรุณาเลือกห้องสร้างและ Category ให้ครบก่อนเปิดระบบ", ephemeral=True)
            return

        config["enabled"] = True
        save_data(self.cog.data)
        await interaction.response.send_message("🟢 **เปิดใช้งานระบบห้องเสียงอัตโนมัติแล้ว**", ephemeral=True)

    @discord.ui.button(label="ปิดระบบ", emoji="⏹️", style=discord.ButtonStyle.danger, row=3)
    async def disable(self, interaction, button):
        config = self.cog.get_config(self.guild_id)
        config["enabled"] = False
        save_data(self.cog.data)
        await interaction.response.send_message("🔴 **ปิดใช้งานระบบห้องเสียงอัตโนมัติแล้ว**", ephemeral=True)

    @discord.ui.button(label="⚙️ จัดการห้อง", style=discord.ButtonStyle.primary, row=3)
    async def manage_rooms(self, interaction: discord.Interaction, button: discord.ui.Button):
        config = self.cog.get_config(self.guild_id)
        active_rooms = config.get("rooms", {})

        if not active_rooms:
            await interaction.response.send_message("ℹ️ ขณะนี้ไม่มีห้องเสียงที่ถูกสร้างโดยบอทในเซิร์ฟเวอร์นี้", ephemeral=True)
            return

        options = []
        for r_id_str, o_id in list(active_rooms.items()):
            ch = interaction.guild.get_channel(int(r_id_str))
            owner = interaction.guild.get_member(o_id)
            ch_name = ch.name if ch else "⚠️ ห้องนี้ถูกลบไปแล้ว"
            owner_name = owner.display_name if owner else f"ID: {o_id}"

            options.append(
                discord.SelectOption(
                    label=f"{ch_name[:25]}",
                    description=f"เจ้าของ: {owner_name}",
                    value=str(r_id_str)
                )
            )

        view = AdminManageRoomsView(self.cog, options)
        await interaction.response.send_message("⚙️ **เลือกห้องที่ต้องการสั่งลบทันที:**", view=view, ephemeral=True)

    @discord.ui.button(label="🔄 รีเฟรช", style=discord.ButtonStyle.secondary, row=4)
    async def refresh(self, interaction: discord.Interaction, button: discord.ui.Button):
        config = self.cog.get_config(self.guild_id)
        status_text = "🟢 เปิดใช้งาน" if config.get("enabled") else "🔴 ปิดใช้งาน"

        embed = discord.Embed(
            title="🎙️ ตั้งค่าและจัดการระบบห้องเสียงอัตโนมัติ (อัปเดตแล้ว)",
            description=f"**สถานะปัจจุบัน:** {status_text}",
            color=discord.Color.blue()
        )
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(label="📊 ดูสถานะ", style=discord.ButtonStyle.secondary, row=4)
    async def status_info(self, interaction: discord.Interaction, button: discord.ui.Button):
        config = self.cog.get_config(self.guild_id)

        status_str = "🟢 เปิดใช้งาน" if config.get("enabled") else "🔴 ปิดใช้งาน"
        create_ch = interaction.guild.get_channel(config.get("create_channel_id"))
        category_ch = interaction.guild.get_channel(config.get("category_id"))
        allowed_roles = [interaction.guild.get_role(rid) for rid in config.get("allowed_role_ids", []) if interaction.guild.get_role(rid)]
        roles_str = ", ".join([r.mention for r in allowed_roles]) if allowed_roles else "ไม่ได้ตั้งค่า"
        active_rooms_count = len(config.get("rooms", {}))

        embed = discord.Embed(
            title=f"📊 สถานะระบบห้องเสียง - {interaction.guild.name}",
            color=discord.Color.green()
        )
        embed.add_field(name="สถานะระบบ", value=status_str, inline=False)
        embed.add_field(name="ห้องสำหรับกดสร้าง", value=create_ch.mention if create_ch else "ยังไม่ได้ตั้งค่า", inline=True)
        embed.add_field(name="Category ปลายทาง", value=category_ch.name if category_ch else "ยังไม่ได้ตั้งค่า", inline=True)
        embed.add_field(name="ยศที่อนุญาตเชื่อมต่อ", value=roles_str, inline=False)
        embed.add_field(name="ห้องที่เปิดใช้งานอยู่", value=f"{active_rooms_count} ห้อง", inline=False)

        await interaction.response.send_message(embed=embed, ephemeral=True)

    @discord.ui.button(label="⚡ อัปเดตคำสั่ง", style=discord.ButtonStyle.secondary, row=4)
    async def sync_commands(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        try:
            synced = await self.cog.bot.tree.sync(guild=interaction.guild)
            await interaction.followup.send(f"✅ ซิงค์ Slash Commands สำหรับเซิร์ฟเวอร์นี้สำเร็จ ({len(synced)} คำสั่ง)", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"❌ เกิดข้อผิดพลาดในการซิงค์คำสั่ง: {e}", ephemeral=True)

    @discord.ui.button(label="💾 บันทึกการตั้งค่า", style=discord.ButtonStyle.success, row=4)
    async def save_config(self, interaction: discord.Interaction, button: discord.ui.Button):
        save_data(self.cog.data)
        await interaction.response.send_message("💾 **บันทึกการตั้งค่าทั้งหมดเรียบร้อยแล้ว!**", ephemeral=True)


# =========================================================
# ADMIN ROOM MANAGEMENT VIEW
# =========================================================

class AdminManageRoomsView(discord.ui.View):

    def __init__(self, cog, options):
        super().__init__(timeout=180)
        self.cog = cog

        select = discord.ui.Select(
            placeholder="🗑️ เลือกห้องที่ต้องการสั่งลบทันที...",
            options=options[:25]
        )
        select.callback = self.select_callback
        self.add_item(select)

    async def select_callback(self, interaction: discord.Interaction):
        room_id_str = interaction.data["values"][0]
        room_id = int(room_id_str)
        config = self.cog.get_config(interaction.guild.id)
        room = interaction.guild.get_channel(room_id)

        panels = config.get("panels", {})
        panel = panels.pop(room_id_str, None)
        if panel:
            try:
                ch = interaction.guild.get_channel(panel["channel_id"])
                if ch:
                    msg = await ch.fetch_message(panel["message_id"])
                    await msg.delete()
            except Exception:
                pass

        if room:
            try:
                await room.delete(reason="แอดมินสั่งลบจากแผงจัดการ")
            except Exception as e:
                await interaction.response.send_message(f"❌ เกิดข้อผิดพลาดขณะลบห้อง: {e}", ephemeral=True)
                return

        config["rooms"].pop(room_id_str, None)
        save_data(self.cog.data)

        await interaction.response.send_message(f"✅ สั่งลบห้อง ID `{room_id_str}` เรียบร้อยแล้ว", ephemeral=True)


# =========================================================
# OWNER ROOM PANEL (แผงควบคุมห้องของผู้ใช้งาน)
# =========================================================

class OwnerRoomPanel(discord.ui.View):

    def __init__(self, cog, room_id, owner_id):
        super().__init__(timeout=None)
        self.cog = cog
        self.room_id = room_id
        self.owner_id = owner_id

    async def interaction_check(self, interaction: discord.Interaction):
        if interaction.user.id != self.owner_id and not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("❌ คุณไม่ใช่เจ้าของห้องนี้", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="ตั้งชื่อห้อง", emoji="✏️", style=discord.ButtonStyle.primary, row=0)
    async def rename(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(RenameModal(self.cog, self.room_id))

    @discord.ui.button(label="จำกัดคนเข้า", emoji="👥", style=discord.ButtonStyle.primary, row=0)
    async def limit(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(LimitModal(self.cog, self.room_id))

    @discord.ui.button(label="ล็อกห้อง", emoji="🔐", style=discord.ButtonStyle.danger, row=1)
    async def lock(self, interaction: discord.Interaction, button: discord.ui.Button):
        room = interaction.guild.get_channel(self.room_id)
        if not room:
            await interaction.response.send_message("❌ ไม่พบห้อง", ephemeral=True)
            return
        try:
            await room.set_permissions(interaction.guild.default_role, connect=False)
            await interaction.response.send_message("🔐 ล็อกห้องเรียบร้อยแล้ว", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ ล็อกห้องไม่สำเร็จ: {e}", ephemeral=True)

    @discord.ui.button(label="ปลดล็อก", emoji="🔓", style=discord.ButtonStyle.success, row=1)
    async def unlock(self, interaction: discord.Interaction, button: discord.ui.Button):
        room = interaction.guild.get_channel(self.room_id)
        if not room:
            await interaction.response.send_message("❌ ไม่พบห้อง", ephemeral=True)
            return
        try:
            await room.set_permissions(interaction.guild.default_role, connect=True)
            await interaction.response.send_message("🔓 ปลดล็อกห้องให้ทุกคนเข้าได้แล้ว", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ ปลดล็อกไม่สำเร็จ: {e}", ephemeral=True)

    @discord.ui.button(label="เลือกคนเข้าถึง", emoji="👤", style=discord.ButtonStyle.secondary, row=2)
    async def allow_user(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(
            "👤 **เลือกสมาชิกที่ต้องการให้อนุญาตเข้าห้องนี้:**",
            view=UserPermissionPanel(self.cog, self.room_id),
            ephemeral=True
        )

    @discord.ui.button(label="ลบห้อง", emoji="🗑️", style=discord.ButtonStyle.danger, row=2)
    async def delete_room(self, interaction: discord.Interaction, button: discord.ui.Button):
        config = self.cog.get_config(interaction.guild.id)
        room = interaction.guild.get_channel(self.room_id)

        room_id_str = str(self.room_id)

        panels = config.get("panels", {})
        panels.pop(room_id_str, None)

        if room:
            try:
                await room.delete(reason="เจ้าของสั่งลบห้อง")
            except Exception:
                pass

        config["rooms"].pop(room_id_str, None)
        save_data(self.cog.data)
        await interaction.response.send_message("🗑️ ลบห้องเสียงของคุณเรียบร้อยแล้ว", ephemeral=True)


# =========================================================
# MODALS & PERMISSION PANELS
# =========================================================

class RenameModal(discord.ui.Modal):

    def __init__(self, cog, room_id):
        super().__init__(title="✏️ ตั้งชื่อห้อง")
        self.cog = cog
        self.room_id = room_id

        self.name_input = discord.ui.TextInput(
            label="ชื่อห้องใหม่",
            placeholder="เช่น 🔊 ห้องนั่งเล่น",
            max_length=100,
            required=True
        )
        self.add_item(self.name_input)

    async def on_submit(self, interaction: discord.Interaction):
        room = interaction.guild.get_channel(self.room_id)
        if not room:
            await interaction.response.send_message("❌ ไม่พบห้องในระบบ", ephemeral=True)
            return

        name = self.name_input.value.strip()
        try:
            await room.edit(name=name)
            await interaction.response.send_message(f"✅ เปลี่ยนชื่อห้องเป็น **{name}** แล้ว", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ เปลี่ยนชื่อห้องไม่สำเร็จ: {e}", ephemeral=True)


class LimitModal(discord.ui.Modal):

    def __init__(self, cog, room_id):
        super().__init__(title="👥 จำกัดคนเข้าห้อง")
        self.cog = cog
        self.room_id = room_id

        self.limit_input = discord.ui.TextInput(
            label="จำนวนคน (ใส่ 0 = ไม่จำกัด)",
            placeholder="ใส่ตัวเลข 0 ถึง 99",
            max_length=2,
            required=True
        )
        self.add_item(self.limit_input)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            limit = int(self.limit_input.value)
        except ValueError:
            await interaction.response.send_message("❌ กรุณากรอกตัวเลขเท่านั้น", ephemeral=True)
            return

        if limit < 0 or limit > 99:
            await interaction.response.send_message("❌ กรุณากรอกตัวเลขระหว่าง 0–99", ephemeral=True)
            return

        room = interaction.guild.get_channel(self.room_id)
        if not room:
            await interaction.response.send_message("❌ ไม่พบห้องในระบบ", ephemeral=True)
            return

        await room.edit(user_limit=limit)
        msg = "✅ **ยกเลิกจำกัดจำนวนคนแล้ว**" if limit == 0 else f"✅ จำกัดจำนวนคนไว้ที่ **{limit} คน** เรียบร้อย"
        await interaction.response.send_message(msg, ephemeral=True)


class UserPermissionPanel(discord.ui.View):

    def __init__(self, cog, room_id):
        super().__init__(timeout=180)
        self.cog = cog
        self.room_id = room_id

    @discord.ui.select(
        cls=discord.ui.UserSelect,
        placeholder="👤 เลือกคนที่ต้องการให้อนุญาตเข้าห้อง"
    )
    async def user_select(self, interaction: discord.Interaction, select: discord.ui.UserSelect):
        room = interaction.guild.get_channel(self.room_id)
        if not room:
            await interaction.response.send_message("❌ ไม่พบห้องในระบบ", ephemeral=True)
            return

        target_user = select.values[0]
        try:
            await room.set_permissions(target_user, view_channel=True, connect=True, speak=True)
            await interaction.response.send_message(f"✅ อนุญาตให้ {target_user.mention} เข้าห้องนี้ได้แล้ว", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ ตั้งสิทธิ์ไม่สำเร็จ: {e}", ephemeral=True)


# =========================================================
# SETUP
# =========================================================

async def setup(bot):
    await bot.add_cog(VoiceRoom(bot))
