import os
import json
from datetime import datetime, timezone
import discord
from discord import app_commands

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
AUDIT_FILE = os.path.join(DATA_DIR, "security_audit.log")
DATA_FILE = os.path.join(DATA_DIR, "role_button.json")
os.makedirs(DATA_DIR, exist_ok=True)

DEFAULT_CONFIG = {"enabled": False, "channel_id": None, "role_id": None, "message": "กดปุ่มด้านล่างเพื่อรับยศ", "image_url": None, "button_label": "รับยศ", "emoji": None, "panel_message_id": None, "panel_channel_id": None, "config_message_id": None, "config_channel_id": None}

def load_data():
    if not os.path.exists(DATA_FILE): return {}
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f: return json.load(f)
    except Exception: return {}

def save_data(data):
    tmp_file = DATA_FILE + ".tmp"
    with open(tmp_file, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)
    os.replace(tmp_file, DATA_FILE)

def audit(guild_id, user_id, action):
    try:
        now = datetime.now(timezone.utc).isoformat(timespec="seconds")
        with open(AUDIT_FILE, "a", encoding="utf-8") as f:
            f.write(f"{now} guild={guild_id} user={user_id} action={action}\n")
    except OSError:
        pass
def get_config(guild_id):
    data = load_data(); gid = str(guild_id); changed = False
    if gid not in data: data[gid] = DEFAULT_CONFIG.copy(); changed = True
    else:
        for k, v in DEFAULT_CONFIG.items():
            if k not in data[gid]: data[gid][k] = v; changed = True
    if changed: save_data(data)
    return data[gid]

def update_config(guild_id, key, value):
    data = load_data(); gid = str(guild_id)
    if gid not in data: data[gid] = DEFAULT_CONFIG.copy()
    data[gid][key] = value; save_data(data)

def can_manage(interaction):
    if interaction.guild is None or interaction.user is None: return False
    member = interaction.guild.get_member(interaction.user.id)
    if member is None: return False
    p = member.guild_permissions
    return member.id == interaction.guild.owner_id or p.administrator or p.manage_guild

def parse_emoji(value):
    if not value: return None
    value = value.strip()
    if value.startswith("<a:") and value.endswith(">"):
        try:
            name, eid = value[3:-1].rsplit(":", 1); return discord.PartialEmoji(name=name, id=int(eid), animated=True)
        except Exception: return None
    if value.startswith("<:") and value.endswith(">"):
        try:
            name, eid = value[2:-1].rsplit(":", 1); return discord.PartialEmoji(name=name, id=int(eid), animated=False)
        except Exception: return None
    return value

def make_config_embed(guild_id):
    c = get_config(guild_id); ch = f"<#{c['channel_id']}>" if c.get("channel_id") else "ยังไม่ได้ตั้ง"; role = f"<@&{c['role_id']}>" if c.get("role_id") else "ยังไม่ได้ตั้ง"; status = "🟢 เปิด" if c.get("enabled") else "🔴 ปิด"
    return discord.Embed(title="🎖️ ตั้งค่าระบบกดปุ่มรับยศ", description=f"สถานะ: **{status}**\nห้องแผง: {ch}\nยศ: {role}\nปุ่ม: **{c.get('button_label','รับยศ')}**\nข้อความ: {c.get('message','')}\nรูป: {'มี' if c.get('image_url') else 'ไม่มี'}\n\nใช้ปุ่มด้านล่างแก้ไขได้ทั้งหมด", color=discord.Color.blurple())

def make_role_embed(guild_id):
    c = get_config(guild_id); embed = discord.Embed(title="🎖️ รับยศ", description=c.get("message") or "กดปุ่มด้านล่างเพื่อรับยศ", color=discord.Color.blurple())
    if c.get("image_url"): embed.set_image(url=c["image_url"])
    return embed

class ClaimButton(discord.ui.Button):
    def __init__(self, guild_id):
        c = get_config(guild_id); super().__init__(label=c.get("button_label") or "รับยศ", style=discord.ButtonStyle.success, emoji=parse_emoji(c.get("emoji")), custom_id=f"role_claim_{guild_id}")
        self.guild_id = guild_id
    async def callback(self, interaction):
        c = get_config(interaction.guild.id)
        if not c.get("enabled"): await interaction.response.send_message("❌ ระบบรับยศถูกปิดอยู่", ephemeral=True); return
        role = interaction.guild.get_role(int(c["role_id"])) if c.get("role_id") else None; me = interaction.guild.me
        if role is None or me is None or role >= me.top_role: await interaction.response.send_message("❌ บอทไม่สามารถให้ยศนี้ได้", ephemeral=True); return
        if role in interaction.user.roles: await interaction.response.send_message("ℹ️ คุณมียศนี้อยู่แล้ว", ephemeral=True); return
        try:
            await interaction.user.add_roles(role, reason="กดปุ่มรับยศ"); await interaction.response.send_message(f"✅ รับยศ {role.mention} สำเร็จ!", ephemeral=True)
        except discord.Forbidden: await interaction.response.send_message("❌ บอทไม่มีสิทธิ์ให้ยศนี้", ephemeral=True)
        except discord.HTTPException: await interaction.response.send_message("❌ Discord ไม่ตอบสนอง", ephemeral=True)

class RoleClaimView(discord.ui.View):
    def __init__(self, guild_id):
        super().__init__(timeout=None); self.add_item(ClaimButton(guild_id))

class ChannelSelect(discord.ui.ChannelSelect):
    def __init__(self):
        super().__init__(placeholder="เลือกห้องแผงรับยศ", channel_types=[discord.ChannelType.text, discord.ChannelType.news], min_values=1, max_values=1, custom_id="role_button_channel_select", row=0)
    async def callback(self, interaction):
        if not can_manage(interaction): await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        ch = self.values[0]; update_config(interaction.guild.id, "channel_id", ch.id); audit(interaction.guild.id, interaction.user.id, "F3 set_channel"); await interaction.response.send_message(f"✅ ตั้งห้องเป็น {ch.mention}", ephemeral=True)

class RoleSelect(discord.ui.RoleSelect):
    def __init__(self):
        super().__init__(placeholder="เลือกยศที่จะให้", min_values=1, max_values=1, custom_id="role_button_role_select", row=1)
    async def callback(self, interaction):
        if not can_manage(interaction): await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        role = self.values[0]; me = interaction.guild.me
        if me is None or role >= me.top_role: await interaction.response.send_message("❌ ยศนี้สูงกว่ายศบอท", ephemeral=True); return
        update_config(interaction.guild.id, "role_id", role.id); audit(interaction.guild.id, interaction.user.id, "F3 set_role"); await interaction.response.send_message(f"✅ ตั้งยศเป็น {role.mention}", ephemeral=True)

class MessageModal(discord.ui.Modal, title="แก้ไขข้อความ"):
    value = discord.ui.TextInput(label="ข้อความ", style=discord.TextStyle.paragraph, required=True, max_length=4000)
    async def on_submit(self, interaction):
        if not can_manage(interaction): await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        update_config(interaction.guild.id, "message", self.value.value); audit(interaction.guild.id, interaction.user.id, "F3 set_message"); await interaction.response.send_message("✅ บันทึกข้อความแล้ว", ephemeral=True)

class ImageModal(discord.ui.Modal, title="แก้ไขรูป / GIF"):
    value = discord.ui.TextInput(label="URL รูป/GIF", placeholder="https://...", required=False, max_length=1000)
    async def on_submit(self, interaction):
        if not can_manage(interaction): await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        url = self.value.value.strip() or None
        if url and not url.startswith(("http://", "https://")): await interaction.response.send_message("❌ URL ไม่ถูกต้อง", ephemeral=True); return
        update_config(interaction.guild.id, "image_url", url); audit(interaction.guild.id, interaction.user.id, "F3 set_image"); await interaction.response.send_message("✅ บันทึกรูปแล้ว", ephemeral=True)

class ButtonModal(discord.ui.Modal, title="แก้ไขปุ่ม"):
    label = discord.ui.TextInput(label="ข้อความบนปุ่ม", placeholder="รับยศ", required=True, max_length=80)
    emoji = discord.ui.TextInput(label="Emoji", placeholder="🎖️ หรือ <:ชื่อ:ID> หรือ <a:ชื่อ:ID>", required=False, max_length=100)
    async def on_submit(self, interaction):
        if not can_manage(interaction): await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        label = self.label.value.strip(); emoji = self.emoji.value.strip() or None
        if not label: await interaction.response.send_message("❌ ชื่อปุ่มห้ามว่าง", ephemeral=True); return
        if emoji and parse_emoji(emoji) is None: await interaction.response.send_message("❌ Emoji ไม่ถูกต้อง", ephemeral=True); return
        update_config(interaction.guild.id, "button_label", label); update_config(interaction.guild.id, "emoji", emoji); audit(interaction.guild.id, interaction.user.id, "F3 set_button"); await interaction.response.send_message("✅ บันทึกปุ่มแล้ว", ephemeral=True)

async def update_role_panel(bot, guild_id):
    c = get_config(guild_id); mid, cid = c.get("panel_message_id"), c.get("panel_channel_id")
    if not mid or not cid: return False, "ยังไม่มีแผงรับยศที่บันทึกไว้"
    guild = bot.get_guild(int(guild_id)); channel = guild.get_channel(int(cid)) if guild else None
    if not channel: return False, "ไม่พบห้องแผง"
    try:
        msg = await channel.fetch_message(int(mid)); await msg.edit(embed=make_role_embed(guild_id), view=RoleClaimView(guild_id)); return True, "อัปเดทแผงรับยศเดิมแล้ว"
    except discord.NotFound: return False, "แผงรับยศเดิมถูกลบแล้ว"
    except discord.Forbidden: return False, "บอทไม่มีสิทธิ์แก้ข้อความ"
    except discord.HTTPException as e: return False, f"Discord Error: {e}"

async def update_config_panel(bot, guild_id):
    c = get_config(guild_id); mid, cid = c.get("config_message_id"), c.get("config_channel_id")
    if not mid or not cid: return False, "ยังไม่มีแผงตั้งค่าที่บันทึกไว้"
    guild = bot.get_guild(int(guild_id)); channel = guild.get_channel(int(cid)) if guild else None
    if not channel: return False, "ไม่พบห้องแผงตั้งค่า"
    try:
        msg = await channel.fetch_message(int(mid)); await msg.edit(embed=make_config_embed(guild_id), view=RoleButtonConfigView()); return True, "อัปเดทแผงตั้งค่าแล้ว"
    except discord.NotFound: return False, "แผงตั้งค่าถูกลบแล้ว"
    except discord.Forbidden: return False, "บอทไม่มีสิทธิ์แก้ข้อความ"
    except discord.HTTPException as e: return False, f"Discord Error: {e}"

class RoleButtonConfigView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None); self.add_item(ChannelSelect()); self.add_item(RoleSelect())
    @discord.ui.button(label="✏️ แก้ข้อความ", style=discord.ButtonStyle.primary, custom_id="role_config_message", row=2)
    async def message(self, interaction, button):
        if not can_manage(interaction): await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        await interaction.response.send_modal(MessageModal())
    @discord.ui.button(label="🖼️ แก้รูป/GIF", style=discord.ButtonStyle.primary, custom_id="role_config_image", row=2)
    async def image(self, interaction, button):
        if not can_manage(interaction): await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        await interaction.response.send_modal(ImageModal())
    @discord.ui.button(label="🔘 แก้ปุ่ม", style=discord.ButtonStyle.secondary, custom_id="role_config_button", row=2)
    async def button_edit(self, interaction, button):
        if not can_manage(interaction): await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        await interaction.response.send_modal(ButtonModal())
    @discord.ui.button(label="🟢 เปิดระบบ", style=discord.ButtonStyle.success, custom_id="role_config_enable", row=3)
    async def enable(self, interaction, button):
        if not can_manage(interaction): await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        c = get_config(interaction.guild.id)
        if not c.get("channel_id") or not c.get("role_id"): await interaction.response.send_message("❌ เลือกห้องและยศก่อน", ephemeral=True); return
        update_config(interaction.guild.id, "enabled", True); audit(interaction.guild.id, interaction.user.id, "F3 enabled"); await interaction.response.send_message("🟢 เปิดระบบแล้ว", ephemeral=True)
    @discord.ui.button(label="🔴 ปิดระบบ", style=discord.ButtonStyle.danger, custom_id="role_config_disable", row=3)
    async def disable(self, interaction, button):
        if not can_manage(interaction): await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        update_config(interaction.guild.id, "enabled", False); audit(interaction.guild.id, interaction.user.id, "F3 disabled"); await interaction.response.send_message("🔴 ปิดระบบแล้ว", ephemeral=True)
    @discord.ui.button(label="📤 ส่งแผงรับยศใหม่", style=discord.ButtonStyle.secondary, custom_id="role_config_send", row=4)
    async def send_panel(self, interaction, button):
        if not can_manage(interaction): await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        c = get_config(interaction.guild.id); ch = interaction.guild.get_channel(int(c["channel_id"])) if c.get("channel_id") else None
        if not ch or not c.get("role_id"): await interaction.response.send_message("❌ เลือกห้องและยศก่อน", ephemeral=True); return
        try:
            msg = await ch.send(embed=make_role_embed(interaction.guild.id), view=RoleClaimView(interaction.guild.id)); update_config(interaction.guild.id, "panel_message_id", msg.id); update_config(interaction.guild.id, "panel_channel_id", ch.id)
            await interaction.response.send_message("✅ ส่งแผงรับยศใหม่แล้ว", ephemeral=True)
        except discord.Forbidden: await interaction.response.send_message("❌ บอทไม่มีสิทธิ์ส่งข้อความ", ephemeral=True)
    @discord.ui.button(label="🔄 อัปเดทแผงทั้งหมด", style=discord.ButtonStyle.primary, custom_id="role_config_update_all", row=4)
    async def update_all(self, interaction, button):
        if not can_manage(interaction): await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        await interaction.response.defer(ephemeral=True)
        a, ta = await update_config_panel(interaction.client, interaction.guild.id); b, tb = await update_role_panel(interaction.client, interaction.guild.id)
        await interaction.followup.send(f"{'✅' if a else '❌'} {ta}\n{'✅' if b else '❌'} {tb}", ephemeral=True)

def setup(bot):
    @bot.tree.command(name="rolebutton", description="ตั้งค่าระบบกดปุ่มรับยศ")
    async def rolebutton(interaction):
        if not can_manage(interaction): await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        msg = await interaction.channel.send(embed=make_config_embed(interaction.guild.id), view=RoleButtonConfigView())
        update_config(interaction.guild.id, "config_message_id", msg.id); update_config(interaction.guild.id, "config_channel_id", interaction.channel.id)
        await interaction.response.send_message("✅ สร้างแผงตั้งค่าแล้ว", ephemeral=True)
    bot.add_view(RoleButtonConfigView())
    data = load_data()
    for gid, c in data.items():
        if c.get("panel_message_id") and c.get("panel_channel_id"):
            try: bot.add_view(RoleClaimView(int(gid)))
            except Exception as e: print(f"⚠️ โหลดแผง F3 ของ {gid} ไม่สำเร็จ: {e}")
    print("✅ F3 Persistent Views โหลดแล้ว")
