import os
import json
import discord

# =========================================================
# F3 - ระบบลาก่อน (Goodbye)
# สำหรับ Public Bot / หลาย Server
# =========================================================

COMMAND_NAME = "goodbye"

DATA_FILE = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "goodbye_data.json"
)


# =========================================================
# โหลด / บันทึกข้อมูล
# =========================================================

def load_data():
    if not os.path.exists(DATA_FILE):
        return {}

    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)

        if isinstance(data, dict):
            return data

    except Exception as e:
        print(f"❌ อ่าน goodbye_data.json ไม่ได้: {e}")

    return {}


def save_data():
    try:
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(
                data,
                f,
                ensure_ascii=False,
                indent=2
            )

    except Exception as e:
        print(f"❌ บันทึก goodbye_data.json ไม่ได้: {e}")


data = load_data()


def get_guild_data(guild_id):
    guild_id = str(guild_id)

    if guild_id not in data:
        data[guild_id] = {
            "channel_id": None,
            "message": "👋 ลาก่อน {user} ขอบคุณที่เคยอยู่กับ {server}",
            "media_url": None,
            "enabled": False
        }

    return data[guild_id]


def is_manager(member):
    return (
        member.guild_permissions.manage_guild
        or member.guild_permissions.administrator
    )


# =========================================================
# แทนค่าข้อความ
# =========================================================

def replace_text(text, member):

    member_count = member.guild.member_count

    if member_count is None:
        member_count = "ไม่ทราบ"

    return (
        text
        .replace("{user}", str(member))
        .replace("{server}", member.guild.name)
        .replace("{member_count}", str(member_count))
    )


# =========================================================
# Modal ตั้งข้อความ
# =========================================================

class GoodbyeMessageModal(
    discord.ui.Modal,
    title="ตั้งข้อความลาก่อน"
):

    message = discord.ui.TextInput(
        label="ข้อความลาก่อน",
        style=discord.TextStyle.paragraph,
        placeholder=(
            "เช่น 👋 ลาก่อน {user} "
            "ขอบคุณที่เคยอยู่กับ {server}"
        ),
        required=True,
        max_length=2000
    )

    async def on_submit(self, interaction):

        guild_data = get_guild_data(
            interaction.guild.id
        )

        guild_data["message"] = str(self.message)

        save_data()

        await interaction.response.send_message(
            "✅ ตั้งข้อความลาก่อนเรียบร้อยแล้ว",
            ephemeral=True
        )


# =========================================================
# Modal ตั้งรูป / GIF
# =========================================================

class GoodbyeMediaModal(
    discord.ui.Modal,
    title="ตั้งรูป / GIF"
):

    url = discord.ui.TextInput(
        label="ลิงก์รูปหรือ GIF",
        style=discord.TextStyle.short,
        placeholder="https://example.com/goodbye.gif",
        required=True,
        max_length=1000
    )

    async def on_submit(self, interaction):

        url = str(self.url).strip()

        if not (
            url.startswith("http://")
            or url.startswith("https://")
        ):
            await interaction.response.send_message(
                "❌ ลิงก์ต้องขึ้นต้นด้วย http:// หรือ https://",
                ephemeral=True
            )
            return

        guild_data = get_guild_data(
            interaction.guild.id
        )

        guild_data["media_url"] = url

        save_data()

        await interaction.response.send_message(
            "✅ ตั้งรูป/GIF เรียบร้อยแล้ว",
            ephemeral=True
        )


# =========================================================
# View ปุ่มตั้งค่า
# =========================================================

class GoodbyeView(discord.ui.View):

    def __init__(self):
        super().__init__(timeout=None)

    # -----------------------------------------------------
    # ตั้งห้อง
    # -----------------------------------------------------

    @discord.ui.button(
        label="ตั้งห้องลาก่อน",
        style=discord.ButtonStyle.primary,
        emoji="📢",
        custom_id="goodbye:set_channel"
    )
    async def set_channel(
        self,
        interaction,
        button
    ):

        if not is_manager(interaction.user):
            await interaction.response.send_message(
                "❌ ต้องมีสิทธิ์ Manage Server",
                ephemeral=True
            )
            return

        guild_data = get_guild_data(
            interaction.guild.id
        )

        guild_data["channel_id"] = (
            interaction.channel.id
        )

        save_data()

        await interaction.response.send_message(
            f"✅ ตั้งห้องลาก่อนเป็น "
            f"{interaction.channel.mention} แล้ว",
            ephemeral=True
        )

    # -----------------------------------------------------
    # ตั้งข้อความ
    # -----------------------------------------------------

    @discord.ui.button(
        label="ตั้งข้อความ",
        style=discord.ButtonStyle.secondary,
        emoji="✏️",
        custom_id="goodbye:set_message"
    )
    async def set_message(
        self,
        interaction,
        button
    ):

        if not is_manager(interaction.user):
            await interaction.response.send_message(
                "❌ ต้องมีสิทธิ์ Manage Server",
                ephemeral=True
            )
            return

        await interaction.response.send_modal(
            GoodbyeMessageModal()
        )

    # -----------------------------------------------------
    # ตั้งรูป
    # -----------------------------------------------------

    @discord.ui.button(
        label="ตั้งรูป/GIF",
        style=discord.ButtonStyle.secondary,
        emoji="🖼️",
        custom_id="goodbye:set_media"
    )
    async def set_media(
        self,
        interaction,
        button
    ):

        if not is_manager(interaction.user):
            await interaction.response.send_message(
                "❌ ต้องมีสิทธิ์ Manage Server",
                ephemeral=True
            )
            return

        await interaction.response.send_modal(
            GoodbyeMediaModal()
        )

    # -----------------------------------------------------
    # เปิดระบบ
    # -----------------------------------------------------

    @discord.ui.button(
        label="เปิดระบบ",
        style=discord.ButtonStyle.success,
        emoji="✅",
        custom_id="goodbye:enable"
    )
    async def enable(
        self,
        interaction,
        button
    ):

        if not is_manager(interaction.user):
            await interaction.response.send_message(
                "❌ ต้องมีสิทธิ์ Manage Server",
                ephemeral=True
            )
            return

        guild_data = get_guild_data(
            interaction.guild.id
        )

        if not guild_data.get("channel_id"):
            await interaction.response.send_message(
                "❌ กรุณาตั้งห้องลาก่อนก่อน",
                ephemeral=True
            )
            return

        guild_data["enabled"] = True

        save_data()

        await interaction.response.send_message(
            "🟢 เปิดระบบลาก่อนแล้ว",
            ephemeral=True
        )

    # -----------------------------------------------------
    # ปิดระบบ
    # -----------------------------------------------------

    @discord.ui.button(
        label="ปิดระบบ",
        style=discord.ButtonStyle.danger,
        emoji="⛔",
        custom_id="goodbye:disable"
    )
    async def disable(
        self,
        interaction,
        button
    ):

        if not is_manager(interaction.user):
            await interaction.response.send_message(
                "❌ ต้องมีสิทธิ์ Manage Server",
                ephemeral=True
            )
            return

        guild_data = get_guild_data(
            interaction.guild.id
        )

        guild_data["enabled"] = False

        save_data()

        await interaction.response.send_message(
            "🔴 ปิดระบบลาก่อนแล้ว",
            ephemeral=True
        )

    # -----------------------------------------------------
    # ลบรูป
    # -----------------------------------------------------

    @discord.ui.button(
        label="ลบรูป/GIF",
        style=discord.ButtonStyle.secondary,
        emoji="🗑️",
        custom_id="goodbye:clear_media"
    )
    async def clear_media(
        self,
        interaction,
        button
    ):

        if not is_manager(interaction.user):
            await interaction.response.send_message(
                "❌ ต้องมีสิทธิ์ Manage Server",
                ephemeral=True
            )
            return

        guild_data = get_guild_data(
            interaction.guild.id
        )

        guild_data["media_url"] = None

        save_data()

        await interaction.response.send_message(
            "✅ ลบรูป/GIF เรียบร้อยแล้ว",
            ephemeral=True
        )


# =========================================================
# Embed หน้าตั้งค่า
# =========================================================

def create_setup_embed(guild):

    guild_data = get_guild_data(guild.id)

    channel_id = guild_data.get("channel_id")

    channel = None

    if channel_id:
        channel = guild.get_channel(channel_id)

    if channel:
        channel_text = channel.mention
    else:
        channel_text = "ยังไม่ได้ตั้ง"

    if guild_data.get("enabled"):
        status = "🟢 เปิดอยู่"
    else:
        status = "🔴 ปิดอยู่"

    media = guild_data.get("media_url")

    embed = discord.Embed(
        title="👋 ระบบลาก่อน",
        description=(
            "ตั้งค่าระบบลาก่อนของ Server นี้\n\n"
            "**ตัวแปรที่ใช้ได้:**\n"
            "`{user}` = สมาชิกที่ออก\n"
            "`{server}` = ชื่อ Server\n"
            "`{member_count}` = จำนวนสมาชิก"
        ),
        color=discord.Color.orange()
    )

    embed.add_field(
        name="📢 ห้องลาก่อน",
        value=channel_text,
        inline=False
    )

    embed.add_field(
        name="📌 สถานะ",
        value=status,
        inline=True
    )

    embed.add_field(
        name="🖼️ สื่อ",
        value="ตั้งไว้แล้ว" if media else "ไม่มี",
        inline=True
    )

    embed.add_field(
        name="✏️ ข้อความ",
        value=guild_data.get("message", "")[:1024],
        inline=False
    )

    embed.set_footer(
        text="ใช้ได้เฉพาะผู้ที่มีสิทธิ์ Manage Server"
    )

    return embed


# =========================================================
# setup()
# =========================================================

def setup(bot):

    @bot.tree.command(
        name=COMMAND_NAME,
        description="ตั้งค่าระบบลาก่อนของ Server"
    )
    @discord.app_commands.guild_only()
    @discord.app_commands.checks.has_permissions(
        manage_guild=True
    )
    async def goodbye(interaction):

        embed = create_setup_embed(
            interaction.guild
        )

        await interaction.response.send_message(
            embed=embed,
            view=GoodbyeView(),
            ephemeral=True
        )

    @goodbye.error
    async def goodbye_error(
        interaction,
        error
    ):

        if isinstance(
            error,
            discord.app_commands.errors.MissingPermissions
        ):

            if interaction.response.is_done():

                await interaction.followup.send(
                    "❌ ต้องมีสิทธิ์ Manage Server",
                    ephemeral=True
                )

            else:

                await interaction.response.send_message(
                    "❌ ต้องมีสิทธิ์ Manage Server",
                    ephemeral=True
                )

        else:

            print(
                f"❌ Goodbye command error: {error}"
            )

            if not interaction.response.is_done():

                await interaction.response.send_message(
                    "❌ เกิดข้อผิดพลาด",
                    ephemeral=True
                )

    # =====================================================
    # สมาชิกออกจาก Server
    # =====================================================

    @bot.listen("on_member_remove")
    async def goodbye_member(member):

        try:

            guild_data = get_guild_data(
                member.guild.id
            )

            # ปิดระบบอยู่
            if not guild_data.get("enabled"):
                return

            # ยังไม่ได้ตั้งห้อง
            channel_id = guild_data.get("channel_id")

            if not channel_id:
                return

            channel = member.guild.get_channel(
                channel_id
            )

            if channel is None:
                print(
                    f"⚠️ ไม่พบห้องลาก่อน "
                    f"ของ Server {member.guild.id}"
                )
                return

            message = replace_text(
                guild_data.get("message", ""),
                member
            )

            media_url = guild_data.get(
                "media_url"
            )

            embed = discord.Embed(
                description=message,
                color=discord.Color.orange()
            )

            if media_url:
                embed.set_image(
                    url=media_url
                )

            await channel.send(
                embed=embed
            )

        except discord.Forbidden:

            print(
                f"❌ บอทไม่มีสิทธิ์ส่งข้อความ "
                f"ในห้องลาก่อนของ "
                f"{member.guild.id}"
            )

        except Exception as e:

            print(
                f"❌ Goodbye Error "
                f"({member.guild.id}): {e}"
            )

    # ทำให้ปุ่มใช้งานได้หลังบอทรีสตาร์ต
    bot.add_view(GoodbyeView())

    print("✅ F3 Goodbye โหลดสำเร็จ")