# F7.py
# Discord Verification System
# Compatible with a Bot Loader that calls: module.setup(bot)
# No TOKEN required.

import sqlite3
import secrets
from datetime import datetime, timezone

import discord
from discord.ext import commands
from discord import app_commands


DB_FILE = "F7_verification.db"


# =========================================================
# DATABASE
# =========================================================

def db_connect():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn


def init_database():
    conn = db_connect()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            guild_id INTEGER PRIMARY KEY,
            verify_channel_id INTEGER,
            admin_channel_id INTEGER,
            role_id INTEGER,
            panel_message_id INTEGER,
            enabled INTEGER DEFAULT 1,
            code_length INTEGER DEFAULT 6,
            panel_title TEXT,
            panel_description TEXT,
            panel_footer TEXT,
            panel_image_url TEXT,
            panel_color TEXT DEFAULT '#5865F2',
            panel_button_label TEXT DEFAULT 'ยืนยันตัวตน',
            code_title TEXT DEFAULT '🔑 รหัสยืนยันใหม่',
            code_description TEXT,
            code_footer TEXT,
            code_image_url TEXT,
            code_color TEXT DEFAULT '#57F287'
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS codes (
            guild_id INTEGER NOT NULL,
            code TEXT NOT NULL,
            used INTEGER DEFAULT 0,
            used_by INTEGER,
            used_at TEXT,
            message_id INTEGER,
            created_at TEXT NOT NULL,
            PRIMARY KEY (guild_id, code)
        )
    """)

    # รองรับฐานข้อมูล F7 เดิม
    code_columns = {row[1] for row in conn.execute("PRAGMA table_info(codes)").fetchall()}
    if "message_id" not in code_columns:
        conn.execute("ALTER TABLE codes ADD COLUMN message_id INTEGER")

    setting_columns = {row[1] for row in conn.execute("PRAGMA table_info(settings)").fetchall()}
    migrations = {
        "panel_title": "TEXT",
        "panel_description": "TEXT",
        "panel_footer": "TEXT",
        "panel_image_url": "TEXT",
        "panel_color": "TEXT",
        "panel_button_label": "TEXT",
        "code_title": "TEXT",
        "code_description": "TEXT",
        "code_footer": "TEXT",
        "code_image_url": "TEXT",
        "code_color": "TEXT",
    }
    for column, column_type in migrations.items():
        if column not in setting_columns:
            conn.execute(f"ALTER TABLE settings ADD COLUMN {column} {column_type}")

    conn.commit()
    conn.close()


def create_settings(guild_id):
    conn = db_connect()
    conn.execute("""
        INSERT OR IGNORE INTO settings
        (guild_id, enabled, code_length)
        VALUES (?, 1, 6)
    """, (guild_id,))
    conn.commit()
    conn.close()


def get_settings(guild_id):
    create_settings(guild_id)
    conn = db_connect()
    row = conn.execute(
        "SELECT * FROM settings WHERE guild_id = ?",
        (guild_id,)
    ).fetchone()
    conn.close()
    return row


def update_setting(guild_id, field, value):
    allowed = {
        "verify_channel_id",
        "admin_channel_id",
        "role_id",
        "panel_message_id",
        "enabled",
        "code_length",
        "panel_title",
        "panel_description",
        "panel_footer",
        "panel_image_url",
        "panel_color",
        "panel_button_label",
        "code_title",
        "code_description",
        "code_footer",
        "code_image_url",
        "code_color",
    }
    if field not in allowed:
        return

    create_settings(guild_id)
    conn = db_connect()
    conn.execute(
        f"UPDATE settings SET {field} = ? WHERE guild_id = ?",
        (value, guild_id),
    )
    conn.commit()
    conn.close()


# =========================================================
# CUSTOM MESSAGE / EMBED HELPERS
# =========================================================

DEFAULT_PANEL_TITLE = "🛡️ ยืนยันตัวตน"
DEFAULT_PANEL_DESCRIPTION = (
    "กดปุ่มด้านล่างเพื่อยืนยันตัวตน\n\n"
    "🔐 กรอกรหัสที่ได้รับจากแอดมิน\n"
    "🎖️ ยืนยันสำเร็จจะได้รับ {role}\n\n"
    "⚠️ รหัสแต่ละรหัสใช้ได้เพียงครั้งเดียว"
)
DEFAULT_PANEL_FOOTER = "Verification System"
DEFAULT_PANEL_COLOR = "#5865F2"
DEFAULT_PANEL_BUTTON = "ยืนยันตัวตน"

DEFAULT_CODE_TITLE = "🔑 รหัสยืนยันใหม่"
DEFAULT_CODE_DESCRIPTION = (
    "## `{code}`\n\n"
    "🟢 **ยังไม่ได้ใช้**\n"
    "♾️ **ไม่มีวันหมดอายุ**\n"
    "👤 **ใช้ได้เพียง 1 คน**"
)
DEFAULT_CODE_FOOTER = "รหัสนี้ใช้ได้เพียงครั้งเดียว"
DEFAULT_CODE_COLOR = "#57F287"


def clean_text(value, default=""):
    return default if value is None else str(value)


def parse_color(value, fallback="#5865F2"):
    value = str(value or "").strip().replace("0x", "").replace("#", "")
    if len(value) != 6:
        value = fallback.replace("#", "")
    try:
        return discord.Color(int(value, 16))
    except ValueError:
        return discord.Color(int(fallback.replace("#", ""), 16))


def render_text(template, **kwargs):
    text = clean_text(template)
    for key, value in kwargs.items():
        text = text.replace("{" + key + "}", str(value))
    return text


def get_panel_embed(settings, role_mention):
    title = clean_text(settings["panel_title"], DEFAULT_PANEL_TITLE)
    description = clean_text(
        settings["panel_description"],
        DEFAULT_PANEL_DESCRIPTION,
    )
    footer = clean_text(settings["panel_footer"], DEFAULT_PANEL_FOOTER)
    image_url = clean_text(settings["panel_image_url"], "")
    color = parse_color(settings["panel_color"], DEFAULT_PANEL_COLOR)

    embed = discord.Embed(
        title=render_text(title, role=role_mention),
        description=render_text(description, role=role_mention),
        color=color,
    )

    if footer:
        embed.set_footer(text=render_text(footer, role=role_mention))

    if image_url:
        embed.set_image(url=image_url)

    return embed


def get_code_embed(settings, code, creator="ระบบ"):
    title = clean_text(settings["code_title"], DEFAULT_CODE_TITLE)
    description = clean_text(
        settings["code_description"],
        DEFAULT_CODE_DESCRIPTION,
    )
    footer = clean_text(settings["code_footer"], DEFAULT_CODE_FOOTER)
    image_url = clean_text(settings["code_image_url"], "")
    color = parse_color(settings["code_color"], DEFAULT_CODE_COLOR)

    embed = discord.Embed(
        title=render_text(title, code=code, user=creator),
        description=render_text(
            description,
            code=code,
            user=creator,
        ),
        color=color,
    )

    if footer:
        embed.set_footer(
            text=render_text(footer, code=code, user=creator)
        )

    if image_url:
        embed.set_image(url=image_url)

    return embed


# =========================================================
# CODE
# =========================================================

def generate_code(guild_id, length=6):
    length = max(4, min(int(length), 12))
    conn = db_connect()

    for _ in range(10000):
        code = "".join(secrets.choice("0123456789") for _ in range(length))
        exists = conn.execute(
            "SELECT 1 FROM codes WHERE guild_id = ? AND code = ?",
            (guild_id, code),
        ).fetchone()

        if not exists:
            now = datetime.now(timezone.utc).isoformat()
            conn.execute("""
                INSERT INTO codes
                (guild_id, code, used, created_at)
                VALUES (?, ?, 0, ?)
            """, (guild_id, code, now))
            conn.commit()
            conn.close()
            return code

    conn.close()
    raise RuntimeError("ไม่สามารถสร้างรหัสที่ไม่ซ้ำได้")


def get_code(guild_id, code):
    conn = db_connect()
    row = conn.execute("""
        SELECT * FROM codes
        WHERE guild_id = ? AND code = ?
    """, (guild_id, code)).fetchone()
    conn.close()
    return row


def set_code_message_id(guild_id, code, message_id):
    conn = db_connect()
    conn.execute("""
        UPDATE codes SET message_id = ?
        WHERE guild_id = ? AND code = ?
    """, (message_id, guild_id, code))
    conn.commit()
    conn.close()


def consume_code(guild_id, code, user_id):
    """
    ทำให้รหัสใช้ได้ครั้งเดียว
    UPDATE จะสำเร็จเฉพาะเมื่อ used = 0
    """
    conn = db_connect()
    now = datetime.now(timezone.utc).isoformat()

    cur = conn.execute("""
        UPDATE codes
        SET used = 1, used_by = ?, used_at = ?
        WHERE guild_id = ? AND code = ? AND used = 0
    """, (user_id, now, guild_id, code))

    conn.commit()
    ok = cur.rowcount == 1
    conn.close()
    return ok


def release_code(guild_id, code):
    conn = db_connect()
    conn.execute("""
        UPDATE codes
        SET used = 0, used_by = NULL, used_at = NULL
        WHERE guild_id = ? AND code = ?
    """, (guild_id, code))
    conn.commit()
    conn.close()


# =========================================================
# PERMISSION
# =========================================================

def can_manage(interaction):
    if interaction.guild is None:
        return False

    p = interaction.user.guild_permissions
    return (
        interaction.guild.owner_id == interaction.user.id
        or p.administrator
        or p.manage_guild
    )


async def delete_used_code_message(bot, guild, code_row):
    """ลบข้อความรหัสที่ถูกใช้แล้วออกจากห้องแอดมิน"""
    message_id = code_row["message_id"]
    if not message_id:
        return False

    settings = get_settings(guild.id)
    admin_channel_id = settings["admin_channel_id"]
    if not admin_channel_id:
        return False

    channel = guild.get_channel(int(admin_channel_id))
    if channel is None:
        return False

    try:
        message = await channel.fetch_message(int(message_id))
        await message.delete()
        return True
    except (discord.NotFound, discord.Forbidden, discord.HTTPException):
        return False


# =========================================================
# AUTO-REPLACEMENT CODE
# =========================================================

async def send_new_code_to_admin(bot, guild):
    """สร้างรหัสใหม่ทันทีและส่งเข้าห้องแอดมินที่ตั้งค่าไว้"""
    settings = get_settings(guild.id)
    admin_channel_id = settings["admin_channel_id"]

    if not admin_channel_id:
        return False, None, "ยังไม่ได้ตั้งค่าห้องแอดมิน"

    channel = guild.get_channel(int(admin_channel_id))
    if channel is None:
        return False, None, "ไม่พบห้องแอดมิน"

    try:
        code = generate_code(
            guild.id,
            settings["code_length"] or 6,
        )
    except RuntimeError as e:
        return False, None, str(e)

    embed = get_code_embed(
        settings,
        code,
        "ระบบอัตโนมัติ",
    )

    try:
        sent_message = await channel.send(embed=embed)
        set_code_message_id(guild.id, code, sent_message.id)
    except (discord.Forbidden, discord.HTTPException):
        # ถ้าส่งไม่ได้ อย่าทิ้งรหัสค้างไว้โดยไม่มีใครรู้
        conn = db_connect()
        conn.execute(
            "DELETE FROM codes WHERE guild_id = ? AND code = ?",
            (guild.id, code),
        )
        conn.commit()
        conn.close()
        return False, None, "บอทส่งรหัสใหม่เข้าห้องแอดมินไม่ได้"

    return True, code, None


# =========================================================
# VERIFICATION MODAL
# =========================================================

class VerificationModal(discord.ui.Modal, title="ยืนยันตัวตน"):

    code_input = discord.ui.TextInput(
        label="กรอกรหัสยืนยัน",
        placeholder="เช่น 583921",
        required=True,
        min_length=4,
        max_length=12,
    )

    async def on_submit(self, interaction: discord.Interaction):
        if interaction.guild is None:
            await interaction.response.send_message(
                "❌ ใช้ระบบนี้ในเซิร์ฟเวอร์เท่านั้น",
                ephemeral=True,
            )
            return

        guild_id = interaction.guild.id
        code = str(self.code_input.value).strip()

        settings = get_settings(guild_id)

        if not settings["enabled"]:
            await interaction.response.send_message(
                "❌ ระบบยืนยันตัวตนถูกปิดอยู่",
                ephemeral=True,
            )
            return

        role_id = settings["role_id"]
        if not role_id:
            await interaction.response.send_message(
                "❌ แอดมินยังไม่ได้ตั้งค่ายศ",
                ephemeral=True,
            )
            return

        role = interaction.guild.get_role(int(role_id))
        member = interaction.guild.get_member(interaction.user.id)
        me = interaction.guild.me

        if role is None:
            await interaction.response.send_message(
                "❌ ไม่พบยศที่ตั้งค่าไว้",
                ephemeral=True,
            )
            return

        if member is None or me is None:
            await interaction.response.send_message(
                "❌ ไม่พบข้อมูลสมาชิก",
                ephemeral=True,
            )
            return

        if role in member.roles:
            await interaction.response.send_message(
                "ℹ️ คุณได้รับยศนี้อยู่แล้ว",
                ephemeral=True,
            )
            return

        if not me.guild_permissions.manage_roles:
            await interaction.response.send_message(
                "❌ บอทไม่มีสิทธิ์ Manage Roles",
                ephemeral=True,
            )
            return

        if role >= me.top_role:
            await interaction.response.send_message(
                "❌ ยศที่จะมอบต้องอยู่ต่ำกว่ายศสูงสุดของบอท",
                ephemeral=True,
            )
            return

        code_row = get_code(guild_id, code)

        if code_row is None:
            await interaction.response.send_message(
                "❌ รหัสไม่ถูกต้อง",
                ephemeral=True,
            )
            return

        if code_row["used"]:
            await interaction.response.send_message(
                "❌ รหัสนี้ถูกใช้ไปแล้ว",
                ephemeral=True,
            )
            return

        # จองรหัสแบบถาวรก่อน เพื่อไม่ให้คนอื่นใช้ซ้ำ
        if not consume_code(guild_id, code, interaction.user.id):
            await interaction.response.send_message(
                "❌ รหัสนี้ถูกใช้ไปแล้ว",
                ephemeral=True,
            )
            return

        try:
            await member.add_roles(
                role,
                reason="F7 Verification",
            )
        except (discord.Forbidden, discord.HTTPException):
            # ถ้าให้ยศไม่ได้ ให้คืนรหัสกลับมาใช้ได้
            release_code(guild_id, code)

            await interaction.response.send_message(
                "❌ บอทไม่สามารถมอบยศได้\n"
                "ตรวจสอบ Manage Roles และลำดับยศของบอท",
                ephemeral=True,
            )
            return

        # ลบข้อความรหัสเก่าที่ถูกใช้แล้วออกจากห้องแอดมิน
        await delete_used_code_message(
            interaction.client,
            interaction.guild,
            code_row,
        )

        # จากนั้นสร้างรหัสใหม่และส่งเข้าห้องแอดมินทันที
        new_code_ok, new_code, new_code_error = await send_new_code_to_admin(
            interaction.client,
            interaction.guild,
        )

        if new_code_ok:
            await interaction.response.send_message(
                f"✅ ยืนยันตัวตนสำเร็จ!\n"
                f"คุณได้รับยศ {role.mention}",
                ephemeral=True,
            )
        else:
            # การยืนยันสำเร็จแล้ว แต่ไม่สามารถส่งรหัสรอบถัดไปได้
            await interaction.response.send_message(
                f"✅ ยืนยันตัวตนสำเร็จ!\n"
                f"คุณได้รับยศ {role.mention}\n\n"
                f"⚠️ รหัสใหม่ยังส่งเข้าห้องแอดมินไม่ได้: {new_code_error}",
                ephemeral=True,
            )


# =========================================================
# PERSISTENT VERIFY BUTTON
# =========================================================

class VerificationView(discord.ui.View):

    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(
        label="ยืนยันตัวตน",
        emoji="✅",
        style=discord.ButtonStyle.success,
        custom_id="f7_verification_button",
    )
    async def verify_button(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button,
    ):
        await interaction.response.send_modal(
            VerificationModal()
        )


# =========================================================
# SELECT VIEWS
# =========================================================

class VerifyChannelSelect(discord.ui.ChannelSelect):

    def __init__(self):
        super().__init__(
            placeholder="เลือกห้องยืนยันตัวตน",
            channel_types=[discord.ChannelType.text],
            min_values=1,
            max_values=1,
        )

    async def callback(self, interaction):
        channel = self.values[0]
        update_setting(
            interaction.guild.id,
            "verify_channel_id",
            channel.id,
        )
        await interaction.response.edit_message(
            content=f"✅ ห้องยืนยัน: {channel.mention}",
            view=None,
        )


class VerifyChannelView(discord.ui.View):

    def __init__(self):
        super().__init__(timeout=120)
        self.add_item(VerifyChannelSelect())


class AdminChannelSelect(discord.ui.ChannelSelect):

    def __init__(self):
        super().__init__(
            placeholder="เลือกห้องแอดมิน",
            channel_types=[discord.ChannelType.text],
            min_values=1,
            max_values=1,
        )

    async def callback(self, interaction):
        channel = self.values[0]
        update_setting(
            interaction.guild.id,
            "admin_channel_id",
            channel.id,
        )
        await interaction.response.edit_message(
            content=f"✅ ห้องแอดมิน: {channel.mention}",
            view=None,
        )


class AdminChannelView(discord.ui.View):

    def __init__(self):
        super().__init__(timeout=120)
        self.add_item(AdminChannelSelect())


class VerifyRoleSelect(discord.ui.RoleSelect):

    def __init__(self):
        super().__init__(
            placeholder="เลือกยศที่จะได้รับ",
            min_values=1,
            max_values=1,
        )

    async def callback(self, interaction):
        role = self.values[0]

        if role >= interaction.guild.me.top_role:
            await interaction.response.send_message(
                "❌ ยศนี้อยู่สูงกว่ายศบอทหรืออยู่ระดับเดียวกัน",
                ephemeral=True,
            )
            return

        update_setting(
            interaction.guild.id,
            "role_id",
            role.id,
        )

        await interaction.response.edit_message(
            content=f"✅ ยศยืนยันตัวตน: {role.mention}",
            view=None,
        )


class VerifyRoleView(discord.ui.View):

    def __init__(self):
        super().__init__(timeout=120)
        self.add_item(VerifyRoleSelect())


# =========================================================
# CUSTOMIZATION MODALS
# =========================================================

class PanelTextModal(discord.ui.Modal, title="แก้ข้อความแผงยืนยัน"):
    title_input = discord.ui.TextInput(
        label="หัวข้อ",
        placeholder="เช่น 🛡️ ยืนยันตัวตน",
        required=False,
        max_length=256,
    )
    description_input = discord.ui.TextInput(
        label="ข้อความหลัก",
        placeholder="ใส่ข้อความทั้งหมดของแผงยืนยัน",
        required=False,
        style=discord.TextStyle.paragraph,
        max_length=4000,
    )
    footer_input = discord.ui.TextInput(
        label="ข้อความด้านล่าง",
        placeholder="เช่น Verification System",
        required=False,
        max_length=2048,
    )
    image_input = discord.ui.TextInput(
        label="ลิงก์รูป / GIF",
        placeholder="https://example.com/image.gif",
        required=False,
        max_length=2048,
    )
    button_input = discord.ui.TextInput(
        label="ข้อความปุ่ม",
        placeholder="ยืนยันตัวตน",
        required=False,
        max_length=80,
    )

    def __init__(self, settings):
        super().__init__()
        self.settings = settings
        self.title_input.default = clean_text(
            settings["panel_title"], DEFAULT_PANEL_TITLE
        )
        self.description_input.default = clean_text(
            settings["panel_description"], DEFAULT_PANEL_DESCRIPTION
        )
        self.footer_input.default = clean_text(
            settings["panel_footer"], DEFAULT_PANEL_FOOTER
        )
        self.image_input.default = clean_text(
            settings["panel_image_url"], ""
        )
        self.button_input.default = clean_text(
            settings["panel_button_label"], DEFAULT_PANEL_BUTTON
        )

    async def on_submit(self, interaction):
        if not can_manage(interaction):
            await interaction.response.send_message(
                "❌ ไม่มีสิทธิ์",
                ephemeral=True,
            )
            return

        gid = interaction.guild.id
        update_setting(gid, "panel_title", self.title_input.value.strip())
        update_setting(gid, "panel_description", self.description_input.value)
        update_setting(gid, "panel_footer", self.footer_input.value.strip())
        update_setting(gid, "panel_image_url", self.image_input.value.strip())
        update_setting(gid, "panel_button_label", self.button_input.value.strip() or DEFAULT_PANEL_BUTTON)

        await interaction.response.send_message(
            "✅ บันทึกข้อความแผงยืนยันแล้ว\n"
            "ใช้ปุ่ม **ส่งแผงยืนยัน** เพื่อส่งแผงใหม่",
            ephemeral=True,
        )


class PanelColorModal(discord.ui.Modal, title="ตั้งแถบสีแผงยืนยัน"):
    color_input = discord.ui.TextInput(
        label="สี HEX",
        placeholder="#5865F2",
        required=True,
        min_length=6,
        max_length=7,
    )

    def __init__(self, current):
        super().__init__()
        self.color_input.default = clean_text(
            current,
            DEFAULT_PANEL_COLOR,
        )

    async def on_submit(self, interaction):
        if not can_manage(interaction):
            await interaction.response.send_message(
                "❌ ไม่มีสิทธิ์",
                ephemeral=True,
            )
            return

        value = self.color_input.value.strip()
        try:
            parse_color(value)
            update_setting(
                interaction.guild.id,
                "panel_color",
                value if value.startswith("#") else "#" + value,
            )
        except Exception:
            await interaction.response.send_message(
                "❌ สีไม่ถูกต้อง ใช้รูปแบบเช่น `#5865F2`",
                ephemeral=True,
            )
            return

        await interaction.response.send_message(
            f"✅ ตั้งสีแผงเป็น `{value}` แล้ว",
            ephemeral=True,
        )


class CodeMessageModal(discord.ui.Modal, title="แก้ข้อความรหัสแอดมิน"):
    title_input = discord.ui.TextInput(
        label="หัวข้อ",
        placeholder="เช่น 🔑 รหัสยืนยันใหม่",
        required=False,
        max_length=256,
    )
    description_input = discord.ui.TextInput(
        label="ข้อความรหัส",
        placeholder="ใช้ {code} เพื่อแสดงรหัส",
        required=False,
        style=discord.TextStyle.paragraph,
        max_length=4000,
    )
    footer_input = discord.ui.TextInput(
        label="ข้อความด้านล่าง",
        placeholder="เช่น รหัสนี้ใช้ได้เพียงครั้งเดียว",
        required=False,
        max_length=2048,
    )
    image_input = discord.ui.TextInput(
        label="ลิงก์รูป / GIF",
        placeholder="https://example.com/code.gif",
        required=False,
        max_length=2048,
    )
    color_input = discord.ui.TextInput(
        label="สี HEX",
        placeholder="#57F287",
        required=False,
        max_length=7,
    )

    def __init__(self, settings):
        super().__init__()
        self.settings = settings
        self.title_input.default = clean_text(
            settings["code_title"], DEFAULT_CODE_TITLE
        )
        self.description_input.default = clean_text(
            settings["code_description"], DEFAULT_CODE_DESCRIPTION
        )
        self.footer_input.default = clean_text(
            settings["code_footer"], DEFAULT_CODE_FOOTER
        )
        self.image_input.default = clean_text(
            settings["code_image_url"], ""
        )
        self.color_input.default = clean_text(
            settings["code_color"], DEFAULT_CODE_COLOR
        )

    async def on_submit(self, interaction):
        if not can_manage(interaction):
            await interaction.response.send_message(
                "❌ ไม่มีสิทธิ์",
                ephemeral=True,
            )
            return

        gid = interaction.guild.id
        color = self.color_input.value.strip() or DEFAULT_CODE_COLOR
        if not color.startswith("#"):
            color = "#" + color

        try:
            parse_color(color)
        except Exception:
            await interaction.response.send_message(
                "❌ สีไม่ถูกต้อง",
                ephemeral=True,
            )
            return

        update_setting(gid, "code_title", self.title_input.value.strip())
        update_setting(gid, "code_description", self.description_input.value)
        update_setting(gid, "code_footer", self.footer_input.value.strip())
        update_setting(gid, "code_image_url", self.image_input.value.strip())
        update_setting(gid, "code_color", color)

        await interaction.response.send_message(
            "✅ บันทึกข้อความ/รูป/GIF/สีของข้อความรหัสแล้ว",
            ephemeral=True,
        )


# =========================================================
# SETTINGS VIEW
# =========================================================

class VerificationSettingsView(discord.ui.View):

    def __init__(self, cog):
        super().__init__(timeout=300)
        self.cog = cog

    @discord.ui.button(
        label="ห้องยืนยัน",
        emoji="📋",
        style=discord.ButtonStyle.primary,
        row=0,
    )
    async def set_verify_channel(self, interaction, button):
        if not can_manage(interaction):
            await interaction.response.send_message(
                "❌ ไม่มีสิทธิ์",
                ephemeral=True,
            )
            return

        await interaction.response.send_message(
            "เลือกห้องยืนยันตัวตน:",
            view=VerifyChannelView(),
            ephemeral=True,
        )

    @discord.ui.button(
        label="ยศ",
        emoji="🎖️",
        style=discord.ButtonStyle.primary,
        row=0,
    )
    async def set_role(self, interaction, button):
        if not can_manage(interaction):
            await interaction.response.send_message(
                "❌ ไม่มีสิทธิ์",
                ephemeral=True,
            )
            return

        await interaction.response.send_message(
            "เลือกยศที่จะได้รับ:",
            view=VerifyRoleView(),
            ephemeral=True,
        )

    @discord.ui.button(
        label="ห้องแอดมิน",
        emoji="🔐",
        style=discord.ButtonStyle.primary,
        row=0,
    )
    async def set_admin_channel(self, interaction, button):
        if not can_manage(interaction):
            await interaction.response.send_message(
                "❌ ไม่มีสิทธิ์",
                ephemeral=True,
            )
            return

        await interaction.response.send_message(
            "เลือกห้องแอดมินสำหรับรับรหัส:",
            view=AdminChannelView(),
            ephemeral=True,
        )

    @discord.ui.button(
        label="สร้างรหัส",
        emoji="🔑",
        style=discord.ButtonStyle.success,
        row=1,
    )
    async def create_code_button(self, interaction, button):
        if not can_manage(interaction):
            await interaction.response.send_message(
                "❌ ไม่มีสิทธิ์",
                ephemeral=True,
            )
            return

        await self.cog.create_new_code(interaction)

    @discord.ui.button(
        label="ส่งแผงยืนยัน",
        emoji="📨",
        style=discord.ButtonStyle.success,
        row=1,
    )
    async def send_panel_button(self, interaction, button):
        if not can_manage(interaction):
            await interaction.response.send_message(
                "❌ ไม่มีสิทธิ์",
                ephemeral=True,
            )
            return

        await self.cog.send_panel(interaction)

    @discord.ui.button(
        label="สถานะ",
        emoji="📊",
        style=discord.ButtonStyle.secondary,
        row=1,
    )
    async def status_button(self, interaction, button):
        if not can_manage(interaction):
            await interaction.response.send_message(
                "❌ ไม่มีสิทธิ์",
                ephemeral=True,
            )
            return

        await self.cog.show_status(interaction)

    @discord.ui.button(
        label="ข้อความแผง",
        emoji="📝",
        style=discord.ButtonStyle.primary,
        row=2,
    )
    async def panel_text_button(self, interaction, button):
        if not can_manage(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return
        await interaction.response.send_modal(
            PanelTextModal(get_settings(interaction.guild.id))
        )

    @discord.ui.button(
        label="สีแผง",
        emoji="🎨",
        style=discord.ButtonStyle.secondary,
        row=2,
    )
    async def panel_color_button(self, interaction, button):
        if not can_manage(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return
        await interaction.response.send_modal(
            PanelColorModal(
                get_settings(interaction.guild.id)["panel_color"]
            )
        )

    @discord.ui.button(
        label="ข้อความรหัส",
        emoji="🔑",
        style=discord.ButtonStyle.primary,
        row=2,
    )
    async def code_message_button(self, interaction, button):
        if not can_manage(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return
        await interaction.response.send_modal(
            CodeMessageModal(get_settings(interaction.guild.id))
        )

    @discord.ui.button(
        label="เปิด/ปิด",
        emoji="⚙️",
        style=discord.ButtonStyle.secondary,
        row=1,
    )
    async def toggle_button(self, interaction, button):
        if not can_manage(interaction):
            await interaction.response.send_message(
                "❌ ไม่มีสิทธิ์",
                ephemeral=True,
            )
            return

        settings = get_settings(interaction.guild.id)
        new_value = 0 if settings["enabled"] else 1
        update_setting(
            interaction.guild.id,
            "enabled",
            new_value,
        )

        await interaction.response.send_message(
            "🟢 เปิดระบบแล้ว" if new_value else "🔴 ปิดระบบแล้ว",
            ephemeral=True,
        )


# =========================================================
# COG
# =========================================================

class Verification(commands.Cog):

    def __init__(self, bot):
        self.bot = bot
        init_database()

        # ปุ่มเก่าที่อยู่ใน Discord จะกลับมาใช้งานหลัง restart
        try:
            bot.add_view(VerificationView())
        except Exception as e:
            print(f"[F7] Persistent View: {e}")

    async def create_new_code(self, interaction):
        guild = interaction.guild
        settings = get_settings(guild.id)

        admin_channel_id = settings["admin_channel_id"]

        if not admin_channel_id:
            await interaction.response.send_message(
                "❌ กรุณาตั้งค่าห้องแอดมินก่อน",
                ephemeral=True,
            )
            return

        channel = guild.get_channel(int(admin_channel_id))

        if channel is None:
            await interaction.response.send_message(
                "❌ ไม่พบห้องแอดมิน",
                ephemeral=True,
            )
            return

        try:
            code = generate_code(
                guild.id,
                settings["code_length"] or 6,
            )
        except RuntimeError as e:
            await interaction.response.send_message(
                f"❌ {e}",
                ephemeral=True,
            )
            return

        embed = get_code_embed(
            settings,
            code,
            str(interaction.user),
        )

        try:
            sent_message = await channel.send(embed=embed)
            set_code_message_id(guild.id, code, sent_message.id)
        except (discord.Forbidden, discord.HTTPException):
            # ลบรหัสทิ้ง เพราะยังไม่ได้ส่งให้แอดมิน
            conn = db_connect()
            conn.execute(
                "DELETE FROM codes WHERE guild_id = ? AND code = ?",
                (guild.id, code),
            )
            conn.commit()
            conn.close()

            await interaction.response.send_message(
                "❌ ส่งรหัสเข้าห้องแอดมินไม่ได้",
                ephemeral=True,
            )
            return

        await interaction.response.send_message(
            f"✅ สร้างรหัสแล้ว และส่งไปที่ {channel.mention}",
            ephemeral=True,
        )

    async def send_panel(self, interaction):
        guild = interaction.guild
        settings = get_settings(guild.id)

        channel_id = settings["verify_channel_id"]
        role_id = settings["role_id"]

        if not channel_id:
            await interaction.response.send_message(
                "❌ กรุณาตั้งค่าห้องยืนยันก่อน",
                ephemeral=True,
            )
            return

        if not role_id:
            await interaction.response.send_message(
                "❌ กรุณาตั้งค่ายศก่อน",
                ephemeral=True,
            )
            return

        channel = guild.get_channel(int(channel_id))
        role = guild.get_role(int(role_id))

        if channel is None:
            await interaction.response.send_message(
                "❌ ไม่พบห้องยืนยัน",
                ephemeral=True,
            )
            return

        if role is None:
            await interaction.response.send_message(
                "❌ ไม่พบยศ",
                ephemeral=True,
            )
            return

        embed = get_panel_embed(
            settings,
            role.mention,
        )

        try:
            view = VerificationView()
            view.verify_button.label = (
                settings["panel_button_label"] or DEFAULT_PANEL_BUTTON
            )
            message = await channel.send(
                embed=embed,
                view=view,
            )
        except (discord.Forbidden, discord.HTTPException):
            await interaction.response.send_message(
                "❌ บอทส่งข้อความในห้องนี้ไม่ได้",
                ephemeral=True,
            )
            return

        update_setting(
            guild.id,
            "panel_message_id",
            message.id,
        )

        await interaction.response.send_message(
            f"✅ ส่งแผงยืนยันไปที่ {channel.mention} แล้ว",
            ephemeral=True,
        )

    async def show_status(self, interaction):
        guild_id = interaction.guild.id
        settings = get_settings(guild_id)

        conn = db_connect()
        total = conn.execute(
            "SELECT COUNT(*) FROM codes WHERE guild_id = ?",
            (guild_id,),
        ).fetchone()[0]
        used = conn.execute(
            "SELECT COUNT(*) FROM codes WHERE guild_id = ? AND used = 1",
            (guild_id,),
        ).fetchone()[0]
        conn.close()

        verify = (
            f"<#{settings['verify_channel_id']}>"
            if settings["verify_channel_id"]
            else "ยังไม่ได้ตั้ง"
        )
        admin = (
            f"<#{settings['admin_channel_id']}>"
            if settings["admin_channel_id"]
            else "ยังไม่ได้ตั้ง"
        )
        role = (
            f"<@&{settings['role_id']}>"
            if settings["role_id"]
            else "ยังไม่ได้ตั้ง"
        )

        embed = discord.Embed(
            title="📊 สถานะระบบ Verification",
            color=discord.Color.blurple(),
        )

        embed.add_field(
            name="สถานะ",
            value="🟢 เปิด" if settings["enabled"] else "🔴 ปิด",
            inline=True,
        )
        embed.add_field(
            name="รหัสทั้งหมด",
            value=str(total),
            inline=True,
        )
        embed.add_field(
            name="ใช้แล้ว",
            value=str(used),
            inline=True,
        )
        embed.add_field(
            name="รหัสที่ยังใช้ได้",
            value=str(total - used),
            inline=True,
        )
        embed.add_field(
            name="ห้องยืนยัน",
            value=verify,
            inline=False,
        )
        embed.add_field(
            name="ห้องแอดมิน",
            value=admin,
            inline=False,
        )
        embed.add_field(
            name="ยศ",
            value=role,
            inline=False,
        )

        await interaction.response.send_message(
            embed=embed,
            ephemeral=True,
        )


# =========================================================
# SETUP
# =========================================================

async def setup(bot):
    """
    Bot Loader ของคุณต้องเรียก:
        await module.setup(bot)

    ไม่ใช้การสร้าง app_commands.Command() โดยตรง
    เพื่อให้เข้ากับ discord.py หลายเวอร์ชัน
    """

    init_database()

    cog = Verification(bot)
    await bot.add_cog(cog)

    # สำคัญ: ลงทะเบียน Slash Command ด้วย tree.command decorator
    @bot.tree.command(
        name="verification",
        description="ตั้งค่าระบบยืนยันตัวตน",
    )
    @app_commands.default_permissions(manage_guild=True)
    async def verification(interaction: discord.Interaction):

        if interaction.guild is None:
            await interaction.response.send_message(
                "❌ ใช้คำสั่งนี้ในเซิร์ฟเวอร์เท่านั้น",
                ephemeral=True,
            )
            return

        if not can_manage(interaction):
            await interaction.response.send_message(
                "❌ คุณไม่มีสิทธิ์จัดการระบบนี้",
                ephemeral=True,
            )
            return

        settings = get_settings(interaction.guild.id)

        verify = (
            f"<#{settings['verify_channel_id']}>"
            if settings["verify_channel_id"]
            else "ยังไม่ได้ตั้ง"
        )
        admin = (
            f"<#{settings['admin_channel_id']}>"
            if settings["admin_channel_id"]
            else "ยังไม่ได้ตั้ง"
        )
        role = (
            f"<@&{settings['role_id']}>"
            if settings["role_id"]
            else "ยังไม่ได้ตั้ง"
        )

        embed = discord.Embed(
            title="🛡️ ระบบยืนยันตัวตน",
            description=(
                "ตั้งค่าระบบจากปุ่มด้านล่าง\n\n"
                "🔑 รหัสถูกสร้างแบบสุ่ม\n"
                "♾️ รหัสไม่มีวันหมดอายุ\n"
                "👤 รหัสหนึ่งใช้ได้เพียงคนเดียว\n"
                "🔐 รหัสใหม่จะส่งไปห้องแอดมิน\n🖼️ รองรับรูป/GIF และกำหนดสีได้"
            ),
            color=discord.Color.blurple(),
        )

        embed.add_field(
            name="📋 ห้องยืนยัน",
            value=verify,
            inline=False,
        )
        embed.add_field(
            name="🔐 ห้องแอดมิน",
            value=admin,
            inline=False,
        )
        embed.add_field(
            name="🎖️ ยศ",
            value=role,
            inline=False,
        )
        embed.add_field(
            name="🎨 แถบสีแผง",
            value=str(settings["panel_color"] or DEFAULT_PANEL_COLOR),
            inline=True,
        )
        embed.add_field(
            name="🖼️ รูป/GIF แผง",
            value="ตั้งแล้ว" if settings["panel_image_url"] else "ยังไม่ได้ตั้ง",
            inline=True,
        )
        embed.add_field(
            name="🔑 รูป/GIF รหัส",
            value="ตั้งแล้ว" if settings["code_image_url"] else "ยังไม่ได้ตั้ง",
            inline=True,
        )
        embed.add_field(
            name="สถานะ",
            value="🟢 เปิด" if settings["enabled"] else "🔴 ปิด",
            inline=False,
        )

        await interaction.response.send_message(
            embed=embed,
            view=VerificationSettingsView(cog),
            ephemeral=True,
        )

    print("[F7] Verification System Loaded")
