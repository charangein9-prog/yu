import discord
from discord.ext import commands
from discord import app_commands
from datetime import timedelta
import json
import os
import re

CONFIG_FILE = "link_guard_config.json"

DEFAULT_CONFIG = {
    "enabled": False,
    "invite_enabled": True,
    "delete_message": True,
    "punishment": "timeout",
    "timeout_minutes": 10,
}

INVITE_REGEX = re.compile(
    r"(?:https?://)?(?:www\.)?(?:discord\.gg|discord\.com/invite|discordapp\.com/invite)/[A-Za-z0-9-]+",
    re.IGNORECASE,
)

def load_config():
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data if isinstance(data, dict) else {}
    except Exception as e:
        print(f"[LinkGuard] Config load error: {e}")
    return {}

CONFIG = load_config()

def save_config():
    try:
        tmp = CONFIG_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(CONFIG, f, ensure_ascii=False, indent=2)
        os.replace(tmp, CONFIG_FILE)
    except Exception as e:
        print(f"[LinkGuard] Config save error: {e}")

def get_config(guild_id: int):
    gid = str(guild_id)
    if gid not in CONFIG or not isinstance(CONFIG[gid], dict):
        CONFIG[gid] = DEFAULT_CONFIG.copy()
        save_config()
    else:
        changed = False
        for k, v in DEFAULT_CONFIG.items():
            if k not in CONFIG[gid]:
                CONFIG[gid][k] = v
                changed = True
        if changed:
            save_config()
    return CONFIG[gid]

def has_invite(text: str) -> bool:
    return bool(INVITE_REGEX.search(text or ""))

def punishment_text(cfg):
    names = {
        "timeout": f"⏱️ หมดเวลา ({cfg.get('timeout_minutes', 10)} นาที)",
        "ban": "🔨 แบน",
        "kick": "👢 เตะ",
    }
    return names.get(cfg.get("punishment"), "⏱️ หมดเวลา")

def make_embed(guild):
    cfg = get_config(guild.id)
    e = discord.Embed(
        title="🛡️ Link Guard",
        description="ตั้งค่าระบบป้องกันลิงก์เชิญ Discord",
        color=discord.Color.blurple(),
    )
    e.add_field(name="ระบบ", value="🟢 เปิด" if cfg["enabled"] else "🔴 ปิด", inline=True)
    e.add_field(
        name="Discord Invite",
        value="🟢 เปิด" if cfg["invite_enabled"] else "🔴 ปิด",
        inline=True,
    )
    e.add_field(
        name="ลบข้อความ",
        value="🟢 เปิด" if cfg["delete_message"] else "🔴 ปิด",
        inline=True,
    )
    e.add_field(name="บทลงโทษ", value=punishment_text(cfg), inline=False)
    e.set_footer(text="บันทึกค่าอัตโนมัติ • โหลดค่าเดิมเมื่อ Bot กลับมา")
    return e

class TimeoutModal(discord.ui.Modal, title="ตั้งเวลา Timeout"):
    minutes = discord.ui.TextInput(
        label="จำนวนเวลา (นาที)",
        placeholder="1 - 10080 นาที (สูงสุด 1 สัปดาห์)",
        min_length=1,
        max_length=5,
        required=True,
    )

    def __init__(self, guild_id):
        super().__init__()
        self.guild_id = guild_id

    async def on_submit(self, interaction: discord.Interaction):
        try:
            value = int(str(self.minutes.value).strip())
        except ValueError:
            return await interaction.response.send_message(
                "❌ กรุณาใส่เป็นตัวเลขเท่านั้น", ephemeral=True
            )

        if value < 1 or value > 10080:
            return await interaction.response.send_message(
                "❌ กำหนดได้ตั้งแต่ **1 นาที ถึง 10,080 นาที (7 วัน)**",
                ephemeral=True,
            )

        cfg = get_config(self.guild_id)
        cfg["timeout_minutes"] = value
        save_config()

        days = value // 1440
        hours = (value % 1440) // 60
        mins = value % 60

        parts = []
        if days:
            parts.append(f"{days} วัน")
        if hours:
            parts.append(f"{hours} ชั่วโมง")
        if mins or not parts:
            parts.append(f"{mins} นาที")

        await interaction.response.send_message(
            f"✅ ตั้งเวลา Timeout เป็น **{' '.join(parts)}** ({value} นาที) แล้ว",
            ephemeral=True,
        )


class PunishmentSelect(discord.ui.Select):
    def __init__(self, guild_id):
        self.guild_id = guild_id
        options = [
            discord.SelectOption(label="หมดเวลา", value="timeout", emoji="⏱️"),
            discord.SelectOption(label="แบน", value="ban", emoji="🔨"),
            discord.SelectOption(label="เตะ", value="kick", emoji="👢"),
        ]
        super().__init__(
            placeholder="เลือกบทลงโทษ",
            min_values=1,
            max_values=1,
            options=options,
        )

    async def callback(self, interaction: discord.Interaction):
        if not interaction.guild or not interaction.user.guild_permissions.manage_guild:
            return await interaction.response.send_message(
                "❌ ต้องมีสิทธิ์ Manage Server", ephemeral=True
            )
        cfg = get_config(self.guild_id)
        cfg["punishment"] = self.values[0]
        save_config()

        if self.values[0] == "timeout":
            await interaction.response.send_modal(
                TimeoutModal(self.guild_id)
            )
            return

        await interaction.response.edit_message(
            content=f"✅ ตั้งบทลงโทษเป็น **{punishment_text(cfg)}** แล้ว",
            view=None,
        )

class PunishmentView(discord.ui.View):
    def __init__(self, guild_id):
        super().__init__(timeout=60)
        self.add_item(PunishmentSelect(guild_id))

class LinkGuardView(discord.ui.View):
    def __init__(self, guild_id):
        super().__init__(timeout=None)
        self.guild_id = guild_id

    async def allowed(self, interaction):
        if not interaction.guild:
            await interaction.response.send_message("❌ ใช้ได้เฉพาะในเซิร์ฟเวอร์", ephemeral=True)
            return False
        if not interaction.user.guild_permissions.manage_guild:
            await interaction.response.send_message("❌ ต้องมีสิทธิ์ Manage Server", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="เปิด/ปิดระบบ", emoji="🛡️", style=discord.ButtonStyle.primary)
    async def toggle_system(self, interaction, button):
        if not await self.allowed(interaction):
            return
        cfg = get_config(self.guild_id)
        cfg["enabled"] = not cfg["enabled"]
        save_config()
        await interaction.response.edit_message(embed=make_embed(interaction.guild), view=self)

    @discord.ui.button(label="Invite Discord", emoji="🔗", style=discord.ButtonStyle.secondary)
    async def toggle_invite(self, interaction, button):
        if not await self.allowed(interaction):
            return
        cfg = get_config(self.guild_id)
        cfg["invite_enabled"] = not cfg["invite_enabled"]
        save_config()
        await interaction.response.edit_message(embed=make_embed(interaction.guild), view=self)

    @discord.ui.button(label="ลบข้อความ", emoji="🗑️", style=discord.ButtonStyle.secondary)
    async def toggle_delete(self, interaction, button):
        if not await self.allowed(interaction):
            return
        cfg = get_config(self.guild_id)
        cfg["delete_message"] = not cfg["delete_message"]
        save_config()
        await interaction.response.edit_message(embed=make_embed(interaction.guild), view=self)

    @discord.ui.button(label="ตั้งเวลา Timeout", emoji="⏱️", style=discord.ButtonStyle.secondary)
    async def timeout_settings(self, interaction, button):
        if not await self.allowed(interaction):
            return

        cfg = get_config(self.guild_id)

        if cfg.get("punishment") != "timeout":
            await interaction.response.send_message(
                "ℹ️ กรุณาเลือกบทลงโทษ **หมดเวลา** ก่อน",
                ephemeral=True,
            )
            return

        await interaction.response.send_modal(
            TimeoutModal(self.guild_id)
        )

    @discord.ui.button(label="บทลงโทษ", emoji="⚔️", style=discord.ButtonStyle.success)
    async def punishment(self, interaction, button):
        if not await self.allowed(interaction):
            return
        await interaction.response.send_message(
            "⚔️ เลือกบทลงโทษ",
            view=PunishmentView(self.guild_id),
            ephemeral=True,
        )

class LinkGuard(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.ready = False

    @app_commands.command(
        name="linkguard",
        description="เปิดหน้าตั้งค่าระบบป้องกันลิงก์ Discord",
    )
    @app_commands.default_permissions(manage_guild=True)
    async def linkguard(self, interaction: discord.Interaction):
        if not interaction.guild:
            return await interaction.response.send_message(
                "❌ ใช้ได้เฉพาะในเซิร์ฟเวอร์", ephemeral=True
            )
        if not interaction.user.guild_permissions.manage_guild:
            return await interaction.response.send_message(
                "❌ ต้องมีสิทธิ์ Manage Server", ephemeral=True
            )
        get_config(interaction.guild.id)
        await interaction.response.send_message(
            embed=make_embed(interaction.guild),
            view=LinkGuardView(interaction.guild.id),
            ephemeral=True,
        )

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if not message.guild or message.author.bot:
            return

        cfg = get_config(message.guild.id)

        if not cfg["enabled"] or not cfg["invite_enabled"]:
            return

        if message.author.guild_permissions.administrator:
            return

        if not has_invite(message.content):
            return

        if cfg["delete_message"]:
            try:
                await message.delete()
            except (discord.NotFound, discord.Forbidden):
                pass
            except Exception as e:
                print(f"[LinkGuard] Delete error: {e}")

        member = message.author

        try:
            # ป้องกันไม่ให้บอทลงโทษคนที่มีสิทธิ์สูงกว่าบอท
            if isinstance(member, discord.Member) and member.top_role >= message.guild.me.top_role:
                print(f"[LinkGuard] ข้ามการลงโทษ {member}: role สูงกว่าหรือเท่ากับ Bot")
                return

            punishment = cfg["punishment"]

            if punishment == "timeout":
                minutes = max(1, min(int(cfg.get("timeout_minutes", 10)), 40320))
                await member.timeout(
                    timedelta(minutes=minutes),
                    reason="ส่ง Discord Invite Link",
                )
                action = f"Timeout {minutes} นาที"

            elif punishment == "ban":
                await message.guild.ban(
                    member,
                    reason="ส่ง Discord Invite Link",
                    delete_message_seconds=0,
                )
                action = "Ban"

            else:
                await message.guild.kick(
                    member,
                    reason="ส่ง Discord Invite Link",
                )
                action = "Kick"

            print(
                f"[LinkGuard] {message.guild.name} | "
                f"{member} | {action}"
            )

        except discord.Forbidden:
            print("[LinkGuard] Bot ไม่มีสิทธิ์ดำเนินการ หรือ Role ของสมาชิกสูงกว่า Bot")
        except Exception as e:
            print(f"[LinkGuard] Punishment error: {e}")

async def setup(bot):
    await bot.add_cog(LinkGuard(bot))
    print("[LinkGuard] Loaded successfully")
