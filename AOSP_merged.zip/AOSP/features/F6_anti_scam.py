import discord
from discord.ext import commands
from discord import app_commands
import json
import os
import re
import ipaddress
from datetime import timedelta
from urllib.parse import urlparse

# =========================================================
# F6 - ANTI SCAM / IMAGE & LINK GUARD
# =========================================================

DATA_FILE = "anti_scam_data.json"
DOMAINS_PER_PAGE = 20

DEFAULT_SETTINGS = {
    "enabled": True,
    "delete_suspicious": True,
    "scan_files": True,
    "log_channel_id": 0,
    "exempt_role_ids": [],
    "blocked_domains": [],
    "bot_role_spam_enabled": False,
    "bot_spam_limit": 5,
    "bot_spam_window": 8,
    "bot_role_punishment": "kick",
    "bot_role_spam_delete": True,
    "bot_role_spam_exempt_ids": []
}

URL_REGEX = re.compile(
    r"(https?://[^\s<>()]+|www\.[^\s<>()]+)",
    re.IGNORECASE
)

DANGEROUS_EXTENSIONS = {
    ".exe", ".scr", ".bat", ".cmd", ".com", ".msi",
    ".vbs", ".vbe", ".js", ".jse", ".ps1", ".jar",
    ".apk", ".lnk", ".hta", ".iso"
}


# =========================================================
# DATABASE
# =========================================================

def load_data():
    if not os.path.exists(DATA_FILE):
        return {}

    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data if isinstance(data, dict) else {}
    except Exception as e:
        print(f"[F6] Database read error: {e}")
        return {}


def save_data(data):
    try:
        tmp = DATA_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
        os.replace(tmp, DATA_FILE)
    except Exception as e:
        print(f"[F6] Database save error: {e}")


def get_settings(guild_id):
    data = load_data()
    gid = str(guild_id)

    if gid not in data:
        data[gid] = dict(DEFAULT_SETTINGS)
        data[gid]["exempt_role_ids"] = []
        data[gid]["blocked_domains"] = []
        save_data(data)

    settings = data[gid]
    changed = False

    for key, value in DEFAULT_SETTINGS.items():
        if key not in settings:
            if isinstance(value, list):
                settings[key] = []
            else:
                settings[key] = value
            changed = True

    if changed:
        save_data(data)

    return settings


def save_settings(guild_id, settings):
    data = load_data()
    data[str(guild_id)] = settings
    save_data(data)


# =========================================================
# HELPERS
# =========================================================

def normalize_domain(domain):
    domain = str(domain).strip().lower()
    domain = re.sub(r"^https?://", "", domain)
    domain = re.sub(r"^www\.", "", domain)
    domain = domain.split("/")[0]
    domain = domain.split("?")[0]
    domain = domain.split("#")[0]
    domain = domain.split(":")[0]
    return domain.strip().strip(".")


def valid_domain(domain):
    if not domain or len(domain) > 253:
        return False
    if " " in domain or "." not in domain:
        return False
    return bool(re.fullmatch(
        r"[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?",
        domain,
        re.IGNORECASE
    ))


def extract_urls(text):
    return URL_REGEX.findall(text or "")


def get_hostname(url):
    try:
        if url.lower().startswith("www."):
            url = "https://" + url
        parsed = urlparse(url)
        return parsed.hostname.lower().strip(".") if parsed.hostname else None
    except Exception:
        return None


def is_ip_address(host):
    if not host:
        return False
    try:
        ipaddress.ip_address(host)
        return True
    except ValueError:
        return False


def domain_matches(host, blocked_domains):
    if not host:
        return False

    host = host.lower().strip(".")

    for blocked in blocked_domains:
        blocked = normalize_domain(blocked)
        if not blocked:
            continue

        if host == blocked or host.endswith("." + blocked):
            return True

    return False


def suspicious_url_reason(url):
    try:
        check_url = url
        if check_url.lower().startswith("www."):
            check_url = "https://" + check_url

        parsed = urlparse(check_url)
        host = parsed.hostname

        if not host:
            return None

        if is_ip_address(host):
            return "URL ใช้ IP Address โดยตรง"

        if "xn--" in host.lower():
            return "โดเมนใช้ Punycode"

        if parsed.username:
            return "URL มี username ซ่อนอยู่ก่อนโดเมน"

        return None
    except Exception:
        return None


def dangerous_file(filename):
    if not filename:
        return False

    filename = filename.lower().split("?")[0]

    return any(filename.endswith(ext) for ext in DANGEROUS_EXTENSIONS)


def has_exempt_role(member, settings):
    if not isinstance(member, discord.Member):
        return False

    exempt = set(settings.get("exempt_role_ids", []))
    return any(role.id in exempt for role in member.roles)


# =========================================================
# BOT ROLE + SPAM PROTECTION
# =========================================================

BOT_SPAM_CACHE = {}

def get_bot_shared_roles(member, guild_me):
    if not isinstance(member, discord.Member) or not guild_me:
        return []
    own_ids = {r.id for r in guild_me.roles if r.id != member.guild.id}
    return [r for r in member.roles if r.id in own_ids and r.id != member.guild.id]

def bot_spam_exempt(member, settings):
    return member.id in set(settings.get("bot_role_spam_exempt_ids", []))

def is_bot_spamming(message, settings):
    limit = max(1, int(settings.get("bot_spam_limit", 5)))
    window = max(1, int(settings.get("bot_spam_window", 8)))
    now = discord.utils.utcnow().timestamp()
    key = (message.guild.id, message.author.id)
    timestamps = [t for t in BOT_SPAM_CACHE.get(key, []) if now - t <= window]
    timestamps.append(now)
    BOT_SPAM_CACHE[key] = timestamps
    return len(timestamps) >= limit, len(timestamps), limit

async def punish_bot_for_role_spam(guild, member, settings, shared_roles):
    punishment = str(settings.get("bot_role_punishment", "kick")).lower()
    role_text = ", ".join(f"`{r.name}` (`{r.id}`)" for r in shared_roles)[:900]
    reason = f"F6: Bot spam และมียศร่วมกับบอทหลัก | Shared Role: {role_text}"
    success, result = False, "ไม่สำเร็จ"
    try:
        if punishment == "ban":
            await guild.ban(member, reason=reason, delete_message_seconds=0)
            success, result = True, "แบน"
        elif punishment == "timeout":
            await member.timeout(timedelta(minutes=10), reason=reason)
            success, result = True, "Timeout 10 นาที"
        else:
            await guild.kick(member, reason=reason)
            success, result = True, "เตะ"
    except discord.Forbidden:
        result = "ไม่มีสิทธิ์ลงโทษ"
    except discord.HTTPException as e:
        result = f"Discord API Error: {e}"
    channel_id = settings.get("log_channel_id", 0)
    channel = guild.get_channel(channel_id) if channel_id else None
    if channel:
        embed = discord.Embed(title="🚨 F6 • Bot Spam + Role ซ้ำ", description=f"ตรวจพบ Bot `{member}` สแปมและมียศร่วมกับบอทหลัก", color=discord.Color.red(), timestamp=discord.utils.utcnow())
        embed.add_field(name="Bot", value=f"{member.mention}\n`{member.id}`", inline=False)
        embed.add_field(name="Role ที่ตรงกัน", value=role_text or "ไม่พบ", inline=False)
        embed.add_field(name="การลงโทษ", value=result, inline=True)
        embed.add_field(name="สถานะ", value="สำเร็จ" if success else "ไม่สำเร็จ", inline=True)
        try: await channel.send(embed=embed)
        except Exception as e: print(f"[F6] Bot role spam log error: {e}")
    return success, result

# =========================================================
# LOG
# =========================================================

async def send_log(guild, message, reason, url=None):
    settings = get_settings(guild.id)
    channel_id = settings.get("log_channel_id", 0)

    if not channel_id:
        return

    channel = guild.get_channel(channel_id)
    if not channel:
        return

    embed = discord.Embed(
        title="🛡️ F6 Anti-Scam Alert",
        color=discord.Color.red(),
        timestamp=discord.utils.utcnow()
    )

    embed.add_field(
        name="ผู้ส่ง",
        value=f"{message.author.mention}\n`{message.author.id}`",
        inline=False
    )
    embed.add_field(
        name="ห้อง",
        value=message.channel.mention,
        inline=True
    )
    embed.add_field(
        name="เหตุผล",
        value=reason,
        inline=True
    )

    if url:
        embed.add_field(
            name="ลิงก์",
            value=f"`{str(url)[:1000]}`",
            inline=False
        )

    try:
        await channel.send(embed=embed)
    except Exception as e:
        print(f"[F6] Log error: {e}")


# =========================================================
# MODALS
# =========================================================

class AddDomainModal(discord.ui.Modal, title="➕ เพิ่มโดเมน"):
    domain = discord.ui.TextInput(
        label="โดเมน",
        placeholder="example.com",
        required=True,
        max_length=253
    )

    async def on_submit(self, interaction):
        settings = get_settings(interaction.guild.id)
        domain = normalize_domain(self.domain.value)

        if not valid_domain(domain):
            await interaction.response.send_message(
                "❌ รูปแบบโดเมนไม่ถูกต้อง",
                ephemeral=True
            )
            return

        domains = settings["blocked_domains"]

        if domain in domains:
            await interaction.response.send_message(
                f"⚠️ `{domain}` มีอยู่แล้ว",
                ephemeral=True
            )
            return

        domains.append(domain)
        domains.sort()
        save_settings(interaction.guild.id, settings)

        await interaction.response.send_message(
            f"✅ เพิ่ม `{domain}` สำเร็จ",
            ephemeral=True
        )


class RemoveDomainModal(discord.ui.Modal, title="🗑️ ลบโดเมน"):
    domain = discord.ui.TextInput(
        label="โดเมนที่ต้องการลบ",
        placeholder="example.com",
        required=True,
        max_length=253
    )

    async def on_submit(self, interaction):
        settings = get_settings(interaction.guild.id)
        domain = normalize_domain(self.domain.value)

        if domain not in settings["blocked_domains"]:
            await interaction.response.send_message(
                f"❌ ไม่พบ `{domain}`",
                ephemeral=True
            )
            return

        settings["blocked_domains"].remove(domain)
        save_settings(interaction.guild.id, settings)

        await interaction.response.send_message(
            f"✅ ลบ `{domain}` แล้ว",
            ephemeral=True
        )


class SearchDomainModal(discord.ui.Modal, title="🔎 ค้นหาโดเมน"):
    keyword = discord.ui.TextInput(
        label="คำค้นหา",
        placeholder="เช่น discord หรือ scam",
        required=True,
        max_length=100
    )

    async def on_submit(self, interaction):
        view = DomainManagerView(
            interaction.guild.id,
            search=str(self.keyword.value).strip().lower()
        )

        await interaction.response.send_message(
            embed=view.create_embed(),
            view=view,
            ephemeral=True
        )


class LogChannelModal(discord.ui.Modal, title="📝 ตั้งห้อง Log"):
    channel_id = discord.ui.TextInput(
        label="Channel ID",
        placeholder="123456789012345678",
        required=True,
        max_length=30
    )

    async def on_submit(self, interaction):
        try:
            channel_id = int(str(self.channel_id.value).strip())
        except ValueError:
            await interaction.response.send_message(
                "❌ Channel ID ต้องเป็นตัวเลข",
                ephemeral=True
            )
            return

        channel = interaction.guild.get_channel(channel_id)

        if not channel:
            await interaction.response.send_message(
                "❌ ไม่พบห้องนี้",
                ephemeral=True
            )
            return

        settings = get_settings(interaction.guild.id)
        settings["log_channel_id"] = channel_id
        save_settings(interaction.guild.id, settings)

        await interaction.response.send_message(
            f"✅ ตั้ง Log เป็น {channel.mention}",
            ephemeral=True
        )


class AddRoleModal(discord.ui.Modal, title="👑 เพิ่ม Role ยกเว้น"):
    role_id = discord.ui.TextInput(
        label="Role ID",
        placeholder="123456789012345678",
        required=True,
        max_length=30
    )

    async def on_submit(self, interaction):
        try:
            role_id = int(str(self.role_id.value).strip())
        except ValueError:
            await interaction.response.send_message(
                "❌ Role ID ต้องเป็นตัวเลข",
                ephemeral=True
            )
            return

        role = interaction.guild.get_role(role_id)

        if not role:
            await interaction.response.send_message(
                "❌ ไม่พบ Role",
                ephemeral=True
            )
            return

        settings = get_settings(interaction.guild.id)

        if role_id not in settings["exempt_role_ids"]:
            settings["exempt_role_ids"].append(role_id)
            save_settings(interaction.guild.id, settings)

        await interaction.response.send_message(
            f"✅ เพิ่ม {role.mention} เป็น Role ยกเว้น",
            ephemeral=True
        )


class RemoveRoleModal(discord.ui.Modal, title="🗑️ ลบ Role ยกเว้น"):
    role_id = discord.ui.TextInput(
        label="Role ID",
        placeholder="123456789012345678",
        required=True,
        max_length=30
    )

    async def on_submit(self, interaction):
        try:
            role_id = int(str(self.role_id.value).strip())
        except ValueError:
            await interaction.response.send_message(
                "❌ Role ID ต้องเป็นตัวเลข",
                ephemeral=True
            )
            return

        settings = get_settings(interaction.guild.id)

        if role_id not in settings["exempt_role_ids"]:
            await interaction.response.send_message(
                "❌ Role นี้ไม่ได้อยู่ในรายการ",
                ephemeral=True
            )
            return

        settings["exempt_role_ids"].remove(role_id)
        save_settings(interaction.guild.id, settings)

        await interaction.response.send_message(
            "✅ ลบ Role ยกเว้นแล้ว",
            ephemeral=True
        )


# =========================================================
# DOMAIN MANAGER
# =========================================================

class DomainSelect(discord.ui.Select):
    def __init__(self, parent):
        self.parent = parent

        options = []

        for index, domain in enumerate(parent.current_domains):
            # ใช้ index เป็น value เพื่อไม่ตัดโดเมนยาว
            options.append(
                discord.SelectOption(
                    label=domain[:100],
                    value=str(index),
                    emoji="🔗"
                )
            )

        if not options:
            options.append(
                discord.SelectOption(
                    label="ไม่พบโดเมน",
                    value="none",
                    emoji="❌"
                )
            )

        super().__init__(
            placeholder="🔗 เลือกโดเมนที่ต้องการจัดการ",
            min_values=1,
            max_values=1,
            options=options,
            row=0
        )

    async def callback(self, interaction):
        selected = self.values[0]

        if selected == "none":
            await interaction.response.send_message(
                "❌ ไม่มีโดเมนให้เลือก",
                ephemeral=True
            )
            return

        index = int(selected)

        if index >= len(self.parent.current_domains):
            await interaction.response.send_message(
                "❌ รายการนี้หมดอายุ กรุณากดรีเฟรช",
                ephemeral=True
            )
            return

        self.parent.selected_domain = self.parent.current_domains[index]

        await interaction.response.send_message(
            f"✅ เลือก `{self.parent.selected_domain}` แล้ว\n"
            "กดปุ่ม 🗑️ เพื่อลบโดเมนนี้",
            ephemeral=True
        )


class DomainManagerView(discord.ui.View):
    def __init__(self, guild_id, page=0, search=""):
        super().__init__(timeout=300)

        self.guild_id = guild_id
        self.page = max(0, page)
        self.search = search
        self.selected_domain = None

        settings = get_settings(guild_id)
        all_domains = sorted(settings.get("blocked_domains", []))

        if search:
            all_domains = [
                d for d in all_domains
                if search.lower() in d.lower()
            ]

        self.filtered_domains = all_domains

        start = self.page * DOMAINS_PER_PAGE
        end = start + DOMAINS_PER_PAGE

        self.current_domains = all_domains[start:end]

        self.total_pages = max(
            1,
            (len(all_domains) + DOMAINS_PER_PAGE - 1)
            // DOMAINS_PER_PAGE
        )

        if self.page >= self.total_pages:
            self.page = self.total_pages - 1

        self.previous_button = discord.ui.Button(
            label="ก่อนหน้า",
            emoji="◀️",
            style=discord.ButtonStyle.secondary,
            row=2
        )
        self.next_button = discord.ui.Button(
            label="ถัดไป",
            emoji="▶️",
            style=discord.ButtonStyle.secondary,
            row=2
        )
        self.delete_button = discord.ui.Button(
            label="ลบโดเมนที่เลือก",
            emoji="🗑️",
            style=discord.ButtonStyle.danger,
            row=1
        )
        self.search_button = discord.ui.Button(
            label="ค้นหา",
            emoji="🔎",
            style=discord.ButtonStyle.primary,
            row=1
        )
        self.clear_button = discord.ui.Button(
            label="ล้างค้นหา",
            emoji="🔄",
            style=discord.ButtonStyle.secondary,
            row=1
        )

        self.previous_button.callback = self.previous_page
        self.next_button.callback = self.next_page
        self.delete_button.callback = self.delete_selected
        self.search_button.callback = self.search_domains
        self.clear_button.callback = self.clear_search

        self.add_item(DomainSelect(self))
        self.add_item(self.delete_button)
        self.add_item(self.search_button)
        self.add_item(self.clear_button)
        self.add_item(self.previous_button)
        self.add_item(self.next_button)

        self.update_buttons()

    def update_buttons(self):
        self.previous_button.disabled = self.page <= 0
        self.next_button.disabled = self.page >= self.total_pages - 1

    def create_embed(self):
        start = self.page * DOMAINS_PER_PAGE + 1

        if self.current_domains:
            end = start + len(self.current_domains) - 1
        else:
            end = 0

        title = (
            "🔎 ผลการค้นหาโดเมน"
            if self.search
            else "🚫 จัดการโดเมนที่บล็อก"
        )

        description = ""

        if self.search:
            description += f"คำค้นหา: `{self.search}`\n"

        description += (
            f"\nหน้า **{self.page + 1} / {self.total_pages}**\n"
            f"แสดง **{start}–{end}** "
            f"จาก **{len(self.filtered_domains)}** โดเมน"
        )

        if self.current_domains:
            description += "\n\nเลือกโดเมนจากเมนูด้านล่าง"
        else:
            description += "\n\n❌ ไม่พบโดเมน"

        return discord.Embed(
            title=title,
            description=description,
            color=discord.Color.blurple()
        )

    async def previous_page(self, interaction):
        if self.page <= 0:
            await interaction.response.defer()
            return

        new_view = DomainManagerView(
            self.guild_id,
            self.page - 1,
            self.search
        )

        await interaction.response.edit_message(
            embed=new_view.create_embed(),
            view=new_view
        )

    async def next_page(self, interaction):
        if self.page >= self.total_pages - 1:
            await interaction.response.defer()
            return

        new_view = DomainManagerView(
            self.guild_id,
            self.page + 1,
            self.search
        )

        await interaction.response.edit_message(
            embed=new_view.create_embed(),
            view=new_view
        )

    async def delete_selected(self, interaction):
        if not self.selected_domain:
            await interaction.response.send_message(
                "❌ กรุณาเลือกโดเมนก่อน",
                ephemeral=True
            )
            return

        settings = get_settings(self.guild_id)
        domain = self.selected_domain

        if domain not in settings["blocked_domains"]:
            await interaction.response.send_message(
                "❌ ไม่พบโดเมนนี้แล้ว กรุณารีเฟรช",
                ephemeral=True
            )
            return

        settings["blocked_domains"].remove(domain)
        save_settings(self.guild_id, settings)

        new_view = DomainManagerView(
            self.guild_id,
            self.page,
            self.search
        )

        await interaction.response.edit_message(
            embed=new_view.create_embed(),
            view=new_view
        )

    async def search_domains(self, interaction):
        await interaction.response.send_modal(
            SearchDomainModal()
        )

    async def clear_search(self, interaction):
        new_view = DomainManagerView(
            self.guild_id,
            0,
            ""
        )

        await interaction.response.edit_message(
            embed=new_view.create_embed(),
            view=new_view
        )


# =========================================================
# MAIN UI
# =========================================================

class AntiScamMainView(discord.ui.View):
    def __init__(self, bot, guild_id):
        super().__init__(timeout=300)
        self.bot = bot
        self.guild_id = guild_id

    def settings(self):
        return get_settings(self.guild_id)

    def embed(self):
        s = self.settings()

        enabled = "🟢 เปิด" if s["enabled"] else "🔴 ปิด"
        delete = "🟢 เปิด" if s["delete_suspicious"] else "🔴 ปิด"
        files = "🟢 เปิด" if s["scan_files"] else "🔴 ปิด"
        bot_role_spam = "🟢 เปิด" if s.get("bot_role_spam_enabled", False) else "🔴 ปิด"

        log_id = s.get("log_channel_id", 0)
        log_text = f"<#{log_id}>" if log_id else "ไม่ได้ตั้ง"

        e = discord.Embed(
            title="🛡️ F6 • Anti-Scam",
            description=(
                "ระบบตรวจจับลิงก์/ไฟล์ที่น่าสงสัย "
                "และจัดการโดเมนที่ถูกบล็อก"
            ),
            color=discord.Color.green() if s["enabled"]
            else discord.Color.red()
        )

        e.add_field(name="ระบบ", value=enabled, inline=True)
        e.add_field(name="ลบสิ่งต้องสงสัย", value=delete, inline=True)
        e.add_field(name="ตรวจไฟล์", value=files, inline=True)
        e.add_field(
            name="โดเมนบล็อก",
            value=str(len(s["blocked_domains"])),
            inline=True
        )
        e.add_field(
            name="Role ยกเว้น",
            value=str(len(s["exempt_role_ids"])),
            inline=True
        )
        e.add_field(name="Log", value=log_text, inline=True)
        e.add_field(name="Bot สแปม + ยศซ้ำ", value=bot_role_spam, inline=True)
        e.add_field(name="Limit", value=f"{s.get('bot_spam_limit', 5)} ข้อความ / {s.get('bot_spam_window', 8)} วิ", inline=True)
        e.add_field(name="ลงโทษ", value=str(s.get("bot_role_punishment", "kick")).upper(), inline=True)

        return e

    @discord.ui.button(
        label="เปิด/ปิด",
        emoji="🔘",
        style=discord.ButtonStyle.primary,
        row=0
    )
    async def toggle(self, interaction, button):
        s = self.settings()
        s["enabled"] = not s["enabled"]
        save_settings(self.guild_id, s)

        await interaction.response.edit_message(
            embed=self.embed(),
            view=AntiScamMainView(self.bot, self.guild_id)
        )

    @discord.ui.button(
        label="จัดการโดเมน",
        emoji="🔗",
        style=discord.ButtonStyle.secondary,
        row=0
    )
    async def domains(self, interaction, button):
        view = DomainManagerView(self.guild_id)

        await interaction.response.send_message(
            embed=view.create_embed(),
            view=view,
            ephemeral=True
        )

    @discord.ui.button(
        label="เพิ่มโดเมน",
        emoji="➕",
        style=discord.ButtonStyle.success,
        row=0
    )
    async def add_domain(self, interaction, button):
        await interaction.response.send_modal(
            AddDomainModal()
        )

    @discord.ui.button(
        label="ลบโดเมน",
        emoji="🗑️",
        style=discord.ButtonStyle.danger,
        row=1
    )
    async def remove_domain(self, interaction, button):
        await interaction.response.send_modal(
            RemoveDomainModal()
        )

    @discord.ui.button(
        label="ตั้ง Log",
        emoji="📝",
        style=discord.ButtonStyle.secondary,
        row=1
    )
    async def log_channel(self, interaction, button):
        await interaction.response.send_modal(
            LogChannelModal()
        )

    @discord.ui.button(
        label="เพิ่ม Role ยกเว้น",
        emoji="👑",
        style=discord.ButtonStyle.secondary,
        row=1
    )
    async def add_role(self, interaction, button):
        await interaction.response.send_modal(
            AddRoleModal()
        )

    @discord.ui.button(
        label="ลบ Role ยกเว้น",
        emoji="🚫",
        style=discord.ButtonStyle.secondary,
        row=1
    )
    async def remove_role(self, interaction, button):
        await interaction.response.send_modal(
            RemoveRoleModal()
        )

    @discord.ui.button(
        label="ตรวจไฟล์ ON/OFF",
        emoji="📎",
        style=discord.ButtonStyle.secondary,
        row=2
    )
    async def scan_files(self, interaction, button):
        s = self.settings()
        s["scan_files"] = not s["scan_files"]
        save_settings(self.guild_id, s)

        await interaction.response.edit_message(
            embed=self.embed(),
            view=AntiScamMainView(self.bot, self.guild_id)
        )

    @discord.ui.button(
        label="ลบสิ่งต้องสงสัย ON/OFF",
        emoji="🧹",
        style=discord.ButtonStyle.danger,
        row=2
    )
    async def delete_suspicious(self, interaction, button):
        s = self.settings()
        s["delete_suspicious"] = not s["delete_suspicious"]
        save_settings(self.guild_id, s)

        await interaction.response.edit_message(
            embed=self.embed(),
            view=AntiScamMainView(self.bot, self.guild_id)
        )

    @discord.ui.button(label="Bot สแปม + ยศซ้ำ ON/OFF", emoji="🤖", style=discord.ButtonStyle.primary, row=3)
    async def bot_role_spam_toggle(self, interaction, button):
        s = self.settings(); s["bot_role_spam_enabled"] = not s.get("bot_role_spam_enabled", False); save_settings(self.guild_id, s)
        await interaction.response.edit_message(embed=self.embed(), view=AntiScamMainView(self.bot, self.guild_id))

    @discord.ui.button(label="ตั้งค่าลงโทษ", emoji="⚖️", style=discord.ButtonStyle.danger, row=3)
    async def bot_role_spam_punishment(self, interaction, button):
        s = self.settings(); order = ["kick", "ban", "timeout"]; cur = str(s.get("bot_role_punishment", "kick")); s["bot_role_punishment"] = order[(order.index(cur)+1)%3] if cur in order else "kick"; save_settings(self.guild_id, s)
        await interaction.response.send_message(f"✅ การลงโทษ: **{s['bot_role_punishment']}**", ephemeral=True)

    @discord.ui.button(
        label="รีเฟรช",
        emoji="🔄",
        style=discord.ButtonStyle.success,
        row=3
    )
    async def refresh(self, interaction, button):
        await interaction.response.edit_message(
            embed=self.embed(),
            view=AntiScamMainView(self.bot, self.guild_id)
        )


# =========================================================
# COG
# =========================================================

class F6(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(
        name="antiscam",
        description="เปิดหน้าตั้งค่าระบบป้องกัน Scam"
    )
    @app_commands.default_permissions(manage_guild=True)
    async def antiscam(self, interaction):
        if interaction.guild is None:
            await interaction.response.send_message(
                "❌ ใช้คำสั่งนี้ในเซิร์ฟเวอร์เท่านั้น",
                ephemeral=True
            )
            return

        if not interaction.user.guild_permissions.manage_guild:
            await interaction.response.send_message(
                "❌ ต้องมีสิทธิ์ Manage Server",
                ephemeral=True
            )
            return

        view = AntiScamMainView(
            self.bot,
            interaction.guild.id
        )

        await interaction.response.send_message(
            embed=view.embed(),
            view=view,
            ephemeral=True
        )

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or message.guild is None:
            return

        settings = get_settings(message.guild.id)

        if not settings.get("enabled", True):
            return

        # Bot อื่น + สแปม + มียศร่วมกับบอทหลัก = ลงโทษ
        if (message.author.bot and settings.get("bot_role_spam_enabled", False) and self.bot.user and message.author.id != self.bot.user.id and not bot_spam_exempt(message.author, settings)):
            guild_me = message.guild.me
            if guild_me:
                shared_roles = get_bot_shared_roles(message.author, guild_me)
                if shared_roles:
                    spam, _, _ = is_bot_spamming(message, settings)
                    if spam:
                        if settings.get("bot_role_spam_delete", True):
                            try: await message.delete()
                            except (discord.Forbidden, discord.NotFound): pass
                        key = (message.guild.id, message.author.id, "punished")
                        if key not in BOT_SPAM_CACHE:
                            BOT_SPAM_CACHE[key] = [discord.utils.utcnow().timestamp()]
                            await punish_bot_for_role_spam(message.guild, message.author, settings, shared_roles)
                        return

        if message.author.bot:
            return

        if has_exempt_role(message.author, settings):
            return

        urls = extract_urls(message.content)

        # -----------------------------
        # ตรวจลิงก์
        # -----------------------------
        for url in urls:
            host = get_hostname(url)

            if domain_matches(
                host,
                settings.get("blocked_domains", [])
            ):
                reason = "โดเมนอยู่ในรายการบล็อก"

                await send_log(
                    message.guild,
                    message,
                    reason,
                    url
                )

                if settings.get("delete_suspicious", True):
                    try:
                        await message.delete()
                    except (discord.Forbidden, discord.NotFound):
                        pass

                try:
                    warning = await message.channel.send(
                        f"🚫 {message.author.mention} "
                        "ตรวจพบลิงก์ที่ถูกบล็อก"
                    )
                    await warning.delete(delay=5)
                except Exception:
                    pass

                return

            suspicious = suspicious_url_reason(url)

            if suspicious:
                await send_log(
                    message.guild,
                    message,
                    suspicious,
                    url
                )

        # -----------------------------
        # ตรวจไฟล์
        # -----------------------------
        if settings.get("scan_files", True):
            for attachment in message.attachments:
                if dangerous_file(attachment.filename):
                    reason = (
                        f"ไฟล์น่าสงสัย: "
                        f"{attachment.filename[:150]}"
                    )

                    await send_log(
                        message.guild,
                        message,
                        reason
                    )

                    if settings.get("delete_suspicious", True):
                        try:
                            await message.delete()
                        except (discord.Forbidden, discord.NotFound):
                            pass

                    try:
                        warning = await message.channel.send(
                            f"🚫 {message.author.mention} "
                            "ไฟล์นี้ไม่อนุญาต"
                        )
                        await warning.delete(delay=5)
                    except Exception:
                        pass

                    return


# =========================================================
# BOT LOADER
# =========================================================

async def setup(bot):
    await bot.add_cog(F6(bot))
    print("🛡️ F6 Anti-Scam โหลดสำเร็จ: /antiscam")
