import os
import json
import discord

COMMAND_NAME = "welcome"
DATA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "welcome_data.json")

def load_data():
    if not os.path.exists(DATA_FILE):
        return {}
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            x = json.load(f)
            return x if isinstance(x, dict) else {}
    except Exception as e:
        print(f"❌ อ่านข้อมูลไม่ได้: {e}")
        return {}

def save_data(data):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

data = load_data()

def guild_config(guild_id):
    key = str(guild_id)
    if key not in data:
        data[key] = {"channel_id": None, "message": "ยินดีต้อนรับ {user} เข้าสู่ {server} 🎉", "media_url": None, "media_type": None, "enabled": False}
    return data[key]

def can_manage(member):
    return member.guild_permissions.manage_guild or member.guild_permissions.administrator

def replace_vars(text, member):
    return text.replace("{user}", member.mention).replace("{server}", member.guild.name).replace("{member_count}", str(member.guild.member_count))

class MessageModal(discord.ui.Modal, title="ตั้งข้อความต้อนรับ"):
    message = discord.ui.TextInput(label="ข้อความ", style=discord.TextStyle.paragraph, default="ยินดีต้อนรับ {user} เข้าสู่ {server} 🎉", max_length=2000)
    async def on_submit(self, interaction: discord.Interaction):
        guild_config(interaction.guild.id)["message"] = str(self.message)
        save_data(data)
        await interaction.response.send_message("✅ ตั้งข้อความแล้ว", ephemeral=True)

class MediaModal(discord.ui.Modal, title="ตั้งรูป / GIF / วิดีโอ"):
    url = discord.ui.TextInput(label="URL ของไฟล์", placeholder="https://...", max_length=1000)
    async def on_submit(self, interaction: discord.Interaction):
        url = str(self.url).strip()
        if not url.startswith(("http://", "https://")):
            await interaction.response.send_message("❌ URL ต้องขึ้นต้นด้วย http:// หรือ https://", ephemeral=True)
            return
        cfg = guild_config(interaction.guild.id)
        cfg["media_url"] = url
        cfg["media_type"] = "video" if url.lower().split("?")[0].endswith((".mp4", ".webm", ".mov")) else "image"
        save_data(data)
        await interaction.response.send_message("✅ ตั้งสื่อเรียบร้อยแล้ว", ephemeral=True)

class WelcomeView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    async def check(self, interaction):
        if not can_manage(interaction.user):
            await interaction.response.send_message("❌ ต้องมีสิทธิ์ Manage Server", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="ตั้งห้องต้อนรับ", style=discord.ButtonStyle.primary, emoji="📢", custom_id="welcome:set_channel")
    async def set_channel(self, interaction, button):
        if not await self.check(interaction): return
        cfg = guild_config(interaction.guild.id)
        cfg["channel_id"] = interaction.channel.id
        save_data(data)
        await interaction.response.send_message(f"✅ ตั้งห้องต้อนรับเป็น {interaction.channel.mention} แล้ว", ephemeral=True)

    @discord.ui.button(label="ตั้งข้อความ", style=discord.ButtonStyle.secondary, emoji="✏️", custom_id="welcome:set_message")
    async def set_message(self, interaction, button):
        if not await self.check(interaction): return
        await interaction.response.send_modal(MessageModal())

    @discord.ui.button(label="ตั้งรูป/GIF/วิดีโอ", style=discord.ButtonStyle.secondary, emoji="🖼️", custom_id="welcome:set_media")
    async def set_media(self, interaction, button):
        if not await self.check(interaction): return
        await interaction.response.send_modal(MediaModal())

    @discord.ui.button(label="เปิดระบบ", style=discord.ButtonStyle.success, emoji="✅", custom_id="welcome:enable")
    async def enable(self, interaction, button):
        if not await self.check(interaction): return
        cfg = guild_config(interaction.guild.id)
        if not cfg.get("channel_id"):
            await interaction.response.send_message("❌ ตั้งห้องต้อนรับก่อน", ephemeral=True)
            return
        cfg["enabled"] = True
        save_data(data)
        await interaction.response.send_message("🟢 เปิดระบบต้อนรับแล้ว", ephemeral=True)

    @discord.ui.button(label="ปิดระบบ", style=discord.ButtonStyle.danger, emoji="⛔", custom_id="welcome:disable")
    async def disable(self, interaction, button):
        if not await self.check(interaction): return
        guild_config(interaction.guild.id)["enabled"] = False
        save_data(data)
        await interaction.response.send_message("🔴 ปิดระบบต้อนรับแล้ว", ephemeral=True)

    @discord.ui.button(label="ลบสื่อ", style=discord.ButtonStyle.secondary, emoji="🗑️", custom_id="welcome:clear_media")
    async def clear_media(self, interaction, button):
        if not await self.check(interaction): return
        cfg = guild_config(interaction.guild.id)
        cfg["media_url"] = None
        cfg["media_type"] = None
        save_data(data)
        await interaction.response.send_message("✅ ลบรูป/GIF/วิดีโอแล้ว", ephemeral=True)

def setup_embed(guild):
    cfg = guild_config(guild.id)
    channel = guild.get_channel(cfg.get("channel_id")) if cfg.get("channel_id") else None
    embed = discord.Embed(title="👋 ระบบยินดีต้อนรับ", description="ตั้งค่าระบบของ Server นี้จากปุ่มด้านล่าง\n\n`{user}` = สมาชิกใหม่\n`{server}` = ชื่อ Server\n`{member_count}` = จำนวนสมาชิก", color=discord.Color.blurple())
    embed.add_field(name="📢 ห้อง", value=channel.mention if channel else "ยังไม่ได้ตั้ง", inline=False)
    embed.add_field(name="📌 สถานะ", value="🟢 เปิด" if cfg.get("enabled") else "🔴 ปิด", inline=True)
    embed.add_field(name="🖼️ สื่อ", value="มี" if cfg.get("media_url") else "ไม่มี", inline=True)
    embed.add_field(name="✏️ ข้อความ", value=cfg.get("message", "")[:1024], inline=False)
    embed.set_footer(text="ผู้ตั้งค่าต้องมีสิทธิ์ Manage Server")
    return embed

def setup(bot):
    @bot.tree.command(name=COMMAND_NAME, description="ตั้งค่าระบบยินดีต้อนรับของ Server")
    @discord.app_commands.guild_only()
    @discord.app_commands.checks.has_permissions(manage_guild=True)
    async def welcome(interaction: discord.Interaction):
        await interaction.response.send_message(embed=setup_embed(interaction.guild), view=WelcomeView(), ephemeral=True)

    @welcome.error
    async def welcome_error(interaction, error):
        if isinstance(error, discord.app_commands.errors.MissingPermissions):
            msg = "❌ ต้องมีสิทธิ์ Manage Server"
        else:
            print(f"❌ Welcome command error: {error}")
            msg = "❌ เกิดข้อผิดพลาดในการเปิดระบบต้อนรับ"
        if interaction.response.is_done():
            await interaction.followup.send(msg, ephemeral=True)
        else:
            await interaction.response.send_message(msg, ephemeral=True)

    @bot.listen("on_member_join")
    async def welcome_member(member: discord.Member):
        try:
            cfg = guild_config(member.guild.id)
            if not cfg.get("enabled") or not cfg.get("channel_id"):
                return
            channel = member.guild.get_channel(cfg["channel_id"])
            if channel is None:
                return
            embed = discord.Embed(description=replace_vars(cfg.get("message", ""), member), color=discord.Color.green())
            url = cfg.get("media_url")
            if url and cfg.get("media_type") == "image":
                embed.set_image(url=url)
                await channel.send(embed=embed)
            elif url and cfg.get("media_type") == "video":
                await channel.send(embed=embed)
                await channel.send(url)
            else:
                await channel.send(embed=embed)
        except discord.Forbidden:
            print(f"❌ ไม่มีสิทธิ์ส่งข้อความใน Server {member.guild.id}")
        except Exception as e:
            print(f"❌ Welcome error: {e}")

    bot.add_view(WelcomeView())
    print("✅ F1 Welcome Public Bot โหลดสำเร็จ")
