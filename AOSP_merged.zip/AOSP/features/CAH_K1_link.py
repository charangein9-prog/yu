# ============================================================
# link.py
# Anti-Link System - Discord.py 2.x
# ============================================================
#
# คำสั่ง:
#   /link
#
# ระบบ:
#   🔗 เปิด/ปิดระบบตรวจลิงก์
#   ⚖️ เปิด/ปิดการลงโทษ
#   🗑️ เปิด/ปิดลบข้อความอัตโนมัติ
#   🔨 แบน
#   👢 เตะ
#   ⏱️ Timeout
#   ⏱️ 1 นาที - 7 วัน
#   ♾️ แบนถาวร
#   🛡️ ยกเว้นยศ
#   📊 ดูสถานะ
#
# ข้อมูลเก็บที่:
#   link_settings.json
#
# Token ไม่ต้องใส่ในไฟล์นี้
# ============================================================

import discord
from discord.ext import commands, tasks
from discord import app_commands

import json
import os
import re

from datetime import datetime, timedelta, timezone


# ============================================================
# CONFIG
# ============================================================

DATA_FILE = "link_settings.json"


# ============================================================
# DEFAULT SETTINGS
# ============================================================

DEFAULT_GUILD_DATA = {
    "enabled": True,

    # ตรวจจับลิงก์ทั้งหมด
    "block_all_links": True,

    # เปิด/ปิดการลงโทษ
    "punishment_enabled": True,

    # เปิด/ปิดลบข้อความ
    "auto_delete": True,

    # ban / kick / timeout
    "punishment_type": "timeout",

    # ระยะเวลา
    "punishment_duration": "10m",

    # ยศยกเว้น
    "excluded_roles": [],

    # เวลาที่แก้ไขล่าสุด
    "updated_at": None,

    # สมาชิกที่ถูกแบนชั่วคราว
    "temporary_bans": {}
}


# ============================================================
# LOAD DATA
# ============================================================

def load_data():

    if not os.path.exists(DATA_FILE):
        return {}

    try:

        with open(
            DATA_FILE,
            "r",
            encoding="utf-8"
        ) as file:

            data = json.load(file)

        if isinstance(data, dict):
            return data

        return {}

    except Exception as e:

        print(
            f"[LINK] โหลดข้อมูลไม่สำเร็จ: {e}"
        )

        return {}


settings = load_data()


# ============================================================
# SAVE DATA
# ============================================================

def save_data():

    temp_file = DATA_FILE + ".tmp"

    try:

        with open(
            temp_file,
            "w",
            encoding="utf-8"
        ) as file:

            json.dump(
                settings,
                file,
                ensure_ascii=False,
                indent=4
            )

        os.replace(
            temp_file,
            DATA_FILE
        )

    except Exception as e:

        print(
            f"[LINK] บันทึกข้อมูลไม่สำเร็จ: {e}"
        )


# ============================================================
# GET GUILD SETTINGS
# ============================================================

def get_guild_settings(guild_id: int):

    gid = str(guild_id)

    if gid not in settings:

        settings[gid] = {
            "enabled": True,
            "block_all_links": True,
            "punishment_enabled": True,
            "auto_delete": True,
            "punishment_type": "timeout",
            "punishment_duration": "10m",
            "excluded_roles": [],
            "updated_at": None,
            "temporary_bans": {}
        }

        save_data()

    cfg = settings[gid]

    # --------------------------------------------------------
    # รองรับไฟล์เก่า
    # --------------------------------------------------------

    if "enabled" not in cfg:
        cfg["enabled"] = True

    if "block_all_links" not in cfg:
        cfg["block_all_links"] = True

    if "punishment_enabled" not in cfg:
        cfg["punishment_enabled"] = True

    if "auto_delete" not in cfg:
        cfg["auto_delete"] = True

    if "punishment_type" not in cfg:
        cfg["punishment_type"] = "timeout"

    if "punishment_duration" not in cfg:
        cfg["punishment_duration"] = "10m"

    if "excluded_roles" not in cfg:
        cfg["excluded_roles"] = []

    if "temporary_bans" not in cfg:
        cfg["temporary_bans"] = {}

    if "updated_at" not in cfg:
        cfg["updated_at"] = None

    return cfg


# ============================================================
# UPDATE TIME
# ============================================================

def update_setting_time(guild_id: int):

    cfg = get_guild_settings(guild_id)

    cfg["updated_at"] = datetime.now(
        timezone.utc
    ).isoformat()

    save_data()


# ============================================================
# DURATIONS
# ============================================================

DURATION_SECONDS = {

    "1m": 60,

    "5m": 5 * 60,

    "10m": 10 * 60,

    "30m": 30 * 60,

    "1h": 60 * 60,

    "6h": 6 * 60 * 60,

    "12h": 12 * 60 * 60,

    "1d": 24 * 60 * 60,

    "3d": 3 * 24 * 60 * 60,

    "7d": 7 * 24 * 60 * 60
}


DURATION_NAMES = {

    "1m": "1 นาที",

    "5m": "5 นาที",

    "10m": "10 นาที",

    "30m": "30 นาที",

    "1h": "1 ชั่วโมง",

    "6h": "6 ชั่วโมง",

    "12h": "12 ชั่วโมง",

    "1d": "1 วัน",

    "3d": "3 วัน",

    "7d": "7 วัน"
}


def duration_name(value):

    return DURATION_NAMES.get(
        value,
        "ไม่ทราบ"
    )


# ============================================================
# PUNISHMENT NAMES
# ============================================================

def punishment_name(value):

    names = {

        "ban": "🔨 แบน",

        "kick": "👢 เตะ",

        "timeout": "⏱️ หมดเวลา"
    }

    return names.get(
        value,
        "ไม่ได้ตั้งค่า"
    )


# ============================================================
# LINK REGEX
# ============================================================

URL_REGEX = re.compile(
    r"""
    (
        https?://
        |
        www\.
        |
        discord\.gg/
        |
        discord(?:app)?\.com/invite/
        |
        t\.me/
        |
        telegram\.me/
        |
        bit\.ly/
        |
        tinyurl\.com/
        |
        [a-zA-Z0-9-]+\.
        (
            com|
            net|
            org|
            gg|
            io|
            me|
            xyz|
            shop|
            site|
            online|
            co|
            tv|
            ly|
            dev|
            app|
            store|
            link|
            live|
            pro|
            info|
            biz|
            cc|
            top|
            win|
            vip
        )
    )
    """,
    re.IGNORECASE | re.VERBOSE
)


def contains_link(content: str):

    if not content:
        return False

    return bool(
        URL_REGEX.search(content)
    )


# ============================================================
# CHECK EXCLUDED ROLE
# ============================================================

def is_excluded(
    member: discord.Member,
    cfg
):

    excluded_roles = set(
        str(role_id)
        for role_id in cfg.get(
            "excluded_roles",
            []
        )
    )

    for role in member.roles:

        if str(role.id) in excluded_roles:
            return True

    return False


# ============================================================
# CHECK PERMISSION
# ============================================================

def can_manage_link(
    interaction: discord.Interaction
):

    if not interaction.guild:
        return False

    return (
        interaction.user.guild_permissions.manage_guild
        or
        interaction.user.guild_permissions.administrator
    )


# ============================================================
# EXCLUDED ROLE SELECT
# ============================================================

class ExcludedRoleSelect(
    discord.ui.RoleSelect
):

    def __init__(self):

        super().__init__(
            placeholder="เลือกยศเพื่อเพิ่ม/ลบยกเว้น",
            min_values=1,
            max_values=1
        )

    async def callback(
        self,
        interaction: discord.Interaction
    ):

        if not can_manage_link(interaction):

            await interaction.response.send_message(
                "❌ คุณไม่มีสิทธิ์จัดการระบบนี้",
                ephemeral=True
            )

            return

        role = self.values[0]

        cfg = get_guild_settings(
            interaction.guild.id
        )

        role_id = str(role.id)

        if role_id in cfg["excluded_roles"]:

            cfg["excluded_roles"].remove(
                role_id
            )

            update_setting_time(
                interaction.guild.id
            )

            await interaction.response.send_message(

                f"🗑️ นำ {role.mention} "
                f"ออกจากยศยกเว้นแล้ว",

                ephemeral=True
            )

        else:

            cfg["excluded_roles"].append(
                role_id
            )

            update_setting_time(
                interaction.guild.id
            )

            await interaction.response.send_message(

                f"🛡️ เพิ่ม {role.mention} "
                f"เป็นยศยกเว้นแล้ว",

                ephemeral=True
            )


class ExcludedRoleView(
    discord.ui.View
):

    def __init__(self):

        super().__init__(
            timeout=60
        )

        self.add_item(
            ExcludedRoleSelect()
        )


# ============================================================
# PUNISHMENT TYPE
# ============================================================

class PunishmentTypeSelect(
    discord.ui.Select
):

    def __init__(self):

        options = [

            discord.SelectOption(
                label="แบน",
                description="แบนสมาชิกที่ส่งลิงก์",
                emoji="🔨",
                value="ban"
            ),

            discord.SelectOption(
                label="เตะ",
                description="เตะสมาชิกออกทันที",
                emoji="👢",
                value="kick"
            ),

            discord.SelectOption(
                label="หมดเวลา",
                description="Timeout สมาชิก",
                emoji="⏱️",
                value="timeout"
            )
        ]

        super().__init__(
            placeholder="เลือกบทลงโทษ",
            min_values=1,
            max_values=1,
            options=options
        )

    async def callback(
        self,
        interaction: discord.Interaction
    ):

        if not can_manage_link(interaction):

            await interaction.response.send_message(
                "❌ คุณไม่มีสิทธิ์จัดการระบบนี้",
                ephemeral=True
            )

            return

        cfg = get_guild_settings(
            interaction.guild.id
        )

        punishment = self.values[0]

        cfg["punishment_type"] = punishment

        # ถ้าเลือก Kick
        if punishment == "kick":

            cfg["punishment_duration"] = "none"

            update_setting_time(
                interaction.guild.id
            )

            await interaction.response.send_message(

                "👢 ตั้งบทลงโทษเป็น **เตะ** แล้ว\n\n"
                "สมาชิกจะถูกเตะทันที",

                ephemeral=True
            )

            return

        update_setting_time(
            interaction.guild.id
        )

        await interaction.response.send_message(

            f"{punishment_name(punishment)}\n\n"
            "เลือกเวลาที่ต้องการ:",

            view=DurationView(),

            ephemeral=True
        )


class PunishmentTypeView(
    discord.ui.View
):

    def __init__(self):

        super().__init__(
            timeout=60
        )

        self.add_item(
            PunishmentTypeSelect()
        )


# ============================================================
# DURATION SELECT
# ============================================================

class DurationSelect(
    discord.ui.Select
):

    def __init__(self):

        options = []

        for value, name in DURATION_NAMES.items():

            options.append(

                discord.SelectOption(
                    label=name,
                    value=value,
                    emoji="⏱️"
                )
            )

        options.append(

            discord.SelectOption(
                label="แบนถาวร",
                description="ใช้ได้เฉพาะบทลงโทษแบบแบน",
                value="permanent",
                emoji="♾️"
            )
        )

        super().__init__(
            placeholder="เลือกระยะเวลา",
            min_values=1,
            max_values=1,
            options=options
        )

    async def callback(
        self,
        interaction: discord.Interaction
    ):

        if not can_manage_link(interaction):

            await interaction.response.send_message(
                "❌ คุณไม่มีสิทธิ์จัดการระบบนี้",
                ephemeral=True
            )

            return

        cfg = get_guild_settings(
            interaction.guild.id
        )

        selected = self.values[0]

        punishment = cfg.get(
            "punishment_type",
            "timeout"
        )

        # ----------------------------------------------------
        # แบนถาวรใช้ได้เฉพาะ Ban
        # ----------------------------------------------------

        if (
            selected == "permanent"
            and punishment != "ban"
        ):

            await interaction.response.send_message(

                "❌ **แบนถาวร** "
                "ใช้ได้เฉพาะเมื่อเลือก 🔨 แบน",

                ephemeral=True
            )

            return

        cfg["punishment_duration"] = selected

        update_setting_time(
            interaction.guild.id
        )

        if selected == "permanent":

            await interaction.response.send_message(

                "✅ ตั้งเวลาเป็น "
                "**♾️ แบนถาวร** แล้ว",

                ephemeral=True
            )

        else:

            await interaction.response.send_message(

                f"✅ ตั้งเวลาเป็น "
                f"**{duration_name(selected)}** แล้ว",

                ephemeral=True
            )


class DurationView(
    discord.ui.View
):

    def __init__(self):

        super().__init__(
            timeout=60
        )

        self.add_item(
            DurationSelect()
        )


# ============================================================
# MAIN LINK PANEL
# ============================================================

class LinkPanel(
    discord.ui.View
):

    def __init__(self):

        super().__init__(
            timeout=None
        )

    # ========================================================
    # ENABLE / DISABLE SYSTEM
    # ========================================================

    @discord.ui.button(
        label="เปิด/ปิดระบบ",
        emoji="🔗",
        style=discord.ButtonStyle.primary,
        custom_id="link_system_toggle"
    )
    async def system_toggle(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button
    ):

        if not can_manage_link(interaction):

            await interaction.response.send_message(
                "❌ คุณไม่มีสิทธิ์จัดการระบบนี้",
                ephemeral=True
            )

            return

        cfg = get_guild_settings(
            interaction.guild.id
        )

        cfg["enabled"] = not cfg.get(
            "enabled",
            True
        )

        update_setting_time(
            interaction.guild.id
        )

        if cfg["enabled"]:

            await interaction.response.send_message(
                "🟢 เปิดระบบป้องกันลิงก์แล้ว",
                ephemeral=True
            )

        else:

            await interaction.response.send_message(
                "🔴 ปิดระบบป้องกันลิงก์แล้ว",
                ephemeral=True
            )

    # ========================================================
    # BLOCK ALL LINKS
    # ========================================================

    @discord.ui.button(
        label="แบนลิงก์ทั้งหมด",
        emoji="🚫",
        style=discord.ButtonStyle.danger,
        custom_id="link_block_all"
    )
    async def block_all(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button
    ):

        if not can_manage_link(interaction):

            await interaction.response.send_message(
                "❌ คุณไม่มีสิทธิ์จัดการระบบนี้",
                ephemeral=True
            )

            return

        cfg = get_guild_settings(
            interaction.guild.id
        )

        cfg["block_all_links"] = not cfg.get(
            "block_all_links",
            True
        )

        update_setting_time(
            interaction.guild.id
        )

        if cfg["block_all_links"]:

            await interaction.response.send_message(

                "🚫 🟢 เปิดการตรวจจับลิงก์ทั้งหมดแล้ว",

                ephemeral=True
            )

        else:

            await interaction.response.send_message(

                "🚫 🔴 ปิดการตรวจจับลิงก์ทั้งหมดแล้ว",

                ephemeral=True
            )

    # ========================================================
    # PUNISHMENT ENABLE / DISABLE
    # ========================================================

    @discord.ui.button(
        label="เปิด/ปิดการลงโทษ",
        emoji="⚖️",
        style=discord.ButtonStyle.secondary,
        custom_id="link_punishment_toggle"
    )
    async def punishment_toggle(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button
    ):

        if not can_manage_link(interaction):

            await interaction.response.send_message(
                "❌ คุณไม่มีสิทธิ์จัดการระบบนี้",
                ephemeral=True
            )

            return

        cfg = get_guild_settings(
            interaction.guild.id
        )

        cfg["punishment_enabled"] = not cfg.get(
            "punishment_enabled",
            True
        )

        update_setting_time(
            interaction.guild.id
        )

        if cfg["punishment_enabled"]:

            await interaction.response.send_message(

                "⚖️ 🟢 เปิดการลงโทษแล้ว\n"
                "ระบบสามารถ Ban / Kick / Timeout ได้",

                ephemeral=True
            )

        else:

            await interaction.response.send_message(

                "⚖️ 🔴 ปิดการลงโทษแล้ว\n"
                "ระบบจะไม่ Ban / Kick / Timeout",

                ephemeral=True
            )

    # ========================================================
    # AUTO DELETE ENABLE / DISABLE
    # ========================================================

    @discord.ui.button(
        label="เปิด/ปิดลบข้อความ",
        emoji="🗑️",
        style=discord.ButtonStyle.secondary,
        custom_id="link_auto_delete_toggle"
    )
    async def auto_delete_toggle(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button
    ):

        if not can_manage_link(interaction):

            await interaction.response.send_message(
                "❌ คุณไม่มีสิทธิ์จัดการระบบนี้",
                ephemeral=True
            )

            return

        cfg = get_guild_settings(
            interaction.guild.id
        )

        cfg["auto_delete"] = not cfg.get(
            "auto_delete",
            True
        )

        update_setting_time(
            interaction.guild.id
        )

        if cfg["auto_delete"]:

            await interaction.response.send_message(

                "🗑️ 🟢 เปิดลบข้อความอัตโนมัติแล้ว",

                ephemeral=True
            )

        else:

            await interaction.response.send_message(

                "🗑️ 🔴 ปิดลบข้อความอัตโนมัติแล้ว",

                ephemeral=True
            )

    # ========================================================
    # PUNISHMENT SETTINGS
    # ========================================================

    @discord.ui.button(
        label="กำหนดบทลงโทษ",
        emoji="⚙️",
        style=discord.ButtonStyle.secondary,
        custom_id="link_punishment_settings"
    )
    async def punishment_settings(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button
    ):

        if not can_manage_link(interaction):

            await interaction.response.send_message(
                "❌ คุณไม่มีสิทธิ์จัดการระบบนี้",
                ephemeral=True
            )

            return

        cfg = get_guild_settings(
            interaction.guild.id
        )

        current_type = punishment_name(
            cfg.get(
                "punishment_type",
                "timeout"
            )
        )

        current_duration = cfg.get(
            "punishment_duration",
            "10m"
        )

        if current_duration == "permanent":

            duration_text = "♾️ แบนถาวร"

        elif current_duration == "none":

            duration_text = "ไม่มี"

        else:

            duration_text = duration_name(
                current_duration
            )

        await interaction.response.send_message(

            f"⚙️ **กำหนดบทลงโทษ**\n\n"
            f"ประเภท: {current_type}\n"
            f"เวลา: **{duration_text}**\n\n"
            "เลือกประเภท:",

            view=PunishmentTypeView(),

            ephemeral=True
        )

    # ========================================================
    # EXCLUDED ROLE
    # ========================================================

    @discord.ui.button(
        label="ยกเว้นยศ",
        emoji="🛡️",
        style=discord.ButtonStyle.secondary,
        custom_id="link_excluded_role"
    )
    async def excluded_role(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button
    ):

        if not can_manage_link(interaction):

            await interaction.response.send_message(
                "❌ คุณไม่มีสิทธิ์จัดการระบบนี้",
                ephemeral=True
            )

            return

        cfg = get_guild_settings(
            interaction.guild.id
        )

        roles = []

        for role_id in cfg.get(
            "excluded_roles",
            []
        ):

            try:

                role = interaction.guild.get_role(
                    int(role_id)
                )

            except Exception:

                role = None

            if role:

                roles.append(
                    role.mention
                )

        if roles:

            current = "\n".join(
                f"• {role}"
                for role in roles
            )

        else:

            current = "ไม่มี"

        await interaction.response.send_message(

            "🛡️ **ยศยกเว้น**\n\n"
            f"{current}\n\n"
            "เลือกยศด้านล่าง\n"
            "• ยศที่ยังไม่มี = เพิ่มยกเว้น\n"
            "• ยศที่มีอยู่ = ลบออกจากยกเว้น",

            view=ExcludedRoleView(),

            ephemeral=True
        )

    # ========================================================
    # STATUS
    # ========================================================

    @discord.ui.button(
        label="ดูสถานะ",
        emoji="📊",
        style=discord.ButtonStyle.secondary,
        custom_id="link_status"
    )
    async def status(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button
    ):

        cfg = get_guild_settings(
            interaction.guild.id
        )

        system = (
            "🟢 เปิด"
            if cfg.get(
                "enabled",
                True
            )
            else "🔴 ปิด"
        )

        all_links = (
            "🟢 เปิด"
            if cfg.get(
                "block_all_links",
                True
            )
            else "🔴 ปิด"
        )

        punishment_enabled = (
            "🟢 เปิด"
            if cfg.get(
                "punishment_enabled",
                True
            )
            else "🔴 ปิด"
        )

        auto_delete = (
            "🟢 เปิด"
            if cfg.get(
                "auto_delete",
                True
            )
            else "🔴 ปิด"
        )

        punishment = punishment_name(
            cfg.get(
                "punishment_type",
                "timeout"
            )
        )

        duration = cfg.get(
            "punishment_duration",
            "10m"
        )

        if duration == "permanent":

            duration_text = "♾️ แบนถาวร"

        elif duration == "none":

            duration_text = "ไม่มี"

        else:

            duration_text = duration_name(
                duration
            )

        roles = []

        for role_id in cfg.get(
            "excluded_roles",
            []
        ):

            try:

                role = interaction.guild.get_role(
                    int(role_id)
                )

            except Exception:

                role = None

            if role:

                roles.append(
                    role.mention
                )

        role_text = (
            ", ".join(roles)
            if roles
            else "ไม่มี"
        )

        updated = cfg.get(
            "updated_at"
        )

        if updated:

            try:

                dt = datetime.fromisoformat(
                    updated
                )

                updated_text = discord.utils.format_dt(
                    dt,
                    "F"
                )

            except Exception:

                updated_text = updated

        else:

            updated_text = "ยังไม่มี"

        embed = discord.Embed(

            title="🔗 Anti-Link",

            description="สถานะระบบป้องกันลิงก์",

            color=discord.Color.blurple()
        )

        embed.add_field(
            name="ระบบ",
            value=system,
            inline=True
        )

        embed.add_field(
            name="ตรวจลิงก์ทั้งหมด",
            value=all_links,
            inline=True
        )

        embed.add_field(
            name="การลงโทษ",
            value=punishment_enabled,
            inline=True
        )

        embed.add_field(
            name="ลบข้อความ",
            value=auto_delete,
            inline=True
        )

        embed.add_field(
            name="บทลงโทษ",
            value=punishment,
            inline=True
        )

        embed.add_field(
            name="ระยะเวลา",
            value=duration_text,
            inline=True
        )

        embed.add_field(
            name="ยศยกเว้น",
            value=role_text,
            inline=False
        )

        embed.add_field(
            name="แก้ไขล่าสุด",
            value=updated_text,
            inline=False
        )

        await interaction.response.send_message(

            embed=embed,

            ephemeral=True
        )


# ============================================================
# COG
# ============================================================

class Link(commands.Cog):

    def __init__(
        self,
        bot
    ):

        self.bot = bot

        self.expire_bans.start()

    def cog_unload(self):

        self.expire_bans.cancel()

    # ========================================================
    # /link
    # ========================================================

    @app_commands.command(
        name="link",
        description="เปิดเมนูระบบป้องกันลิงก์"
    )
    @app_commands.checks.has_permissions(
        manage_guild=True
    )
    async def link(
        self,
        interaction: discord.Interaction
    ):

        cfg = get_guild_settings(
            interaction.guild.id
        )

        system = (
            "🟢 เปิด"
            if cfg.get(
                "enabled",
                True
            )
            else "🔴 ปิด"
        )

        punishment_enabled = (
            "🟢 เปิด"
            if cfg.get(
                "punishment_enabled",
                True
            )
            else "🔴 ปิด"
        )

        auto_delete = (
            "🟢 เปิด"
            if cfg.get(
                "auto_delete",
                True
            )
            else "🔴 ปิด"
        )

        punishment = punishment_name(
            cfg.get(
                "punishment_type",
                "timeout"
            )
        )

        duration = cfg.get(
            "punishment_duration",
            "10m"
        )

        if duration == "permanent":

            duration_text = "♾️ แบนถาวร"

        elif duration == "none":

            duration_text = "ไม่มี"

        else:

            duration_text = duration_name(
                duration
            )

        embed = discord.Embed(

            title="🔗 ระบบป้องกันลิงก์",

            description=(

                "จัดการระบบป้องกันลิงก์ "
                "จากเมนูด้านล่าง\n\n"

                "🔗 ระบบตรวจจับลิงก์ทั้งหมด\n"
                "⚖️ เลือกบทลงโทษ\n"
                "🛡️ ยกเว้นยศ\n"
                "🗑️ ลบข้อความอัตโนมัติ\n"
                "📊 ดูสถานะ"
            ),

            color=discord.Color.blurple()
        )

        embed.add_field(
            name="ระบบ",
            value=system,
            inline=True
        )

        embed.add_field(
            name="การลงโทษ",
            value=punishment_enabled,
            inline=True
        )

        embed.add_field(
            name="ลบข้อความ",
            value=auto_delete,
            inline=True
        )

        embed.add_field(
            name="บทลงโทษ",
            value=punishment,
            inline=True
        )

        embed.add_field(
            name="เวลา",
            value=duration_text,
            inline=True
        )

        await interaction.response.send_message(

            embed=embed,

            view=LinkPanel(),

            ephemeral=True
        )

    # ========================================================
    # MESSAGE LISTENER
    # ========================================================

    @commands.Cog.listener()
    async def on_message(
        self,
        message: discord.Message
    ):

        # ไม่ตรวจ Bot
        if message.author.bot:
            return

        # ไม่ตรวจ DM
        if not message.guild:
            return

        cfg = get_guild_settings(
            message.guild.id
        )

        # ----------------------------------------------------
        # ระบบปิด
        # ----------------------------------------------------

        if not cfg.get(
            "enabled",
            True
        ):
            return

        # ----------------------------------------------------
        # ปิดการตรวจลิงก์ทั้งหมด
        # ----------------------------------------------------

        if not cfg.get(
            "block_all_links",
            True
        ):
            return

        # ----------------------------------------------------
        # ต้องเป็น Member
        # ----------------------------------------------------

        if not isinstance(
            message.author,
            discord.Member
        ):
            return

        # ----------------------------------------------------
        # ยศยกเว้น
        # ----------------------------------------------------

        if is_excluded(
            message.author,
            cfg
        ):
            return

        # ----------------------------------------------------
        # ตรวจลิงก์
        # ----------------------------------------------------

        if not contains_link(
            message.content
        ):
            return

        # ----------------------------------------------------
        # ลบข้อความ
        # ----------------------------------------------------

        if cfg.get(
            "auto_delete",
            True
        ):

            try:

                await message.delete()

            except discord.Forbidden:

                print(
                    "[LINK] ไม่มีสิทธิ์ลบข้อความ"
                )

            except discord.NotFound:

                pass

            except Exception as e:

                print(
                    f"[LINK] Delete Error: {e}"
                )

        # ----------------------------------------------------
        # ปิดการลงโทษ
        # ----------------------------------------------------

        if not cfg.get(
            "punishment_enabled",
            True
        ):

            return

        # ----------------------------------------------------
        # อ่านการตั้งค่า
        # ----------------------------------------------------

        punishment = cfg.get(
            "punishment_type",
            "timeout"
        )

        duration = cfg.get(
            "punishment_duration",
            "10m"
        )

        # ====================================================
        # KICK
        # ====================================================

        if punishment == "kick":

            try:

                await message.author.kick(

                    reason=(
                        "Anti-Link: "
                        "ส่งลิงก์"
                    )
                )

            except discord.Forbidden:

                print(
                    f"[LINK] ไม่มีสิทธิ์ Kick "
                    f"{message.author}"
                )

            except Exception as e:

                print(
                    f"[LINK] Kick Error: {e}"
                )

            return

        # ====================================================
        # PERMANENT BAN
        # ====================================================

        if (
            punishment == "ban"
            and duration == "permanent"
        ):

            try:

                await message.guild.ban(

                    message.author,

                    reason=(
                        "Anti-Link: "
                        "แบนถาวร"
                    )
                )

            except discord.Forbidden:

                print(
                    f"[LINK] ไม่มีสิทธิ์ Ban "
                    f"{message.author}"
                )

            except Exception as e:

                print(
                    f"[LINK] Permanent Ban Error: {e}"
                )

            return

        # ====================================================
        # TEMPORARY BAN
        # ====================================================

        if (
            punishment == "ban"
            and duration in DURATION_SECONDS
        ):

            seconds = DURATION_SECONDS[
                duration
            ]

            now = datetime.now(
                timezone.utc
            )

            expires = (
                now
                + timedelta(
                    seconds=seconds
                )
            )

            try:

                await message.guild.ban(

                    message.author,

                    reason=(
                        "Anti-Link: "
                        f"แบน {duration_name(duration)}"
                    )
                )

            except discord.Forbidden:

                print(
                    f"[LINK] ไม่มีสิทธิ์ Ban "
                    f"{message.author}"
                )

                return

            except Exception as e:

                print(
                    f"[LINK] Ban Error: {e}"
                )

                return

            # ------------------------------------------------
            # บันทึกเวลา
            # ------------------------------------------------

            user_id = str(
                message.author.id
            )

            if "temporary_bans" not in cfg:

                cfg["temporary_bans"] = {}

            cfg["temporary_bans"][user_id] = {

                "user_id":
                    message.author.id,

                "username":
                    str(message.author),

                "start_time":
                    now.isoformat(),

                "expire_time":
                    expires.isoformat(),

                "duration":
                    duration,

                "duration_name":
                    duration_name(duration)
            }

            save_data()

            return

        # ====================================================
        # TIMEOUT
        # ====================================================

        if (
            punishment == "timeout"
            and duration in DURATION_SECONDS
        ):

            seconds = DURATION_SECONDS[
                duration
            ]

            try:

                await message.author.timeout(

                    timedelta(
                        seconds=seconds
                    ),

                    reason=(
                        "Anti-Link: "
                        f"Timeout {duration_name(duration)}"
                    )
                )

            except discord.Forbidden:

                print(
                    f"[LINK] ไม่มีสิทธิ์ Timeout "
                    f"{message.author}"
                )

            except Exception as e:

                print(
                    f"[LINK] Timeout Error: {e}"
                )

            return

    # ========================================================
    # AUTO UNBAN
    # ========================================================

    @tasks.loop(seconds=30)
    async def expire_bans(self):

        now = datetime.now(
            timezone.utc
        )

        changed = False

        for guild_id, cfg in list(
            settings.items()
        ):

            temporary_bans = cfg.get(
                "temporary_bans",
                {}
            )

            if not temporary_bans:
                continue

            guild = self.bot.get_guild(
                int(guild_id)
            )

            if guild is None:
                continue

            for user_id, info in list(
                temporary_bans.items()
            ):

                try:

                    expire_time = datetime.fromisoformat(
                        info["expire_time"]
                    )

                except Exception:

                    del temporary_bans[
                        user_id
                    ]

                    changed = True

                    continue

                if now < expire_time:
                    continue

                # ------------------------------------------------
                # หมดเวลา -> Unban
                # ------------------------------------------------

                try:

                    await guild.unban(

                        discord.Object(
                            id=int(user_id)
                        ),

                        reason=(
                            "Anti-Link: "
                            "ครบกำหนดเวลาแบน"
                        )
                    )

                except discord.NotFound:

                    pass

                except discord.Forbidden:

                    print(
                        f"[LINK] ไม่มีสิทธิ์ Unban "
                        f"{user_id}"
                    )

                    continue

                except Exception as e:

                    print(
                        f"[LINK] Unban Error: {e}"
                    )

                    continue

                del temporary_bans[
                    user_id
                ]

                changed = True

        if changed:

            save_data()

    @expire_bans.before_loop
    async def before_expire_bans(self):

        await self.bot.wait_until_ready()


# ============================================================
# SETUP
# ============================================================

async def setup(bot):

    await bot.add_cog(
        Link(bot)
    )