import os
import json
from datetime import datetime, timezone

import discord
from discord import app_commands

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
DATA_FILE = os.path.join(DATA_DIR, "f4_security.json")
AUDIT_FILE = os.path.join(DATA_DIR, "f4_security_audit.log")

# ============================================================
# ใส่ Discord User ID ที่อนุญาตให้ใช้ F4 ตรงนี้
# ============================================================
ALLOWED_USER_IDS = {
    1385768484264345631,  # <-- เปลี่ยนเป็น User ID ของคุณ
}


os.makedirs(DATA_DIR, exist_ok=True)

DEFAULT = {
    "alert_channel_id": None,
    "notify_on_join": True,
    "notify_on_leave": True,
    "dm_on_join": False,
    "dm_message": "ขอบคุณที่เพิ่มบอทของเราเข้ามาในเซิร์ฟเวอร์ {server}!"
}

def load():
    if not os.path.exists(DATA_FILE):
        return {}
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def save(data):
    tmp = DATA_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)
    os.replace(tmp, DATA_FILE)

def cfg(guild_id):
    data = load()
    gid = str(guild_id)
    changed = False
    if gid not in data:
        data[gid] = DEFAULT.copy()
        changed = True
    else:
        for k, v in DEFAULT.items():
            if k not in data[gid]:
                data[gid][k] = v
                changed = True
    if changed:
        save(data)
    return data[gid]

def setv(guild_id, key, value):
    data = load()
    gid = str(guild_id)
    if gid not in data:
        data[gid] = DEFAULT.copy()
    data[gid][key] = value
    save(data)

def allowed(interaction):
    if interaction.guild is None:
        return False
    return interaction.user.id in ALLOWED_USER_IDS

def audit(action, guild=None, user=None, extra=""):
    now = datetime.now(timezone.utc).isoformat()
    g = f"{guild.name} ({guild.id})" if guild else "-"
    u = f"{user} ({user.id})" if user else "-"
    line = f"[{now}] {action} | guild={g} | user={u}"
    if extra:
        line += f" | {extra}"
    try:
        with open(AUDIT_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass

def security_embed(title, description, color=None):
    if color is None:
        color = discord.Color.blurple()
    return discord.Embed(title=title, description=description, color=color)

class AlertChannelModal(discord.ui.Modal, title="ตั้งห้องแจ้งเตือน"):
    channel_id = discord.ui.TextInput(
        label="Channel ID",
        placeholder="123456789012345678",
        required=True,
        max_length=30
    )

    async def on_submit(self, interaction):
        if not allowed(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return
        try:
            cid = int(self.channel_id.value.strip())
        except ValueError:
            await interaction.response.send_message("❌ Channel ID ไม่ถูกต้อง", ephemeral=True)
            return

        channel = interaction.guild.get_channel(cid)
        if channel is None:
            await interaction.response.send_message("❌ ไม่พบห้องนี้ในเซิร์ฟเวอร์", ephemeral=True)
            return

        setv(interaction.guild.id, "alert_channel_id", cid)
        audit("SET_ALERT_CHANNEL", interaction.guild, interaction.user, f"channel_id={cid}")
        await interaction.response.send_message(
            f"✅ ตั้งห้องแจ้งเตือนเป็น {channel.mention}",
            ephemeral=True
        )

class DMMessageModal(discord.ui.Modal, title="ตั้งข้อความ DM"):
    message = discord.ui.TextInput(
        label="ข้อความ DM",
        style=discord.TextStyle.paragraph,
        required=True,
        max_length=2000,
        placeholder="ขอบคุณที่เพิ่มบอทของเราเข้ามาในเซิร์ฟเวอร์ {server}!"
    )

    async def on_submit(self, interaction):
        if not allowed(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return

        setv(interaction.guild.id, "dm_message", self.message.value)
        audit("SET_DM_MESSAGE", interaction.guild, interaction.user)
        await interaction.response.send_message("✅ บันทึกข้อความ DM แล้ว", ephemeral=True)

class LeaveConfirmView(discord.ui.View):
    def __init__(self, target_guild_id):
        super().__init__(timeout=60)
        self.target_guild_id = int(target_guild_id)

    @discord.ui.button(
        label="ยืนยันออกจากเซิร์ฟเวอร์",
        style=discord.ButtonStyle.danger,
        emoji="🚪"
    )
    async def confirm(self, interaction, button):
        if not allowed(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return

        guild = interaction.client.get_guild(self.target_guild_id)
        if guild is None:
            await interaction.response.edit_message(
                content="❌ ไม่พบเซิร์ฟเวอร์นี้แล้ว",
                embed=None,
                view=None
            )
            return

        name = guild.name
        gid = guild.id
        audit("LEAVE_CONFIRM", guild, interaction.user)

        await interaction.response.edit_message(
            content=f"🚪 กำลังออกจาก **{discord.utils.escape_markdown(name)}** (`{gid}`)...",
            embed=None,
            view=None
        )

        try:
            await guild.leave()
        except discord.HTTPException:
            pass

    @discord.ui.button(
        label="ยกเลิก",
        style=discord.ButtonStyle.secondary,
        emoji="❌"
    )
    async def cancel(self, interaction, button):
        if not allowed(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return
        await interaction.response.edit_message(
            content="ยกเลิกแล้ว ✅",
            embed=None,
            view=None
        )

class ServerListView(discord.ui.View):
    def __init__(self, bot, owner_id):
        super().__init__(timeout=180)
        self.bot = bot
        self.owner_id = owner_id

    def ok(self, interaction):
        return allowed(interaction) and interaction.user.id == self.owner_id

    @discord.ui.select(
        cls=discord.ui.Select,
        placeholder="เลือกเซิร์ฟเวอร์เพื่อจัดการ",
        min_values=1,
        max_values=1,
        row=0
    )
    async def choose(self, interaction, select):
        if not self.ok(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return

        try:
            gid = int(select.values[0])
        except ValueError:
            await interaction.response.send_message("❌ ข้อมูลไม่ถูกต้อง", ephemeral=True)
            return

        guild = self.bot.get_guild(gid)
        if guild is None:
            await interaction.response.send_message("❌ บอทไม่ได้อยู่ในเซิร์ฟเวอร์นี้แล้ว", ephemeral=True)
            return

        await interaction.response.send_message(
            embed=security_embed(
                f"🔗 {guild.name}",
                f"**Server ID:** `{guild.id}`\n"
                f"**สมาชิก:** `{guild.member_count or '?'} `\n\n"
                "กดปุ่มด้านล่างเพื่อสร้างลิงก์ ส่งข้อความเข้าเซิร์ฟเวอร์ หรือสั่งให้บอทออกจากเซิร์ฟเวอร์",
                discord.Color.dark_teal()
            ),
            view=ServerActionView(self.bot, guild.id),
            ephemeral=True
        )

class SendServerMessageModal(discord.ui.Modal, title="📨 ส่งข้อความเข้าเซิร์ฟเวอร์"):
    message = discord.ui.TextInput(
        label="ข้อความที่จะส่ง",
        style=discord.TextStyle.paragraph,
        required=True,
        max_length=2000,
        placeholder="พิมพ์ข้อความที่ต้องการส่ง..."
    )

    def __init__(self, bot, guild_id, channel_id, owner_id):
        super().__init__()
        self.bot = bot
        self.guild_id = int(guild_id)
        self.channel_id = int(channel_id)
        self.owner_id = int(owner_id)

    async def on_submit(self, interaction):
        if not allowed(interaction) or interaction.user.id != self.owner_id:
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return

        guild = self.bot.get_guild(self.guild_id)
        channel = guild.get_channel(self.channel_id) if guild else None
        if channel is None:
            await interaction.response.send_message("❌ ไม่พบห้องนี้", ephemeral=True)
            return

        me = guild.me
        perms = channel.permissions_for(me) if me else None
        if not perms or not perms.view_channel or not perms.send_messages:
            await interaction.response.send_message(
                "❌ บอทไม่มีสิทธิ์ดูหรือส่งข้อความในห้องนี้", ephemeral=True
            )
            return

        try:
            await channel.send(self.message.value)
            audit("SEND_SERVER_MESSAGE", guild, interaction.user,
                  f"channel_id={channel.id}")

            embeds = await build_chat_embeds(channel)
            await interaction.response.send_message(
                embeds=embeds,
                view=ServerChatView(self.bot, interaction.user.id,
                                    guild.id, channel.id),
                ephemeral=True
            )
        except discord.Forbidden:
            await interaction.response.send_message(
                "❌ Discord ปฏิเสธการส่งข้อความในห้องนี้", ephemeral=True
            )
        except discord.HTTPException as e:
            await interaction.response.send_message(
                f"❌ ส่งข้อความไม่สำเร็จ: `{e}`", ephemeral=True
            )


async def build_chat_embeds(channel, limit=25):
    lines = []
    image_urls = []
    try:
        messages = [m async for m in channel.history(limit=limit, oldest_first=True)]
    except discord.Forbidden:
        return [security_embed(
            "💬 แชต",
            "❌ บอทไม่มีสิทธิ์ **Read Message History** ในห้องนี้",
            discord.Color.red()
        )]
    except discord.HTTPException as e:
        return [security_embed("💬 แชต", f"❌ อ่านข้อความไม่สำเร็จ: `{e}`", discord.Color.red())]

    if not messages:
        return [security_embed("💬 แชต", "ยังไม่มีข้อความในห้องนี้", discord.Color.dark_teal())]

    for m in messages:
        ts = discord.utils.format_dt(m.created_at, style="t")
        content = m.content.strip() if m.content else ""
        
        # ดึงข้อความจาก Embeds กรณีข้อความถูกส่งแบบ Embed
        embed_texts = []
        for e in m.embeds:
            if e.title:
                embed_texts.append(f"**{e.title}**")
            if e.description:
                embed_texts.append(e.description)
            for f in e.fields:
                embed_texts.append(f"**{f.name}**: {f.value}")
        
        if embed_texts:
            embed_content = "\n".join(embed_texts)
            content = f"{content}\n{embed_content}".strip()

        if not content:
            content = "(ไม่มีข้อความ — อาจเป็นรูป/ไฟล์/สติกเกอร์)"
        if len(content) > 500:
            content = content[:497] + "..."

        lines.append(f"**{discord.utils.escape_markdown(m.author.display_name)}** • {ts}\n{content}")

        for a in m.attachments:
            lines.append(f"📎 [{discord.utils.escape_markdown(a.filename)}]({a.url})")
            if a.content_type and a.content_type.startswith("image/") and len(image_urls) < 9:
                image_urls.append(a.url)

        for e in m.embeds:
            if e.image and e.image.url and len(image_urls) < 9:
                image_urls.append(e.image.url)

    description = "\n\n".join(lines)
    if len(description) > 3900:
        description = description[-3900:]
        description = "...\n\n" + description

    embeds = [security_embed(
        f"💬 {channel.name}",
        description,
        discord.Color.dark_teal()
    )]
    embeds[0].set_footer(text=f"แสดงข้อความล่าสุด {len(messages)} ข้อความ • กด 🔄 รีเฟรชเพื่อดูข้อความใหม่")

    for url in image_urls:
        e = discord.Embed(color=discord.Color.dark_teal())
        e.set_image(url=url)
        embeds.append(e)

    return embeds[:10]

async def build_chat_embed(channel, limit=25):
    embeds = await build_chat_embeds(channel, limit)
    return embeds[0]

class ServerChatView(discord.ui.View):
    def __init__(self, bot, owner_id, guild_id, channel_id):
        super().__init__(timeout=300)
        self.bot = bot
        self.owner_id = int(owner_id)
        self.guild_id = int(guild_id)
        self.channel_id = int(channel_id)

    def ok(self, interaction):
        return allowed(interaction) and interaction.user.id == self.owner_id

    @discord.ui.button(label="📨 ส่งข้อความ", style=discord.ButtonStyle.primary, row=0)
    async def send(self, interaction, button):
        if not self.ok(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return
        await interaction.response.send_modal(
            SendServerMessageModal(self.bot, self.guild_id, self.channel_id, self.owner_id)
        )

    @discord.ui.button(label="🔄 รีเฟรช", style=discord.ButtonStyle.secondary, row=0)
    async def refresh(self, interaction, button):
        if not self.ok(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return
        guild = self.bot.get_guild(self.guild_id)
        channel = guild.get_channel(self.channel_id) if guild else None
        if channel is None:
            await interaction.response.edit_message(content="❌ ไม่พบห้องนี้", embed=None, view=None)
            return
        await interaction.response.edit_message(
            embed=await build_chat_embed(channel),
            view=ServerChatView(self.bot, self.owner_id, self.guild_id, self.channel_id)
        )

    @discord.ui.button(label="❌ ปิด", style=discord.ButtonStyle.danger, row=0)
    async def close(self, interaction, button):
        if not self.ok(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return
        await interaction.response.edit_message(content="ปิดหน้าดูข้อความแล้ว ✅", embed=None, view=None)


class ServerChannelView(discord.ui.View):
    def __init__(self, bot, owner_id, guild_id):
        super().__init__(timeout=180)
        self.bot = bot
        self.owner_id = owner_id
        self.guild_id = int(guild_id)

        guild = bot.get_guild(self.guild_id)
        options = []
        if guild:
            me = guild.me
            for channel in sorted(guild.text_channels, key=lambda c: c.position):
                if me is not None:
                    perms = channel.permissions_for(me)
                    if not perms.view_channel or not perms.send_messages:
                        continue
                options.append(discord.SelectOption(
                    label=f"#{channel.name}"[:100],
                    value=str(channel.id),
                    description=f"ID: {channel.id}"[:100]
                ))

        select = discord.ui.Select(
            placeholder="เลือกห้องที่จะเปิดดูข้อความ",
            min_values=1,
            max_values=1,
            options=options[:25] if options else [
                discord.SelectOption(label="ไม่พบห้องที่บอทส่งข้อความได้", value="none")
            ]
        )
        select.callback = self.choose_channel
        self.add_item(select)

    async def choose_channel(self, interaction):
        if not (allowed(interaction) and interaction.user.id == self.owner_id):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return

        channel_id = interaction.data.get("values", [None])[0]
        if channel_id == "none" or channel_id is None:
            await interaction.response.send_message("❌ ไม่พบห้องที่บอทสามารถส่งข้อความได้", ephemeral=True)
            return

        guild = self.bot.get_guild(self.guild_id)
        channel = guild.get_channel(int(channel_id)) if guild else None
        if channel is None:
            await interaction.response.send_message("❌ ไม่พบห้องนี้", ephemeral=True)
            return

        await interaction.response.send_message(
            embed=await build_chat_embed(channel),
            view=ServerChatView(self.bot, interaction.user.id, guild.id, channel.id),
            ephemeral=True
        )



class MemberSearchModal(discord.ui.Modal, title="🔎 ค้นหาผู้ใช้"):
    query = discord.ui.TextInput(
        label="ค้นหาชื่อผู้ใช้",
        placeholder="พิมพ์ Username หรือชื่อที่แสดง เช่น GG MO",
        required=True,
        max_length=100
    )

    def __init__(self, bot, owner_id, guild_id, page=0):
        super().__init__()
        self.bot = bot
        self.owner_id = int(owner_id)
        self.guild_id = int(guild_id)
        self.page = int(page)

    async def on_submit(self, interaction):
        if not allowed(interaction) or interaction.user.id != self.owner_id:
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return

        guild = self.bot.get_guild(self.guild_id)
        if guild is None:
            await interaction.response.send_message("❌ ไม่พบเซิร์ฟเวอร์นี้", ephemeral=True)
            return

        q = self.query.value.strip().lower()
        if not q:
            await interaction.response.send_message("❌ กรุณาพิมพ์ชื่อที่ต้องการค้นหา", ephemeral=True)
            return

        members = list(guild.members)
        results = []
        for member in members:
            username = member.name or ""
            display = member.display_name or ""
            global_name = getattr(member, "global_name", None) or ""
            if q in username.lower() or q in display.lower() or q in global_name.lower():
                results.append(member)

        results.sort(key=lambda m: (m.bot, (m.display_name or m.name or "").lower()))

        if not results:
            await interaction.response.edit_message(
                embed=security_embed(
                    "👤 จัดการสมาชิก",
                    f"เซิร์ฟเวอร์: **{discord.utils.escape_markdown(guild.name)}**\n\n"
                    f"❌ ไม่พบสมาชิกที่ตรงกับ `{discord.utils.escape_markdown(self.query.value)}`",
                    discord.Color.red()
                ),
                view=MemberListView(self.bot, self.owner_id, guild.id, members, page=0)
            )
            return

        await interaction.response.edit_message(
            embed=build_member_list_embed(guild, results, page=0, query=self.query.value),
            view=MemberListView(self.bot, self.owner_id, guild.id, results, page=0, query=self.query.value)
        )


def build_member_list_embed(guild, members, page=0, query=None):
    per_page = 16
    total = len(members)
    pages = max(1, (total + per_page - 1) // per_page)
    page = max(0, min(page, pages - 1))
    start = page * per_page
    current = members[start:start + per_page]

    lines = []
    for index, member in enumerate(current, start=start + 1):
        username = discord.utils.escape_markdown(member.name or "ไม่ทราบชื่อ")
        display = discord.utils.escape_markdown(member.display_name or member.name or "ไม่ทราบชื่อ")
        lines.append(f"`{index:02d}` 👤 **{display}** — `@{username}`")

    search_text = f"\n🔎 ค้นหา: **{discord.utils.escape_markdown(query)}**" if query else ""
    description = (
        f"**เซิร์ฟเวอร์:** {discord.utils.escape_markdown(guild.name)}\n"
        f"**สมาชิกทั้งหมด:** `{guild.member_count or total}` • **รายการที่พบ:** `{total}`\n"
        f"**หน้า:** `{page + 1}/{pages}`{search_text}\n\n"
        + ("\n".join(lines) if lines else "❌ ไม่มีสมาชิกในหน้านี้")
        + "\n\n👉 กดปุ่มชื่อสมาชิกด้านล่างเพื่อเปิดโปรไฟล์และจัดการทันที"
    )
    return security_embed("👤 จัดการสมาชิก", description, discord.Color.dark_teal())


class MemberListView(discord.ui.View):
    def __init__(self, bot, owner_id, guild_id, members, page=0, query=None):
        super().__init__(timeout=300)
        self.bot = bot
        self.owner_id = int(owner_id)
        self.guild_id = int(guild_id)
        self.members = list(members)
        self.page = int(page)
        self.query = query
        self.per_page = 16
        self.refresh_items()

    def ok(self, interaction):
        return allowed(interaction) and interaction.user.id == self.owner_id

    def refresh_items(self):
        self.clear_items()
        start = self.page * self.per_page
        current = self.members[start:start + self.per_page]

        for offset, member in enumerate(current):
            number = start + offset + 1
            label_name = member.display_name or member.name or "ไม่ทราบชื่อ"
            username = member.name or "unknown"
            label = f"{number:02d} 👤 {label_name}"
            if len(label) > 80:
                label = label[:77] + "..."
            button = discord.ui.Button(
                label=label,
                style=discord.ButtonStyle.secondary,
                row=offset // 4
            )
            button.member_id = member.id
            button.callback = self.member_click
            self.add_item(button)

        nav_row = 4
        search_button = discord.ui.Button(label="🔎 ค้นหา", style=discord.ButtonStyle.primary, row=nav_row)
        search_button.callback = self.search_click
        self.add_item(search_button)

        refresh_button = discord.ui.Button(label="🔄 รีเฟรช", style=discord.ButtonStyle.secondary, row=nav_row)
        refresh_button.callback = self.refresh_click
        self.add_item(refresh_button)

        if self.page > 0:
            prev_button = discord.ui.Button(label="◀ ก่อนหน้า", style=discord.ButtonStyle.secondary, row=nav_row)
            prev_button.callback = self.prev_click
            self.add_item(prev_button)

        pages = max(1, (len(self.members) + self.per_page - 1) // self.per_page)
        if self.page < pages - 1:
            next_button = discord.ui.Button(label="ถัดไป ▶", style=discord.ButtonStyle.secondary, row=nav_row)
            next_button.callback = self.next_click
            self.add_item(next_button)

        close_button = discord.ui.Button(label="❌ ปิด", style=discord.ButtonStyle.danger, row=nav_row)
        close_button.callback = self.close_click
        self.add_item(close_button)

    async def member_click(self, interaction):
        if not self.ok(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return

        await interaction.response.send_message("❌ ไม่สามารถระบุสมาชิกจากปุ่มนี้ได้", ephemeral=True)

    async def search_click(self, interaction):
        if not self.ok(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return
        await interaction.response.send_modal(
            MemberSearchModal(self.bot, self.owner_id, self.guild_id, self.page)
        )

    async def refresh_click(self, interaction):
        if not self.ok(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return
        guild = self.bot.get_guild(self.guild_id)
        if guild is None:
            await interaction.response.send_message("❌ ไม่พบเซิร์ฟเวอร์", ephemeral=True)
            return
        self.members = list(guild.members)
        self.members.sort(key=lambda m: (m.bot, (m.display_name or m.name or "").lower()))
        pages = max(1, (len(self.members) + self.per_page - 1) // self.per_page)
        self.page = min(self.page, pages - 1)
        self.query = None
        self.refresh_items()
        await interaction.response.edit_message(
            embed=build_member_list_embed(guild, self.members, self.page),
            view=self
        )

    async def prev_click(self, interaction):
        if not self.ok(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return
        self.page = max(0, self.page - 1)
        guild = self.bot.get_guild(self.guild_id)
        self.refresh_items()
        await interaction.response.edit_message(
            embed=build_member_list_embed(guild, self.members, self.page, self.query), view=self
        )

    async def next_click(self, interaction):
        if not self.ok(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return
        pages = max(1, (len(self.members) + self.per_page - 1) // self.per_page)
        self.page = min(pages - 1, self.page + 1)
        guild = self.bot.get_guild(self.guild_id)
        self.refresh_items()
        await interaction.response.edit_message(
            embed=build_member_list_embed(guild, self.members, self.page, self.query), view=self
        )

    async def close_click(self, interaction):
        if not self.ok(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return
        await interaction.response.edit_message(content="ปิดหน้าจัดการสมาชิกแล้ว ✅", embed=None, view=None)


class MemberProfileView(discord.ui.View):
    def __init__(self, bot, owner_id, guild_id, member_id, parent_view):
        super().__init__(timeout=300)
        self.bot = bot
        self.owner_id = int(owner_id)
        self.guild_id = int(guild_id)
        self.member_id = int(member_id)
        self.parent_view = parent_view

    def ok(self, interaction):
        return allowed(interaction) and interaction.user.id == self.owner_id

    def target(self):
        guild = self.bot.get_guild(self.guild_id)
        member = guild.get_member(self.member_id) if guild else None
        return guild, member

    def check_target(self, guild, member):
        me = guild.me if guild else None
        if not member or not me:
            return False, "❌ ไม่พบสมาชิก"
        if member == guild.owner:
            return False, "❌ ไม่สามารถจัดการเจ้าของเซิร์ฟเวอร์ได้"
        if member == me:
            return False, "❌ ไม่สามารถจัดการบอทเองได้"
        if member.top_role >= me.top_role:
            return False, "❌ Role ของสมาชิกสูงกว่าหรือเท่ากับ Role สูงสุดของบอท"
        return True, ""

    @discord.ui.button(label="🦶 เตะ", style=discord.ButtonStyle.danger, row=0)
    async def kick(self, interaction, button):
        if not self.ok(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return
        guild, member = self.target()
        ok, reason = self.check_target(guild, member)
        if not ok:
            await interaction.response.send_message(reason, ephemeral=True)
            return
        if not guild.me.guild_permissions.kick_members:
            await interaction.response.send_message("❌ บอทไม่มีสิทธิ์ Kick Members", ephemeral=True)
            return
        try:
            name = member.display_name
            await member.kick(reason=f"F4 moderation by {interaction.user} ({interaction.user.id})")
            audit("KICK_MEMBER", guild, interaction.user, f"target={member} ({member.id})")
            await interaction.response.edit_message(content=f"✅ เตะ **{discord.utils.escape_markdown(name)}** จาก **{discord.utils.escape_markdown(guild.name)}** แล้ว", embed=None, view=None)
        except discord.Forbidden:
            await interaction.response.send_message("❌ Discord ปฏิเสธการเตะ", ephemeral=True)
        except discord.HTTPException as e:
            await interaction.response.send_message(f"❌ เตะไม่สำเร็จ: `{e}`", ephemeral=True)

    @discord.ui.button(label="⏱️ หมดเวลา", style=discord.ButtonStyle.primary, row=0)
    async def timeout_member(self, interaction, button):
        if not self.ok(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return
        guild, member = self.target()
        ok, reason = self.check_target(guild, member)
        if not ok:
            await interaction.response.send_message(reason, ephemeral=True)
            return
        if not guild.me.guild_permissions.moderate_members:
            await interaction.response.send_message("❌ บอทไม่มีสิทธิ์ Moderate Members", ephemeral=True)
            return
        await interaction.response.send_modal(TimeoutModal(self.bot, self.owner_id, self.guild_id, self.member_id))

    @discord.ui.button(label="◀ รายชื่อ", style=discord.ButtonStyle.secondary, row=0)
    async def back(self, interaction, button):
        if not self.ok(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return
        guild = self.bot.get_guild(self.guild_id)
        await interaction.response.edit_message(
            embed=build_member_list_embed(guild, self.parent_view.members, self.parent_view.page, self.parent_view.query),
            view=self.parent_view
        )


async def _member_button_callback(interaction, member_id, parent_view):
    if not parent_view.ok(interaction):
        await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
        return
    guild = parent_view.bot.get_guild(parent_view.guild_id)
    member = guild.get_member(int(member_id)) if guild else None
    if guild is None or member is None:
        await interaction.response.send_message("❌ ไม่พบสมาชิกนี้แล้ว กรุณากด 🔄 รีเฟรช", ephemeral=True)
        return

    username = discord.utils.escape_markdown(member.name or "ไม่ทราบชื่อ")
    display = discord.utils.escape_markdown(member.display_name or member.name or "ไม่ทราบชื่อ")
    avatar = member.display_avatar.url
    created = discord.utils.format_dt(member.created_at, style="D")
    joined = discord.utils.format_dt(member.joined_at, style="D") if member.joined_at else "ไม่ทราบ"
    roles = [r.mention for r in member.roles[1:]]
    role_text = ", ".join(roles[-10:]) if roles else "ไม่มี Role เพิ่มเติม"
    description = (
        f"**ชื่อที่แสดง:** {display}\n"
        f"**Username:** `@{username}`\n"
        f"**User ID:** `{member.id}`\n"
        f"**เซิร์ฟเวอร์:** **{discord.utils.escape_markdown(guild.name)}**\n"
        f"**เข้าร่วมเซิร์ฟเวอร์:** {joined}\n"
        f"**สร้างบัญชี:** {created}\n"
        f"**Bot:** {'ใช่' if member.bot else 'ไม่ใช่'}\n\n"
        f"**Role:** {role_text}\n\n"
        "กด **🦶 เตะ** หรือ **⏱️ หมดเวลา** ด้านล่างเพื่อจัดการสมาชิกทันที"
    )
    embed = security_embed("👤 โปรไฟล์สมาชิก", description, discord.Color.blurple())
    embed.set_thumbnail(url=avatar)
    await interaction.response.edit_message(
        embed=embed,
        view=MemberProfileView(parent_view.bot, parent_view.owner_id, guild.id, member.id, parent_view)
    )


def _refresh_member_button_callbacks(view):
    start = view.page * view.per_page
    current = view.members[start:start + view.per_page]
    idx = 0
    for child in view.children:
        if isinstance(child, discord.ui.Button) and hasattr(child, "member_id"):
            member_id = child.member_id
            async def cb(interaction, member_id=member_id, parent_view=view):
                await _member_button_callback(interaction, member_id, parent_view)
            child.callback = cb
            idx += 1

_original_refresh_items = MemberListView.refresh_items
def _patched_refresh_items(self):
    _original_refresh_items(self)
    _refresh_member_button_callbacks(self)
MemberListView.refresh_items = _patched_refresh_items


class TimeoutModal(discord.ui.Modal, title="⏱️ ตั้งเวลาหมดเวลา"):
    minutes = discord.ui.TextInput(label="จำนวนนาที", placeholder="เช่น 10, 60, 1440", required=True, max_length=6)
    def __init__(self, bot, owner_id, guild_id, member_id):
        super().__init__(); self.bot=bot; self.owner_id=int(owner_id); self.guild_id=int(guild_id); self.member_id=int(member_id)
    async def on_submit(self,interaction):
        if not allowed(interaction) or interaction.user.id!=self.owner_id:
            await interaction.response.send_message("❌ ไม่มีสิทธิ์",ephemeral=True); return
        try: minutes=int(self.minutes.value.strip())
        except ValueError:
            await interaction.response.send_message("❌ ต้องใส่เป็นตัวเลข",ephemeral=True); return
        if not 1<=minutes<=40320:
            await interaction.response.send_message("❌ ระบุ 1–40320 นาที (สูงสุด 28 วัน)",ephemeral=True); return
        guild=self.bot.get_guild(self.guild_id); member=guild.get_member(self.member_id) if guild else None; me=guild.me if guild else None
        if not member or not me:
            await interaction.response.send_message("❌ ไม่พบสมาชิก",ephemeral=True); return
        if not me.guild_permissions.moderate_members:
            await interaction.response.send_message("❌ บอทไม่มีสิทธิ์ Moderate Members",ephemeral=True); return
        if member==guild.owner or member==me or member.top_role>=me.top_role:
            await interaction.response.send_message("❌ ไม่สามารถ Timeout สมาชิกนี้ได้ เพราะลำดับ Role/เจ้าของเซิร์ฟเวอร์",ephemeral=True); return
        try:
            from datetime import timedelta
            await member.timeout(discord.utils.utcnow()+timedelta(minutes=minutes),reason=f"F4 moderation by {interaction.user} ({interaction.user.id})")
            audit("TIMEOUT_MEMBER",guild,interaction.user,f"target={member} ({member.id}) minutes={minutes}")
            await interaction.response.send_message(f"✅ Timeout **{discord.utils.escape_markdown(member.display_name)}** {minutes} นาทีแล้ว", ephemeral=True)
        except discord.Forbidden: await interaction.response.send_message("❌ Discord ปฏิเสธการ Timeout สมาชิกนี้",ephemeral=True)
        except discord.HTTPException as e: await interaction.response.send_message(f"❌ Timeout ไม่สำเร็จ: `{e}`",ephemeral=True)


class MemberManageView(discord.ui.View):
    def __init__(self,bot,owner_id,guild_id=None):
        super().__init__(timeout=300); self.bot=bot; self.owner_id=int(owner_id); self.guild_id=int(guild_id) if guild_id else None
        self.add_item(MemberGuildSelect(bot, owner_id))
        close_button=discord.ui.Button(label="❌ ปิด",style=discord.ButtonStyle.danger,row=1)
        close_button.callback=self.close
        self.add_item(close_button)

    async def close(self,i):
        if not allowed(i) or i.user.id!=self.owner_id:
            await i.response.send_message("❌ ไม่มีสิทธิ์",ephemeral=True); return
        await i.response.edit_message(content="ปิดหน้าจัดการสมาชิกแล้ว ✅",embed=None,view=None)


class MemberGuildSelect(discord.ui.Select):
    def __init__(self, bot, owner_id):
        self.bot=bot; self.owner_id=int(owner_id)
        guilds=sorted(bot.guilds,key=lambda g:g.name.lower())[:25]
        options=[discord.SelectOption(label=g.name[:100],description=f"สมาชิก {g.member_count or '?'} คน • ID {g.id}"[:100],value=str(g.id)) for g in guilds]
        super().__init__(placeholder="🏠 เลือกเซิร์ฟเวอร์ก่อน แล้วดูเฉพาะสมาชิกเซิร์ฟนั้น",min_values=1,max_values=1,options=options or [discord.SelectOption(label="ไม่พบเซิร์ฟเวอร์",value="none")],row=0)

    async def callback(self, interaction):
        if not allowed(interaction) or interaction.user.id!=self.owner_id:
            await interaction.response.send_message("❌ ไม่มีสิทธิ์",ephemeral=True); return
        if self.values[0]=="none":
            await interaction.response.send_message("❌ ไม่พบเซิร์ฟเวอร์",ephemeral=True); return
        guild=self.bot.get_guild(int(self.values[0]))
        if guild is None:
            await interaction.response.send_message("❌ ไม่พบเซิร์ฟเวอร์นี้แล้ว",ephemeral=True); return
        members=sorted(list(guild.members),key=lambda m:(m.bot,(m.display_name or m.name or "").lower()))
        await interaction.response.edit_message(
            embed=build_member_list_embed(guild,members,0),
            view=MemberListView(self.bot,self.owner_id,guild.id,members,0)
        )

class ServerActionView(discord.ui.View):
    def __init__(self, bot, guild_id):
        super().__init__(timeout=120)
        self.bot = bot
        self.guild_id = int(guild_id)

    @discord.ui.button(
        label="สร้างลิงก์เซิร์ฟเวอร์",
        style=discord.ButtonStyle.primary,
        emoji="🔗"
    )
    async def create_link(self, interaction, button):
        if not allowed(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return

        guild = self.bot.get_guild(self.guild_id)
        if guild is None:
            await interaction.response.send_message("❌ ไม่พบเซิร์ฟเวอร์", ephemeral=True)
            return

        await interaction.response.defer(ephemeral=True)

        invite_url = await create_invite(guild)
        if not invite_url:
            await interaction.followup.send(
                "❌ สร้างลิงก์ไม่ได้\n"
                "ให้บอทมีสิทธิ์ **Create Invite** ในห้องข้อความอย่างน้อย 1 ห้อง",
                ephemeral=True
            )
            return

        link_view = discord.ui.View(timeout=120)
        link_view.add_item(
            discord.ui.Button(
                label="🔗 เปิดลิงก์เซิร์ฟเวอร์",
                style=discord.ButtonStyle.link,
                url=invite_url
            )
        )

        audit("CREATE_SERVER_INVITE", guild, interaction.user, invite_url)
        await interaction.followup.send(
            embed=security_embed(
                "🔗 ลิงก์เซิร์ฟเวอร์",
                f"สร้างลิงก์สำหรับ **{guild.name}** สำเร็จแล้ว\n\n"
                "กดปุ่มด้านล่างเพื่อเปิดลิงก์",
                discord.Color.green()
            ),
            view=link_view,
            ephemeral=True
        )

    @discord.ui.button(
        label="📨 ส่งข้อความเข้าเซิร์ฟเวอร์",
        style=discord.ButtonStyle.primary,
        emoji="📨",
        row=1
    )
    async def send_server_message(self, interaction, button):
        if not allowed(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return

        guild = self.bot.get_guild(self.guild_id)
        if guild is None:
            await interaction.response.send_message("❌ ไม่พบเซิร์ฟเวอร์", ephemeral=True)
            return

        me = guild.me
        available = []
        if me is not None:
            for channel in sorted(guild.text_channels, key=lambda c: c.position):
                perms = channel.permissions_for(me)
                if perms.view_channel and perms.send_messages:
                    available.append(channel)

        if not available:
            await interaction.response.send_message(
                "❌ ไม่มีห้องข้อความที่บอทสามารถส่งข้อความได้",
                ephemeral=True
            )
            return

        await interaction.response.send_message(
            embed=security_embed(
                "📨 ส่งข้อความเข้าเซิร์ฟเวอร์",
                f"เซิร์ฟเวอร์: **{guild.name}**\n"
                "เลือกห้องที่ต้องการส่งข้อความด้านล่าง\n\n"
                "⚠️ แสดงห้องได้สูงสุด 25 ห้องต่อหน้า",
                discord.Color.blurple()
            ),
            view=ServerChannelView(self.bot, interaction.user.id, guild.id),
            ephemeral=True
        )

    @discord.ui.button(
        label="👤 จัดการสมาชิก",
        style=discord.ButtonStyle.success,
        emoji="👤",
        row=2
    )
    async def manage_members(self, interaction, button):
        if not allowed(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return
        guild=self.bot.get_guild(self.guild_id)
        if guild is None:
            await interaction.response.send_message("❌ ไม่พบเซิร์ฟเวอร์", ephemeral=True)
            return
        await interaction.response.send_message(
            embed=security_embed("👤 จัดการสมาชิก",f"บอทอยู่ทั้งหมด **{len(self.bot.guilds)}** เซิร์ฟเวอร์\nเลือกเซิร์ฟเวอร์ก่อน แล้วระบบจะแสดงเฉพาะสมาชิกของเซิร์ฟเวอร์ที่เลือก",discord.Color.dark_teal()),
            view=MemberManageView(self.bot,interaction.user.id),ephemeral=True
        )

    @discord.ui.button(
        label="ออกจากเซิร์ฟเวอร์",
        style=discord.ButtonStyle.danger,
        emoji="🚪",
        row=2
    )
    async def leave(self, interaction, button):
        if not allowed(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return

        guild = self.bot.get_guild(self.guild_id)
        if guild is None:
            await interaction.response.send_message("❌ ไม่พบเซิร์ฟเวอร์", ephemeral=True)
            return

        await interaction.response.send_message(
            embed=security_embed(
                "⚠️ ยืนยันการออก",
                f"คุณกำลังจะให้บอทออกจาก **{guild.name}**\n"
                f"ID: `{guild.id}`\n\n"
                "การกระทำนี้จะทำให้ฟีเจอร์ของบอทในเซิร์ฟเวอร์นั้นหยุดทำงาน",
                discord.Color.red()
            ),
            view=LeaveConfirmView(guild.id),
            ephemeral=True
        )

def invite_url_for(guild):
    me = guild.me
    if me is None:
        return None

    channels = sorted(guild.text_channels, key=lambda c: c.position)
    for channel in channels:
        perms = channel.permissions_for(me)
        if perms.create_instant_invite:
            try:
                return f"https://discord.com/channels/{guild.id}/{channel.id}"
            except Exception:
                return None
    return None

async def create_invite(guild):
    me = guild.me
    if me is None:
        return None

    for channel in sorted(guild.text_channels, key=lambda c: c.position):
        perms = channel.permissions_for(me)
        if not perms.create_instant_invite:
            continue
        try:
            invite = await channel.create_invite(
                max_age=0,
                max_uses=0,
                unique=False,
                reason="F4 security server link"
            )
            return invite.url
        except (discord.Forbidden, discord.HTTPException):
            continue
    return None

def server_select_options(bot):
    guilds = sorted(bot.guilds, key=lambda g: g.name.lower())
    return guilds[:25]

def build_server_list_view(bot, owner_id):
    guilds = server_select_options(bot)
    view = ServerListView(bot, owner_id)
    select = view.children[0]
    select.options = [
        discord.SelectOption(
            label=g.name[:100],
            value=str(g.id),
            description=f"ID: {g.id}"[:100]
        )
        for g in guilds
    ]
    return view

# ============================================================
# หน้าแรกของระบบ: ปรับให้เหลือเฉพาะปุ่มจัดการเซิร์ฟเวอร์
# ============================================================
class SecurityView(discord.ui.View):
    def __init__(self, bot):
        super().__init__(timeout=None)
        self.bot = bot

    @discord.ui.button(
        label="📋 จัดการเซิร์ฟเวอร์",
        style=discord.ButtonStyle.success,
        custom_id="f4_servers",
        row=0
    )
    async def servers(self, interaction, button):
        if not allowed(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True)
            return
        guilds = server_select_options(self.bot)
        if not guilds:
            await interaction.response.send_message("ไม่มีเซิร์ฟเวอร์", ephemeral=True)
            return
        await interaction.response.send_message(
            embed=security_embed(
                "📋 เซิร์ฟเวอร์ที่บอทอยู่",
                f"บอทอยู่ทั้งหมด **{len(self.bot.guilds)}** เซิร์ฟเวอร์\n"
                "เลือกเซิร์ฟเวอร์จากเมนูด้านล่าง\n\n"
                "⚠️ รายการในเมนูแสดงได้สูงสุด 25 เซิร์ฟเวอร์ต่อหน้า",
                discord.Color.dark_teal()
            ),
            view=build_server_list_view(self.bot, interaction.user.id),
            ephemeral=True
        )

def panel_embed(guild):
    return security_embed(
        "🔐 F4 — Bot Security",
        "กดปุ่ม **📋 จัดการเซิร์ฟเวอร์** ด้านล่าง เพื่อเลือกดูรายชื่อเซิร์ฟเวอร์ทั้งหมดที่บอทอยู่ "
        "รวมถึงสร้างลิงก์เชิญ ส่งข้อความเข้าเซิร์ฟเวอร์ หรือสั่งให้บอทออกจากเซิร์ฟเวอร์"
    )

def setup(bot):
    @bot.tree.command(name="safety", description="สำหรับผู้พัฒนา")
    async def security(interaction):
        if interaction.guild is None or not allowed(interaction):
            await interaction.response.defer(ephemeral=True)
            audit(
                "UNAUTHORIZED_SAFETY_COMMAND",
                interaction.guild,
                interaction.user,
                "command=/safety"
            )
            return
        await interaction.response.send_message(
            embed=panel_embed(interaction.guild),
            view=SecurityView(bot),
            ephemeral=True
        )

    bot.add_view(SecurityView(bot))

    @bot.event
    async def on_guild_join(guild):
        audit("BOT_JOIN_GUILD", guild)

        c = cfg(guild.id)
        if c.get("notify_on_join") and c.get("alert_channel_id"):
            channel = guild.get_channel(int(c["alert_channel_id"]))
            if channel:
                try:
                    await channel.send(
                        embed=security_embed(
                            "🚨 บอทถูกเพิ่มเข้าเซิร์ฟเวอร์",
                            f"Server: **{guild.name}**\n"
                            f"ID: `{guild.id}`\n"
                            f"สมาชิก: `{guild.member_count or '?'}`",
                            discord.Color.red()
                        )
                    )
                except discord.HTTPException:
                    pass

        if not c.get("dm_on_join"):
            return

        try:
            me = guild.me
            if me is None or not me.guild_permissions.view_audit_log:
                return

            entries = [
                e async for e in guild.audit_logs(
                    limit=10,
                    action=discord.AuditLogAction.bot_add
                )
            ]

            for entry in entries:
                if entry.target and getattr(entry.target, "id", None) == bot.user.id:
                    inviter = entry.user
                    if inviter and inviter.id != bot.user.id:
                        msg = c.get("dm_message", DEFAULT["dm_message"])
                        msg = msg.replace("{server}", guild.name)
                        try:
                            await inviter.send(msg)
                            audit("DM_INVITER_SENT", guild, inviter)
                        except discord.HTTPException:
                            audit("DM_INVITER_FAILED", guild, inviter)
                    break
        except (discord.Forbidden, discord.HTTPException):
            pass

    @bot.event
    async def on_guild_remove(guild):
        audit("BOT_LEFT_GUILD", guild)

    print("✅ F4 Security โหลดแล้ว: /safety")
