import os
import re
import json
import inspect
import discord
from discord import app_commands
from discord.ext import commands

# ============================================================
# ตั้งค่าพาธและไฟล์เก็บข้อมูล (Multi-Guild Config)
# ============================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
DATA_FILE = os.path.join(DATA_DIR, "ticket_config.json")

os.makedirs(DATA_DIR, exist_ok=True)

DEFAULT_CONFIG = {
    "category_id": None,
    "support_role_id": None,
    "refresh_role_id": None,
    "ticket_count": 0,
    "panel_title": "🎟️ ทีมงาน",
    "panel_desc": "กดเลือกรายชื่อด้านล่างและกดปุ่มตกลงเพื่อเปิดห้องคุยส่วนตัว",
    "placeholder_text": "👤 เลือกคนที่ต้องการติดต่อ...",
    "channel_prefix": "ห้อง-{staff}",
    "use_number_suffix": True,
    "send_welcome_embed": True
}

def load_config():
    if not os.path.exists(DATA_FILE):
        return {}
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def save_config(data):
    tmp = DATA_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)
    os.replace(tmp, DATA_FILE)

def get_guild_cfg(guild_id):
    data = load_config()
    gid = str(guild_id)
    if gid not in data:
        data[gid] = DEFAULT_CONFIG.copy()
        save_config(data)
    else:
        for k, v in DEFAULT_CONFIG.items():
            if k not in data[gid]:
                data[gid][k] = v
        save_config(data)
    return data[gid]

def set_guild_cfg(guild_id, key, value):
    data = load_config()
    gid = str(guild_id)
    if gid not in data:
        data[gid] = DEFAULT_CONFIG.copy()
    data[gid][key] = value
    save_config(data)


def clean_name(name_str):
    clean = re.sub(r'[\s_]+', '-', name_str.lower())
    clean = re.sub(r'[^\w\u0E00-\u0E7F-]', '', clean)
    return clean or "user"


# ============================================================
# ฟังก์ชันสร้างห้องคุยส่วนตัว
# ============================================================
async def create_ticket_channel(interaction: discord.Interaction, target_staff: discord.Member):
    await interaction.response.defer(ephemeral=True)

    guild = interaction.guild
    cfg = get_guild_cfg(guild.id)
    
    category_id = cfg.get("category_id")
    support_role_id = cfg.get("support_role_id")
    prefix = cfg.get("channel_prefix", "ห้อง-{staff}")
    use_number = cfg.get("use_number_suffix", True)
    send_embed = cfg.get("send_welcome_embed", True)

    category = guild.get_channel(category_id) if category_id else None
    support_role = guild.get_role(support_role_id) if support_role_id else None

    # เช็กว่ามีห้องเดิมที่เปิดคุยค้างไว้กับผู้คุมคนเดียวกันหรือไม่
    if category and target_staff:
        for ch in category.text_channels:
            user_can_view = ch.permissions_for(interaction.user).view_channel
            staff_can_view = ch.permissions_for(target_staff).view_channel
            
            if user_can_view and staff_can_view and not interaction.user.guild_permissions.administrator:
                await interaction.followup.send(
                    f"❌ คุณ {interaction.user.mention} มีห้องคุยกับ {target_staff.mention} อยู่อยู่แล้ว: {ch.mention}\n"
                    f"กรุณาใช้ห้องเดิมก่อนเปิดห้องใหม่ครับ",
                    ephemeral=True
                )
                return

    count = cfg.get("ticket_count", 0) + 1
    set_guild_cfg(guild.id, "ticket_count", count)

    clean_user = clean_name(interaction.user.display_name)
    clean_staff = clean_name(target_staff.display_name if target_staff else "staff")

    formatted_prefix = prefix.replace("{user}", clean_user).replace("{staff}", clean_staff)

    if use_number:
        channel_name = f"{formatted_prefix}-{count:04d}"
    else:
        channel_name = formatted_prefix

    overwrites = {
        guild.default_role: discord.PermissionOverwrite(view_channel=False),
        interaction.user: discord.PermissionOverwrite(
            view_channel=True, 
            send_messages=True, 
            attach_files=True, 
            read_message_history=True
        ),
        guild.me: discord.PermissionOverwrite(
            view_channel=True, 
            send_messages=True, 
            manage_channels=True, 
            read_message_history=True
        )
    }

    if support_role:
        overwrites[support_role] = discord.PermissionOverwrite(view_channel=False)

    if target_staff:
        overwrites[target_staff] = discord.PermissionOverwrite(
            view_channel=True,
            send_messages=True,
            attach_files=True,
            manage_messages=True,
            read_message_history=True,
            manage_channels=True
        )

    try:
        ticket_channel = await guild.create_text_channel(
            name=channel_name,
            category=category,
            overwrites=overwrites,
            reason=f"Chat opened by {interaction.user} with {target_staff}"
        )
    except Exception as ex:
        await interaction.followup.send(
            f"❌ ไม่สามารถสร้างห้องได้ กรุณาให้สิทธิ์ Administrator แก่ยศบอท ({ex})",
            ephemeral=True
        )
        return

    await interaction.followup.send(
        f"✅ คุณ {interaction.user.mention} สร้างห้องคุยส่วนตัวกับ {target_staff.mention} เรียบร้อยแล้ว: {ticket_channel.mention}",
        ephemeral=True
    )

    if send_embed:
        embed = discord.Embed(
            title=f"💬 คุยส่วนตัว #{count:04d}",
            description=f"สวัสดีคุณ {interaction.user.mention} คุณสามารถเริ่มพูดคุยได้เลยครับ\n\n"
                        f"👑 **คนคุมห้องนี้:** {target_staff.mention}",
            color=discord.Color.green()
        )
        embed.set_footer(text="สิทธิ์การจัดการห้องนี้ขึ้นอยู่กับคนคุมห้องเท่านั้น")

        try:
            await ticket_channel.send(
                content=f"{interaction.user.mention} {target_staff.mention}",
                embed=embed
            )
        except Exception:
            pass
    else:
        try:
            await ticket_channel.send(content=f"{interaction.user.mention} {target_staff.mention}")
        except Exception:
            pass


# ============================================================
# UI แผงหน้างาน: รวมดรอปดาวน์ + ปุ่มตกลง
# ============================================================
class SelectStaffTicketView(discord.ui.View):
    def __init__(self, bot, guild_id):
        super().__init__(timeout=None)
        self.bot = bot
        self.guild_id = guild_id
        self.selected_staff_id = None
        self.refresh_ui()

    def refresh_ui(self):
        self.clear_items()
        guild = self.bot.get_guild(self.guild_id)
        cfg = get_guild_cfg(self.guild_id)
        role = guild.get_role(cfg.get("support_role_id")) if (guild and cfg.get("support_role_id")) else None

        options = []
        if role and role.members:
            for member in role.members:
                if not member.bot:
                    options.append(discord.SelectOption(
                        label=member.display_name,
                        value=str(member.id),
                        description=f"กดเพื่อเลือก {member.name}",
                        emoji="👤"
                    ))

        if not options:
            options.append(discord.SelectOption(
                label="ไม่มีรายชื่อทีมงาน",
                value="none"
            ))

        select_item = discord.ui.Select(
            placeholder=cfg.get("placeholder_text", "👤 เลือกคนที่ต้องการติดต่อ..."),
            options=options[:25],
            row=0,
            custom_id="user_select_staff_menu_inline"
        )
        select_item.callback = self.on_select_change
        self.add_item(select_item)

        confirm_button = discord.ui.Button(
            label="✅ ตกลง",
            style=discord.ButtonStyle.success,
            row=1,
            custom_id="user_confirm_staff_btn_inline"
        )
        confirm_button.callback = self.on_confirm_click
        self.add_item(confirm_button)

    async def on_select_change(self, interaction: discord.Interaction):
        val = interaction.data["values"][0]
        if val == "none":
            self.selected_staff_id = None
            await interaction.response.send_message("❌ ยังไม่มีรายชื่อสมาชิกในยศนี้", ephemeral=True)
            return

        self.selected_staff_id = int(val)
        member = interaction.guild.get_member(self.selected_staff_id)
        
        await interaction.response.send_message(
            f"👍 คุณ {interaction.user.mention} เลือก **{member.mention if member else 'สมาชิก'}** เรียบร้อยแล้ว! กดปุ่ม **'✅ ตกลง'** เพื่อเปิดห้องได้เลย",
            ephemeral=True
        )

    async def on_confirm_click(self, interaction: discord.Interaction):
        if not self.selected_staff_id:
            await interaction.response.send_message("⚠️ กรุณากดเลือกคนจากเมนูดร็อปดาวน์ด้านบนก่อนกดปุ่มตกลงครับ", ephemeral=True)
            return

        target_member = interaction.guild.get_member(self.selected_staff_id)
        if not target_member:
            await interaction.response.send_message("❌ ไม่พบสมาชิกท่านนี้แล้ว", ephemeral=True)
            return

        await create_ticket_channel(interaction, target_staff=target_member)


# ============================================================
# UI แผงควบคุมตั้งค่าระบบ (Admin Dashboard)
# ============================================================
class SetChannelPrefixModal(discord.ui.Modal, title="🏷️ ตั้งค่ารูปแบบชื่อห้อง"):
    def __init__(self, current_prefix):
        super().__init__()
        self.channel_prefix.default = current_prefix

    channel_prefix = discord.ui.TextInput(
        label="ใช้ {user}=ชื่อคนกด, {staff}=ชื่อคนคุม",
        placeholder="เช่น ห้อง-{staff} หรือ work-{user}",
        required=True,
        max_length=50
    )

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        set_guild_cfg(interaction.guild_id, "channel_prefix", self.channel_prefix.value.strip())
        
        view = TicketAdminDashboardView(interaction.client, interaction.guild_id)
        embed = view.build_status_embed(interaction.guild)
        await interaction.edit_original_response(embed=embed, view=view)


class SetPanelMessageModal(discord.ui.Modal, title="📝 ตั้งค่าข้อความแผงตั๋ว"):
    def __init__(self, current_title, current_desc, current_ph):
        super().__init__()
        self.panel_title.default = current_title
        self.panel_desc.default = current_desc
        self.placeholder_text.default = current_ph

    panel_title = discord.ui.TextInput(
        label="หัวข้อแผงตั๋ว (Embed Title)",
        placeholder="เช่น 🎟️ เลือกทีมงาน",
        required=True,
        max_length=100
    )
    panel_desc = discord.ui.TextInput(
        label="รายละเอียดแผงตั๋ว (Embed Description)",
        style=discord.TextStyle.paragraph,
        placeholder="พิมพ์คำอธิบายต้อนรับ...",
        required=True,
        max_length=1000
    )
    placeholder_text = discord.ui.TextInput(
        label="ข้อความช่องเลือก (Dropdown Placeholder)",
        placeholder="เช่น 👤 เลือกคนที่ต้องการติดต่อ...",
        required=True,
        max_length=100
    )

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        set_guild_cfg(interaction.guild_id, "panel_title", self.panel_title.value)
        set_guild_cfg(interaction.guild_id, "panel_desc", self.panel_desc.value)
        set_guild_cfg(interaction.guild_id, "placeholder_text", self.placeholder_text.value)

        view = TicketAdminDashboardView(interaction.client, interaction.guild_id)
        embed = view.build_status_embed(interaction.guild)
        await interaction.edit_original_response(embed=embed, view=view)


class TicketAdminDashboardView(discord.ui.View):
    def __init__(self, bot, guild_id):
        super().__init__(timeout=None)
        self.bot = bot
        self.guild_id = guild_id
        self.update_toggle_buttons()

    def update_toggle_buttons(self):
        cfg = get_guild_cfg(self.guild_id)
        
        use_number = cfg.get("use_number_suffix", True)
        if use_number:
            self.toggle_number_btn.label = "🔢 เลขรันห้อง: เปิดอยู่"
            self.toggle_number_btn.style = discord.ButtonStyle.success
        else:
            self.toggle_number_btn.label = "🔢 เลขรันห้อง: ปิดแล้ว"
            self.toggle_number_btn.style = discord.ButtonStyle.secondary

        send_embed = cfg.get("send_welcome_embed", True)
        if send_embed:
            self.toggle_embed_btn.label = "💬 ข้อความต้อนรับ: เปิดอยู่"
            self.toggle_embed_btn.style = discord.ButtonStyle.success
        else:
            self.toggle_embed_btn.label = "💬 ข้อความต้อนรับ: ปิดแล้ว"
            self.toggle_embed_btn.style = discord.ButtonStyle.secondary

    def build_status_embed(self, guild):
        cfg = get_guild_cfg(guild.id)
        cat = guild.get_channel(cfg.get("category_id")) if cfg.get("category_id") else None
        role = guild.get_role(cfg.get("support_role_id")) if cfg.get("support_role_id") else None
        refresh_role = guild.get_role(cfg.get("refresh_role_id")) if cfg.get("refresh_role_id") else None
        
        staff_count = len([m for m in role.members if not m.bot]) if role else 0
        use_num = "เปิดใช้งาน (-0001)" if cfg.get("use_number_suffix", True) else "ปิดใช้งาน (ไม่มีเลข)"
        send_emb = "เปิดใช้งาน (ส่ง Embed)" if cfg.get("send_welcome_embed", True) else "ปิดใช้งาน (ไม่ส่ง Embed)"

        embed = discord.Embed(
            title="⚙️ แผงควบคุมระบบตั๋ว (Ticket Admin Panel)",
            description=f"จัดการและตั้งค่าระบบตั๋วสำหรับ **{guild.name}**\n\n"
                        f"📁 **หมวดหมู่ห้องตั๋ว (Category):** {cat.mention if cat else '`ยังไม่ได้ตั้งค่า`'}\n"
                        f"🛡️ **ยศทีมงาน (Support Role):** {role.mention if role else '`ยังไม่ได้ตั้งค่า`'} *(มี {staff_count} คน)*\n"
                        f"🔄 **ยศที่อนุญาตให้ใช้ /ticket_refresh:** {refresh_role.mention if refresh_role else '`เฉพาะ Admin`'}\n"
                        f"🏷️ **รูปแบบชื่อห้อง:** `{cfg.get('channel_prefix')}`\n"
                        f"💡 *ตัวแปรในชื่อห้อง: `{'{user}'}` = ชื่อคนกดตั๋ว, `{'{staff}'}` = ชื่อคนคุมห้อง*\n"
                        f"🔢 **ตัวเลขรันห้องท้ายชื่อ:** `{use_num}`\n"
                        f"💬 **ข้อความ Embed เมื่อเปิดห้อง:** `{send_emb}`\n"
                        f"👑 **สิทธิ์คุมห้อง:** `มอบสิทธิ์จัดการห้องให้แก่คนคุมห้องโดยเฉพาะ`\n"
                        f"🚫 **ปุ่มปิดห้อง:** `ปิดการใช้งาน (ไม่มีปุ่มปิดตั๋ว)`\n"
                        f"🔢 **จำนวนตั๋วสะสมทั้งหมด:** `{cfg.get('ticket_count', 0)}` ตั๋ว",
            color=discord.Color.blurple()
        )
        embed.set_footer(text="กดเลือกเมนูหรือปุ่มด้านล่างเพื่อปรับเปลี่ยนการตั้งค่า")
        return embed

    @discord.ui.select(
        cls=discord.ui.ChannelSelect,
        channel_types=[discord.ChannelType.category],
        placeholder="📁 เลือกหมวดหมู่ห้องสำหรับสร้างตั๋ว (Category)",
        min_values=1, max_values=1, row=0
    )
    async def select_category(self, interaction: discord.Interaction, select: discord.ui.ChannelSelect):
        await interaction.response.defer()
        set_guild_cfg(interaction.guild_id, "category_id", select.values[0].id)
        embed = self.build_status_embed(interaction.guild)
        await interaction.edit_original_response(embed=embed, view=self)

    @discord.ui.select(
        cls=discord.ui.RoleSelect,
        placeholder="🛡️ เลือดยศทีมงานที่จะแสดงในดรอปดาวน์",
        min_values=1, max_values=1, row=1
    )
    async def select_role(self, interaction: discord.Interaction, select: discord.ui.RoleSelect):
        await interaction.response.defer()
        set_guild_cfg(interaction.guild_id, "support_role_id", select.values[0].id)
        embed = self.build_status_embed(interaction.guild)
        await interaction.edit_original_response(embed=embed, view=self)

    @discord.ui.select(
        cls=discord.ui.RoleSelect,
        placeholder="🔄 เลือดยศที่อนุญาตให้ใช้คำสั่ง /ticket_refresh",
        min_values=1, max_values=1, row=2
    )
    async def select_refresh_role(self, interaction: discord.Interaction, select: discord.ui.RoleSelect):
        await interaction.response.defer()
        set_guild_cfg(interaction.guild_id, "refresh_role_id", select.values[0].id)
        embed = self.build_status_embed(interaction.guild)
        await interaction.edit_original_response(embed=embed, view=self)

    @discord.ui.button(
        label="🏷️ ตั้งชื่อห้อง",
        style=discord.ButtonStyle.primary,
        emoji="🏷️",
        row=3
    )
    async def set_prefix_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        cfg = get_guild_cfg(interaction.guild_id)
        modal = SetChannelPrefixModal(current_prefix=cfg.get("channel_prefix", "ห้อง-{staff}"))
        await interaction.response.send_modal(modal)

    @discord.ui.button(
        label="📝 ตั้งค่าข้อความแผง",
        style=discord.ButtonStyle.primary,
        emoji="✏️",
        row=3
    )
    async def set_panel_msg_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        cfg = get_guild_cfg(interaction.guild_id)
        modal = SetPanelMessageModal(
            current_title=cfg.get("panel_title"),
            current_desc=cfg.get("panel_desc"),
            current_ph=cfg.get("placeholder_text")
        )
        await interaction.response.send_modal(modal)

    @discord.ui.button(
        label="🔢 เลขรันห้อง: เปิดอยู่",
        style=discord.ButtonStyle.success,
        row=3
    )
    async def toggle_number_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer()
        cfg = get_guild_cfg(interaction.guild_id)
        current_state = cfg.get("use_number_suffix", True)
        
        set_guild_cfg(interaction.guild_id, "use_number_suffix", not current_state)
        
        self.update_toggle_buttons()
        embed = self.build_status_embed(interaction.guild)
        await interaction.edit_original_response(embed=embed, view=self)

    @discord.ui.button(
        label="💬 ข้อความต้อนรับ: เปิดอยู่",
        style=discord.ButtonStyle.success,
        row=4
    )
    async def toggle_embed_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer()
        cfg = get_guild_cfg(interaction.guild_id)
        current_state = cfg.get("send_welcome_embed", True)
        
        set_guild_cfg(interaction.guild_id, "send_welcome_embed", not current_state)
        
        self.update_toggle_buttons()
        embed = self.build_status_embed(interaction.guild)
        await interaction.edit_original_response(embed=embed, view=self)

    @discord.ui.button(
        label="📌 ส่งแผงเลือกคนลงห้องนี้",
        style=discord.ButtonStyle.success,
        emoji="📨",
        row=4
    )
    async def send_panel(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        cfg = get_guild_cfg(interaction.guild_id)
        
        embed = discord.Embed(
            title=cfg.get("panel_title"),
            description=cfg.get("panel_desc"),
            color=discord.Color.blue()
        )
        embed.set_footer(text="เลือกรายชื่อจากเมนูด้านล่างและกดปุ่มตกลงเพื่อเริ่มการติดต่อ")

        view = SelectStaffTicketView(self.bot, interaction.guild_id)
        try:
            await interaction.channel.send(embed=embed, view=view)
            await interaction.followup.send("✅ ส่งแผงเลือกคนลงห้องนี้เรียบร้อยแล้ว!", ephemeral=True)
        except discord.errors.Forbidden:
            await interaction.followup.send(
                "❌ **บอทไม่มีสิทธิ์ส่งข้อความในห้องนี้!**\n"
                "กรุณาตั้งค่าสิทธิ์ให้ยศของบอทเป็น **Administrator** หรือให้สิทธิ์ **Send Messages** ในห้องนี้ครับ",
                ephemeral=True
            )

    @discord.ui.button(
        label="❌ ปิด",
        style=discord.ButtonStyle.danger,
        emoji="✖️",
        row=4
    )
    async def close_panel(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(content="ปิดแผงควบคุมแล้ว ✅", embed=None, view=None)


# ============================================================
# Cog หลัก
# ============================================================
class TicketCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="ticket_setting", description="เปิด UI แผงควบคุมระบบตั๋ว ตั้งค่าชื่อห้อง ข้อความ ปิดเลขท้าย และปิด Embed ต้อนรับ")
    @app_commands.checks.has_permissions(administrator=True)
    async def ticket_setting(self, interaction: discord.Interaction):
        view = TicketAdminDashboardView(self.bot, interaction.guild_id)
        embed = view.build_status_embed(interaction.guild)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

    @app_commands.command(name="ticket_refresh", description="รีเฟรชอัปเดตรายชื่อทีมงาน")
    async def ticket_refresh(self, interaction: discord.Interaction):
        cfg = get_guild_cfg(interaction.guild_id)
        refresh_role_id = cfg.get("refresh_role_id")
        
        # ตรวจสอบสิทธิ์การใช้งานคำสั่ง
        is_admin = interaction.user.guild_permissions.administrator
        has_role = any(r.id == refresh_role_id for r in interaction.user.roles) if refresh_role_id else False

        if not (is_admin or has_role):
            allowed_role = interaction.guild.get_role(refresh_role_id) if refresh_role_id else None
            role_msg = f"ยศ **{allowed_role.name}**" if allowed_role else "สิทธิ์ **Administrator**"
            await interaction.response.send_message(
                f"❌ คุณไม่มีสิทธิ์ใช้คำสั่งนี้! (ต้องมี {role_msg})",
                ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True)

        # สแกนหาข้อความแผงตั๋วในช่องที่กดใช้คำสั่ง แล้วอัปเดต View
        updated_count = 0
        try:
            async for msg in interaction.channel.history(limit=50):
                if msg.author.id == self.bot.user.id and msg.components:
                    # สร้าง View ใหม่ที่ดึงรายชื่อสมาชิกล่าสุด
                    new_view = SelectStaffTicketView(self.bot, interaction.guild_id)
                    await msg.edit(view=new_view)
                    updated_count += 1
        except Exception:
            pass

        role = interaction.guild.get_role(cfg.get("support_role_id")) if cfg.get("support_role_id") else None
        staff_count = len([m for m in role.members if not m.bot]) if role else 0

        await interaction.followup.send(
            f"🔄 **รีเฟรชข้อมูลสำเร็จ!**\n"
            f"อัปเดตแผงเลือกคนในช่องนี้เรียบร้อยแล้ว (พบสมาชิกในยศทั้งหมด `{staff_count}` คน)",
            ephemeral=True
        )


# ============================================================
# ฟังก์ชัน Setup
# ============================================================
async def setup(bot):
    res = bot.add_cog(TicketCog(bot))
    if inspect.isawaitable(res):
        await res
    print("✅ โหลดระบบตั๋ว (Live UI Refreshing via /ticket_refresh) สำเร็จ!")
