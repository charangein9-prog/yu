import os
import json
from datetime import datetime, timezone
import discord
from discord import app_commands

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
AUDIT_FILE = os.path.join(DATA_DIR, "security_audit.log")
DATA_FILE = os.path.join(DATA_DIR, "role_text.json")
os.makedirs(DATA_DIR, exist_ok=True)

DEFAULT_CONFIG = {"enabled": False, "channel_id": None, "role_id": None, "trigger_text": "", "panel_message_id": None, "panel_channel_id": None}

def load_data():
    if not os.path.exists(DATA_FILE): return {}
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f: return json.load(f)
    except Exception: return {}

def save_data(data):
    tmp_file = DATA_FILE + ".tmp"
    with open(tmp_file, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)
    os.replace(tmp_file, DATA_FILE)

def audit(guild_id, user_id, action):
    try:
        now = datetime.now(timezone.utc).isoformat(timespec="seconds")
        with open(AUDIT_FILE, "a", encoding="utf-8") as f:
            f.write(f"{now} guild={guild_id} user={user_id} action={action}\n")
    except OSError:
        pass
def get_config(guild_id):
    data = load_data(); gid = str(guild_id); changed = False
    if gid not in data: data[gid] = DEFAULT_CONFIG.copy(); changed = True
    else:
        for k, v in DEFAULT_CONFIG.items():
            if k not in data[gid]: data[gid][k] = v; changed = True
    if changed: save_data(data)
    return data[gid]

def update_config(guild_id, key, value):
    data = load_data(); gid = str(guild_id)
    if gid not in data: data[gid] = DEFAULT_CONFIG.copy()
    data[gid][key] = value; save_data(data)

def can_manage(interaction):
    if interaction.guild is None or interaction.user is None: return False
    member = interaction.guild.get_member(interaction.user.id)
    if member is None: return False
    p = member.guild_permissions
    return member.id == interaction.guild.owner_id or p.administrator or p.manage_guild

def make_embed(guild_id):
    c = get_config(guild_id)
    ch = f"<#{c['channel_id']}>" if c.get("channel_id") else "ยังไม่ได้ตั้ง"
    role = f"<@&{c['role_id']}>" if c.get("role_id") else "ยังไม่ได้ตั้ง"
    trigger = c.get("trigger_text") or "ยังไม่ได้ตั้ง"
    status = "🟢 เปิด" if c.get("enabled") else "🔴 ปิด"
    return discord.Embed(title="🎖️ ระบบรับยศด้วยข้อความ", description=f"สถานะ: **{status}**\nห้อง: {ch}\nยศ: {role}\nข้อความ: `{trigger}`\n\nกดปุ่มด้านล่างเพื่อแก้ไขระบบ", color=discord.Color.blurple())

class TriggerModal(discord.ui.Modal, title="ตั้งข้อความรับยศ"):
    trigger = discord.ui.TextInput(label="ข้อความที่ต้องพิมพ์", required=True, max_length=200)
    async def on_submit(self, interaction):
        if not can_manage(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        value = self.trigger.value.strip()
        if not value:
            await interaction.response.send_message("❌ ห้ามว่าง", ephemeral=True); return
        update_config(interaction.guild.id, "trigger_text", value)
        audit(interaction.guild.id, interaction.user.id, "F2 set_trigger_text")
        await interaction.response.send_message("✅ บันทึกข้อความแล้ว", ephemeral=True)

class ChannelSelect(discord.ui.ChannelSelect):
    def __init__(self):
        super().__init__(placeholder="เลือกห้องรับยศ", channel_types=[discord.ChannelType.text, discord.ChannelType.news], min_values=1, max_values=1, custom_id="role_text_channel_select", row=0)
    async def callback(self, interaction):
        if not can_manage(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        ch = self.values[0]; update_config(interaction.guild.id, "channel_id", ch.id)
        audit(interaction.guild.id, interaction.user.id, "F2 set_channel")
        await interaction.response.send_message(f"✅ ตั้งห้องเป็น {ch.mention}", ephemeral=True)

class RoleSelect(discord.ui.RoleSelect):
    def __init__(self):
        super().__init__(placeholder="เลือกยศที่จะให้", min_values=1, max_values=1, custom_id="role_text_role_select", row=1)
    async def callback(self, interaction):
        if not can_manage(interaction):
            await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        role = self.values[0]; me = interaction.guild.me
        if me is None or role >= me.top_role:
            await interaction.response.send_message("❌ ยศนี้สูงกว่ายศบอท", ephemeral=True); return
        update_config(interaction.guild.id, "role_id", role.id)
        audit(interaction.guild.id, interaction.user.id, "F2 set_role")
        await interaction.response.send_message(f"✅ ตั้งยศเป็น {role.mention}", ephemeral=True)

class RoleTextView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(ChannelSelect()); self.add_item(RoleSelect())
    @discord.ui.button(label="✏️ แก้ข้อความ", style=discord.ButtonStyle.primary, custom_id="role_text_trigger", row=2)
    async def trigger(self, interaction, button):
        if not can_manage(interaction): await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        await interaction.response.send_modal(TriggerModal())
    @discord.ui.button(label="🟢 เปิดระบบ", style=discord.ButtonStyle.success, custom_id="role_text_enable", row=3)
    async def enable(self, interaction, button):
        if not can_manage(interaction): await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        c = get_config(interaction.guild.id)
        if not c.get("channel_id") or not c.get("role_id") or not c.get("trigger_text"):
            await interaction.response.send_message("❌ เลือกห้อง + ยศ + ข้อความให้ครบ", ephemeral=True); return
        update_config(interaction.guild.id, "enabled", True); audit(interaction.guild.id, interaction.user.id, "F2 enabled"); await interaction.response.send_message("🟢 เปิดระบบแล้ว", ephemeral=True)
    @discord.ui.button(label="🔴 ปิดระบบ", style=discord.ButtonStyle.danger, custom_id="role_text_disable", row=3)
    async def disable(self, interaction, button):
        if not can_manage(interaction): await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        update_config(interaction.guild.id, "enabled", False); audit(interaction.guild.id, interaction.user.id, "F2 disabled"); await interaction.response.send_message("🔴 ปิดระบบแล้ว", ephemeral=True)
    @discord.ui.button(label="🔄 อัปเดทแผง", style=discord.ButtonStyle.primary, custom_id="role_text_update", row=4)
    async def update(self, interaction, button):
        if not can_manage(interaction): await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        await interaction.response.defer(ephemeral=True); ok, text = await update_saved_panel(interaction.client, interaction.guild.id); await interaction.followup.send(("✅ " if ok else "❌ ") + text, ephemeral=True)

async def update_saved_panel(bot, guild_id):
    c = get_config(guild_id); mid, cid = c.get("panel_message_id"), c.get("panel_channel_id")
    if not mid or not cid: return False, "ยังไม่มีแผงที่บันทึกไว้"
    guild = bot.get_guild(int(guild_id)); channel = guild.get_channel(int(cid)) if guild else None
    if not channel: return False, "ไม่พบห้องแผง"
    try:
        msg = await channel.fetch_message(int(mid)); await msg.edit(embed=make_embed(guild_id), view=RoleTextView()); return True, "อัปเดทแผงเดิมแล้ว"
    except discord.NotFound: return False, "แผงเดิมถูกลบแล้ว"
    except discord.Forbidden: return False, "บอทไม่มีสิทธิ์แก้ข้อความ"
    except discord.HTTPException as e: return False, f"Discord Error: {e}"

def setup(bot):
    @bot.tree.command(name="roletext", description="ตั้งค่าระบบรับยศด้วยข้อความ")
    async def roletext(interaction):
        if not can_manage(interaction): await interaction.response.send_message("❌ ไม่มีสิทธิ์", ephemeral=True); return
        msg = await interaction.channel.send(embed=make_embed(interaction.guild.id), view=RoleTextView())
        update_config(interaction.guild.id, "panel_message_id", msg.id); update_config(interaction.guild.id, "panel_channel_id", interaction.channel.id)
        await interaction.response.send_message("✅ สร้างแผงตั้งค่าแล้ว", ephemeral=True)
    bot.add_view(RoleTextView())
    @bot.listen("on_message")
    async def role_text_message(message):
        if message.author.bot or message.guild is None: return
        c = get_config(message.guild.id)
        if not c.get("enabled") or message.channel.id != c.get("channel_id"): return
        if message.content.strip().lower() != str(c.get("trigger_text", "")).strip().lower(): return
        role = message.guild.get_role(int(c["role_id"])) if c.get("role_id") else None; me = message.guild.me
        if role is None or me is None or role >= me.top_role: return
        try:
            if role not in message.author.roles: await message.author.add_roles(role, reason="ระบบรับยศด้วยข้อความ")
            await message.delete()
        except (discord.Forbidden, discord.HTTPException): pass
