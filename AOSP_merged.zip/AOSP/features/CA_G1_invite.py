import discord
from discord import app_commands
from discord.ext import commands

class InviteModal(discord.ui.Modal, title="สร้างลิงก์เชิญ"):
    hours = discord.ui.TextInput(
        label="อายุลิงก์ (ชั่วโมง, 0 = ไม่หมดอายุ)", default="24", max_length=3)
    uses = discord.ui.TextInput(
        label="ใช้ได้กี่ครั้ง (0 = ไม่จำกัด)", default="0", max_length=3)

    def __init__(self, channel):
        super().__init__()
        self.channel = channel

    async def on_submit(self, interaction: discord.Interaction):
        try:
            h, u = int(self.hours.value), int(self.uses.value)
        except ValueError:
            return await interaction.response.send_message(
                "กรอกเป็นตัวเลขเท่านั้น", ephemeral=True)
        if not (0 <= h <= 168 and 0 <= u <= 100):
            return await interaction.response.send_message(
                "อายุสูงสุด 168 ชม. (7 วัน) และจำนวนครั้งสูงสุด 100", ephemeral=True)

        invite = await self.channel.create_invite(
            max_age=h * 3600, max_uses=u, unique=True)
        await interaction.response.send_message(
            f"ลิงก์ของคุณ: {invite.url}", ephemeral=True)

class InviteView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=300)
        self.channel = None

    @discord.ui.select(cls=discord.ui.ChannelSelect,
                       channel_types=[discord.ChannelType.text],
                       placeholder="เลือกห้องปลายทาง")
    async def pick(self, interaction: discord.Interaction, select: discord.ui.ChannelSelect):
        self.channel = interaction.guild.get_channel(select.values[0].id)
        await interaction.response.defer()

    @discord.ui.button(label="ตั้งค่าและสร้างลิงก์", style=discord.ButtonStyle.green)
    async def create(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(
            InviteModal(self.channel or interaction.channel))

class Invite(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="invite_panel", description="เปิดแผงสร้างลิงก์เชิญ")
    @app_commands.checks.has_permissions(create_instant_invite=True)
    async def invite_panel(self, interaction: discord.Interaction):
        await interaction.response.send_message(
            "เลือกห้อง แล้วกดปุ่มเพื่อตั้งค่า", view=InviteView(), ephemeral=True)

async def setup(bot):
    await bot.add_cog(Invite(bot))